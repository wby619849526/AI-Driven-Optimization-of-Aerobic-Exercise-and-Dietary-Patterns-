"""Generate and save all raw data (development cohort + independent trial cohort)."""
import os, json
import numpy as np, pandas as pd
from simulator import (generate_cohort, generate_actigraphy, nonparametric_circadian, sample_prescriptions,
                       response, DEC_NAMES, DEC_LB, DEC_UB, DEC_UNITS, OUTCOMES, OUT_LABELS, bmhi)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data", "raw")
os.makedirs(RAW, exist_ok=True)


def build(n, seed, prefix, assign=True):
    base, lat = generate_cohort(n, seed=seed)
    act, logs = generate_actigraphy(base, lat, seed=seed)
    npc = nonparametric_circadian(act)
    base = pd.concat([base, npc], axis=1)
    rng = np.random.default_rng(seed + 99)
    base.round(4).to_csv(os.path.join(RAW, f"{prefix}baseline_phenotype.csv"), index=False)
    lat.round(4).to_csv(os.path.join(RAW, f"{prefix}latent_ground_truth.csv"), index=False)
    logs.to_csv(os.path.join(RAW, f"{prefix}daily_logs.csv"), index=False)
    long = pd.DataFrame(dict(sid=np.repeat(base.sid.values, act.shape[1]),
                             day=np.tile(np.repeat(np.arange(1, 15), 24), n),
                             hour=np.tile(np.arange(24), 14 * n),
                             activity_counts=np.round(act.reshape(-1), 1)))
    long.to_csv(os.path.join(RAW, f"{prefix}actigraphy_hourly.csv"), index=False)
    np.save(os.path.join(RAW, f"{prefix}actigraphy.npy"), act.astype(np.float32))
    if assign:
        X = sample_prescriptions(n, base.bmi.values, rng)
        Y, adh = response(base, lat, X, rng, noise=True)
        pa = pd.DataFrame(X, columns=DEC_NAMES)
        pa.insert(0, "sid", base.sid.values)
        pa["adherence_expected"] = adh
        pa.round(4).to_csv(os.path.join(RAW, f"{prefix}intervention_assignments.csv"), index=False)
        out = pd.DataFrame(Y, columns=OUTCOMES)
        out.insert(0, "sid", base.sid.values)
        out["bmhi"] = bmhi(Y)
        out.round(5).to_csv(os.path.join(RAW, f"{prefix}outcomes_12wk.csv"), index=False)
    print(prefix, "done", base.shape, logs.shape, long.shape)


if __name__ == "__main__":
    build(2400, 2026, "dev_")
    build(800, 7, "trial_", assign=False)
    dd = []
    for c, u, lo, hi in zip(DEC_NAMES, DEC_UNITS, DEC_LB, DEC_UB):
        dd.append(dict(variable=c, group="decision (prescription)", unit=u, range=f"[{lo:g}, {hi:g}]"))
    for c, lab in zip(OUTCOMES, OUT_LABELS):
        dd.append(dict(variable=c, group="12-week outcome", unit=lab, range=""))
    pd.DataFrame(dd).to_csv(os.path.join(RAW, "data_dictionary_decisions_outcomes.csv"), index=False)
