"""Architecture / methodology / optimizer flow diagrams (Graphviz)."""
import os, subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

FONT = "Helvetica"
C = dict(data="#E8F1FB", data_b="#2F6DB5", prep="#EAF6EC", prep_b="#2E8B57", model="#FFF4E0", model_b="#C77700",
         opt="#F3E8FA", opt_b="#7B3FA0", eval="#FDECEC", eval_b="#B83B3B", grey="#F4F4F4", grey_b="#555555")


def render(dot, name):
    p = os.path.join(FIG, name)
    open(p + ".dot", "w").write(dot)
    for fmt in ["png", "pdf"]:
        args = ["dot", f"-T{fmt}", p + ".dot", "-o", f"{p}.{fmt}"]
        if fmt == "png":
            args.insert(1, "-Gdpi=300")
        subprocess.run(args, check=True)


def node(n, label, fill, border, shape="box", w=None):
    extra = f', width={w}' if w else ""
    return (f'{n} [label=<{label}>, shape={shape}, style="rounded,filled", fillcolor="{fill}", color="{border}", '
            f'penwidth=1.6, fontname="{FONT}", fontsize=11, margin="0.18,0.10"{extra}];\n')


def flow():
    d = f'digraph G {{\nrankdir=TB; newrank=true; ordering=out; nodesep=0.3; ranksep=0.45; splines=spline; bgcolor="white";\n'
    d += f'edge [color="#444444", penwidth=1.3, arrowsize=0.8, fontname="{FONT}", fontsize=9];\n'
    # stage clusters
    d += f'subgraph cluster_a {{label=<<B>A. Data acquisition (CHRONO-SIM cohort)</B>>; fontname="{FONT}"; fontsize=12; style="rounded,dashed"; color="{C["data_b"]}";\n'
    d += node("a1", "<B>Baseline phenotype</B><BR/>anthropometry, VO<SUB>2max</SUB>, HRV,<BR/>HOMA-IR, lipids, diet, stress", C["data"], C["data_b"])
    d += node("a2", "<B>14-day wrist actigraphy</B><BR/>336 hourly activity counts", C["data"], C["data_b"])
    d += node("a3", "<B>14-day behaviour logs</B><BR/>sleep, steps, MVPA,<BR/>meal timing, caffeine", C["data"], C["data_b"])
    d += node("a4", "<B>Randomised 12-week<BR/>exercise + diet prescriptions</B><BR/>(12 decision variables)<BR/>and 9 outcome changes", C["data"], C["data_b"])
    d += "}\n"
    d += f'subgraph cluster_b {{label=<<B>B. Chrono-feature engineering</B>>; fontname="{FONT}"; fontsize=12; style="rounded,dashed"; color="{C["prep_b"]}";\n'
    d += node("b1", "<B>Non-parametric circadian metrics</B><BR/>IS, IV, RA, L5, M10, M10 onset", C["prep"], C["prep_b"])
    d += node("b2", "<B>Token construction</B><BR/>24 hourly + 14 daily tokens<BR/>circadian / weekly harmonics", C["prep"], C["prep_b"])
    d += node("b3", "<B>Chronotype-relative<BR/>prescription encoding</B><BR/>timing vs. MSF<SUB>sc</SUB>, wake, sleep onset", C["prep"], C["prep_b"])
    d += node("b4", "<B>Phenotype-similarity graph</B><BR/>cosine k-NN to labelled<BR/>reference students", C["prep"], C["prep_b"])
    d += "}\n"
    d += f'subgraph cluster_c {{label=<<B>C. Learning: CHRONO-RAGAT</B>>; fontname="{FONT}"; fontsize=12; style="rounded,dashed"; color="{C["model_b"]}";\n'
    d += node("c1", "<B>Circadian temporal<BR/>Transformer</B>", C["model"], C["model_b"])
    d += node("c2", "<B>Response-aware graph<BR/>attention (RAGAT)</B><BR/>residual response propagation", C["model"], C["model_b"])
    d += node("c3", "<B>Chrono-nutritional<BR/>cross-attention + FiLM</B>", C["model"], C["model_b"])
    d += node("c4", "<B>Multi-task head + tree stacking</B><BR/>9 outcomes &#8594; BMHI<BR/>deep ensemble (&#956;, &#963;)", C["model"], C["model_b"])
    d += node("c5", "<B>CLO-GWO hyper-<BR/>parameter search</B>", C["opt"], C["opt_b"])
    d += "}\n"
    d += f'subgraph cluster_d {{label=<<B>D. Decision: personalised prescription</B>>; fontname="{FONT}"; fontsize=12; style="rounded,dashed"; color="{C["opt_b"]}";\n'
    d += node("d1", "<B>Objective</B><BR/>max &#956;<SUB>BMHI</SUB> &#8722; &#954;&#183;&#963;<SUB>BMHI</SUB><BR/>&#8722; &#955;&#183;constraint violation", C["opt"], C["opt_b"])
    d += node("d2", "<B>CLO-GWO solver</B><BR/>circadian a(t), L&#233;vy, OBL init,<BR/>shift-invariant encircling", C["opt"], C["opt_b"])
    d += node("d3", "<B>Safety repair</B><BR/>fat 20-40 %, deficit only if BMI&gt;22,<BR/>pre-sleep fast &#8805; 2 h", C["opt"], C["opt_b"])
    d += "}\n"
    d += f'subgraph cluster_e {{label=<<B>E. Evaluation</B>>; fontname="{FONT}"; fontsize=12; style="rounded,dashed"; color="{C["eval_b"]}";\n'
    d += node("e1", "<B>Prediction</B><BR/>5-fold CV, 10 baselines,<BR/>ablations", C["eval"], C["eval_b"])
    d += node("e2", "<B>Counterfactual decision<BR/>quality</B><BR/>true BMHI, regret vs. oracle", C["eval"], C["eval_b"])
    d += node("e3", "<B>In-silico RCT</B><BR/>external cohort, 4 arms", C["eval"], C["eval_b"])
    d += node("e4", "<B>Interpretability</B><BR/>attention, chronotype maps", C["eval"], C["eval_b"])
    d += "}\n"
    d += "{rank=same; a1; a2; a3; a4;} {rank=same; b1; b2; b4; b3;} {rank=same; c5; c1; c2; c3; c4;} {rank=same; d1; d2; d3;} {rank=same; e2; e3; e1; e4;}\n"
    d += "a1 -> a2 -> a3 -> a4 [style=invis]; b1 -> b2 -> b4 -> b3 [style=invis]; c5 -> c1 -> c2 -> c3 -> c4 [style=invis]; e2 -> e3 -> e1 -> e4 [style=invis];\n"
    d += "a1 -> b1; a2 -> b1; a2 -> b2; a3 -> b2; a4 -> b3; a1 -> b4; b1 -> b4 [constraint=false];\n"
    d += "b2 -> c1; b1 -> c1; b4 -> c2; b3 -> c3; c1 -> c2; c2 -> c3; c3 -> c4; c5 -> c1 [style=dashed, color=\"%s\"];\n" % C["opt_b"]
    d += "c4 -> d1; d1 -> d2; d2 -> d3; d3 -> d1 [style=dashed, constraint=false];\n"
    d += "c4 -> e1; d3 -> e2; d3 -> e3; c4 -> e4;\n"
    d += "}\n"
    render(d, "Fig1_methodology_flow")


def architecture():
    d = f'digraph G {{\nrankdir=TB; nodesep=0.28; ranksep=0.42; splines=spline; bgcolor="white";\n'
    d += f'edge [color="#444444", penwidth=1.2, arrowsize=0.75, fontname="{FONT}", fontsize=9];\n'
    d += '{rank=same; s_in; h_in; d_in; p_in; nb_in;}\n'
    d += node("s_in", "<B>Static phenotype</B><BR/>s<SUB>i</SUB> &#8712; R<SUP>37</SUP>", C["data"], C["data_b"])
    d += node("h_in", "<B>Hourly rest-activity</B><BR/>H<SUB>i</SUB> &#8712; R<SUP>24&#215;4</SUP>", C["data"], C["data_b"])
    d += node("d_in", "<B>Daily behaviour</B><BR/>D<SUB>i</SUB> &#8712; R<SUP>14&#215;9</SUP>", C["data"], C["data_b"])
    d += node("p_in", "<B>Candidate prescription</B><BR/>x &#8712; R<SUP>12</SUP> &#8594; e(x) &#8712; R<SUP>21</SUP>", C["data"], C["data_b"])
    d += node("nb_in", "<B>k reference neighbours j</B><BR/>(c<SUB>j</SUB>, residual r<SUB>j</SUB>, e(x<SUB>j</SUB>), sim<SUB>ij</SUB>)", C["data"], C["data_b"])
    d += node("enc", "<B>Static encoder</B><BR/>MLP 37&#8594;2d&#8594;d  &#8594;  [CLS]", C["model"], C["model_b"])
    d += node("tok", "<B>Token embedding</B><BR/>W<SUB>h</SUB>H + PE<SUB>24h</SUB>(2 harmonics)<BR/>W<SUB>d</SUB>D + PE<SUB>7d</SUB>(2 harmonics)", C["model"], C["model_b"])
    d += node("tf", "<B>Circadian Transformer block</B><BR/>LN &#8594; MHSA (h heads, 39 tokens) &#8594; LN &#8594; FFN<BR/>output: c<SUB>i</SUB> = [CLS], context tokens T<SUB>i</SUB>", C["model"], C["model_b"])
    d += node("base", "<B>Graph-free base path</B><BR/>base prediction of neighbour j:<BR/>Head(c<SUB>j</SUB>, T<SUB>j</SUB>, x<SUB>j</SUB>)<BR/>residual r<SUB>j</SUB> = y<SUB>j</SUB> &#8722; sg(base)", C["grey"], C["grey_b"])
    d += node("ragat", "<B>Response-Aware Graph Attention (RAGAT)</B><BR/>e<SUB>ij</SUB> = a<SUB>h</SUB><SUP>T</SUP> LeakyReLU(W<SUB>a</SUB>c<SUB>i</SUB> + W<SUB>b</SUB>c<SUB>j</SUB> + W<SUB>c</SUB>[r<SUB>j</SUB>, e(x<SUB>j</SUB>)] + W<SUB>p</SUB>(e(x) &#8722; e(x<SUB>j</SUB>)) + w<SUB>s</SUB>sim<SUB>ij</SUB>)<BR/>m<SUB>ij</SUB> = W<SUB>v</SUB>c<SUB>j</SUB> + MLP([r<SUB>j</SUB>, e(x<SUB>j</SUB>)]);   z<SUB>i</SUB> = LN(c<SUB>i</SUB> + W<SUB>o</SUB>&#931;<SUB>j</SUB>&#945;<SUB>ij</SUB>m<SUB>ij</SUB>)", C["model"], C["model_b"])
    d += node("itok", "<B>Intervention tokens</B><BR/>exercise | nutrition | caffeine", C["model"], C["model_b"])
    d += node("xatt", "<B>Chrono-nutritional cross-attention</B><BR/>queries: intervention tokens t<BR/>keys / values: context tokens T<SUB>i</SUB> and z<SUB>i</SUB><BR/>U = LN(t + MHA(t, [T<SUB>i</SUB>; z<SUB>i</SUB>]))", C["model"], C["model_b"])
    d += node("film", "<B>FiLM modulation</B><BR/>h = z<SUB>i</SUB>&#8857;(1 + tanh(W<SUB>g</SUB>&#363;)) + W<SUB>b</SUB>&#363;", C["model"], C["model_b"])
    d += node("head", "<B>Multi-task head (+ wide skip of s<SUB>i</SUB>)</B><BR/>GELU MLP &#8594; 9 outcome changes<BR/>baseline-scaled for HOMA-IR, TG, RMSSD<BR/>(loss on absolute scale)", C["model"], C["model_b"])
    d += node("prior", "<B>(6) Boosted-tree expert</B><BR/>b(s<SUB>i</SUB>, e(x)): gradient-boosted trees<BR/>(baseline-scaled targets)", C["grey"], C["grey_b"])
    d += node("stack", "<B>Per-outcome stacking</B><BR/>&#375;<SUB>t</SUB> = &#969;<SUB>t</SUB>&#183;b<SUB>t</SUB> + (1 &#8722; &#969;<SUB>t</SUB>)&#183;f<SUB>t</SUB><SUP>net</SUP><BR/>&#969;<SUB>t</SUB> fitted on validation students", C["eval"], C["eval_b"])
    d += node("out", "<B>BMHI</B> = &#931;<SUB>t</SUB> w<SUB>t</SUB> s<SUB>t</SUB> &#916;y<SUB>t</SUB> / MCID<SUB>t</SUB><BR/>ensemble mean &#956; and s.d. &#963;", C["eval"], C["eval_b"])
    d += node("loss", "<B>Loss</B>: &#931;<SUB>t</SUB>[&#189;e<SUP>&#8722;&#961;<SUB>t</SUB></SUP>MSE<SUB>t</SUB> + &#189;&#961;<SUB>t</SUB>] + &#955;<SUB>B</SUB>&#183;MSE(BMHI) + &#946;&#183;L<SUB>base</SUB>", C["grey"], C["grey_b"])
    d += node("clo", "<B>CLO-GWO</B><BR/>(i) hyper-parameters;<BR/>(ii) argmax<SUB>x</SUB> &#956;(x) &#8722; &#954;&#963;(x)", C["opt"], C["opt_b"])
    d += "s_in -> enc; h_in -> tok; d_in -> tok; enc -> tf; tok -> tf;\n"
    d += "tf -> ragat [label=\" c_i\"]; nb_in -> base; base -> ragat [label=\" r_j\"]; nb_in -> ragat; p_in -> ragat [label=\" e(x)\"];\n"
    d += "p_in -> itok; itok -> xatt; tf -> xatt [label=\" T_i\"]; ragat -> xatt [label=\" z_i\"]; xatt -> film; ragat -> film; film -> head; s_in -> head [style=dashed, label=\" wide\"];\n"
    d += "s_in -> prior [style=dashed]; p_in -> prior [style=dashed]; prior -> stack [label=\" b_t\"]; head -> stack [label=\" f_t^net\"];\n"
    d += "stack -> out; head -> loss [style=dotted]; out -> clo; clo -> p_in [style=dashed, color=\"%s\", label=\" candidate x\"];\n" % C["opt_b"]
    d += "}\n"
    render(d, "Fig2_CHRONO_RAGAT_architecture")


def clo_gwo_flow():
    d = f'digraph G {{\nrankdir=TB; nodesep=0.3; ranksep=0.32; bgcolor="white";\n'
    d += f'edge [color="#444444", penwidth=1.2, arrowsize=0.75, fontname="{FONT}", fontsize=9];\n'
    d += node("s0", "<B>Start</B>: bounds, population P, FE budget", C["grey"], C["grey_b"])
    d += node("s1", "<B>Tent-chaotic initialisation</B> X &#8594; opposite X&#771; = lb + ub &#8722; X<BR/>keep best P of X &#8746; X&#771;", C["opt"], C["opt_b"])
    d += node("s2", "<B>Circadian-oscillatory convergence factor</B><BR/>a(t) = 2cos<SUP>2</SUP>(&#960;t/2T)&#183;[1 + A&#183;sin(2&#960;&#969;t/T)]", C["opt"], C["opt_b"])
    d += node("s3", "<B>Fitness-weighted leader fusion</B><BR/>X' = &#931;<SUB>k&#8712;{&#945;,&#946;,&#948;}</SUB> w<SUB>k</SUB>(L<SUB>k</SUB> &#8722; A<SUB>k</SUB>&#8857;|C<SUB>k</SUB>&#8857;(L<SUB>k</SUB> &#8722; X)|)<BR/>(shift-invariant encircling)", C["opt"], C["opt_b"])
    d += node("s4", "<B>Greedy survivor selection</B>: X &#8592; X' if f(X') &lt; f(X)", C["opt"], C["opt_b"])
    d += node("s5", "<B>L&#233;vy-flight refinement of &#945;</B> (annealed step);<BR/>accepted candidate replaces worst wolf", C["opt"], C["opt_b"])
    d += node("s7", "<B>Stagnation?</B> no improvement for 20 iters", C["grey"], C["grey_b"], shape="diamond")
    d += node("s8", "<B>Partial restart</B>: worst half ~ N(&#945;, &#963;(t))", C["opt"], C["opt_b"])
    d += node("s9", "<B>Budget exhausted?</B>", C["grey"], C["grey_b"], shape="diamond")
    d += node("s10", "<B>Return &#945;</B> (best prescription / hyper-parameters)", C["eval"], C["eval_b"])
    d += "s0 -> s1 -> s2 -> s3 -> s4 -> s5 -> s7; s7 -> s8 [label=\" yes\"]; s7 -> s9 [label=\" no\"]; s8 -> s9; s9 -> s2 [label=\" no\", constraint=false]; s9 -> s10 [label=\" yes\"];\n}\n"
    render(d, "Fig3_CLO_GWO_flowchart")


if __name__ == "__main__":
    flow(); architecture(); clo_gwo_flow()
    print("diagrams done")
