"""Stage the deliverable folder for the user's PC: copies key files individually and zips bulky result folders."""
import os, shutil, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = "/mnt/user-data/outputs/DJ0326-1"


def zipdir(src, dst):
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for base, _, files in os.walk(src):
            for f in files:
                if "__pycache__" in base:
                    continue
                p = os.path.join(base, f)
                z.write(p, os.path.relpath(p, os.path.dirname(src)))


if __name__ == "__main__":
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    manifest = []
    for sub in ["paper", "figures", "code", "data/raw"]:
        os.makedirs(os.path.join(OUT, sub), exist_ok=True)
    shutil.copy(os.path.join(ROOT, "README.md"), OUT); manifest.append("README.md")
    for f in sorted(os.listdir(os.path.join(ROOT, "paper"))):
        if f.endswith((".docx", ".pdf")):
            shutil.copy(os.path.join(ROOT, "paper", f), os.path.join(OUT, "paper")); manifest.append("paper/" + f)
    for f in sorted(os.listdir(os.path.join(ROOT, "figures"))):
        if f.endswith(".png"):
            shutil.copy(os.path.join(ROOT, "figures", f), os.path.join(OUT, "figures")); manifest.append("figures/" + f)
    for f in sorted(os.listdir(os.path.join(ROOT, "code"))):
        if f.endswith((".py", ".js")):
            shutil.copy(os.path.join(ROOT, "code", f), os.path.join(OUT, "code")); manifest.append("code/" + f)
    for f in sorted(os.listdir(os.path.join(ROOT, "data", "raw"))):
        if f.endswith(".csv"):
            shutil.copy(os.path.join(ROOT, "data", "raw", f), os.path.join(OUT, "data", "raw")); manifest.append("data/raw/" + f)
    # bulky items as archives
    zipdir(os.path.join(ROOT, "results"), os.path.join(OUT, "results_all.zip")); manifest.append("results_all.zip")
    zipdir(os.path.join(ROOT, "figures"), os.path.join(OUT, "figures_pdf_png_dot.zip")); manifest.append("figures_pdf_png_dot.zip")
    zipdir(os.path.join(ROOT, "data"), os.path.join(OUT, "data_all_including_npy.zip")); manifest.append("data_all_including_npy.zip")
    open(os.path.join(OUT, "MANIFEST.txt"), "w").write("\n".join(manifest))
    print(len(manifest), "files staged")
