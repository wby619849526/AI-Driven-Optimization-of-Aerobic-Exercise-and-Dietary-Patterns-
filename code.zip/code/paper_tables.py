"""Result tables 6-9 and the result dictionary R used by the manuscript text."""
import os, json, glob
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); RAW = os.path.join(ROOT, "data", "raw")

NEURAL_BASE = {"w/o graph (Transformer-only)": "Transformer-only (no graph)", "GCN instead of RAGAT": "GCN variant",
               "GATv2 instead of RAGAT": "GATv2 variant"}
TAB = ["Ridge", "k-NN", "SVR (RBF)", "Random forest", "Gradient boosting", "MLP"]


def load_cv():
    rows = []
    for fpath in glob.glob(os.path.join(RES, "cv", "*.json")):
        r = json.load(open(fpath))
        base = os.path.basename(fpath)
        r["kind"] = "tab" if base.startswith("TAB_") else ("ceil" if base.startswith("CEIL") else "nn")
        rows.append(r)
    return pd.DataFrame(rows)


def ms(x, d=3):
    x = np.asarray(x, float)
    return f"{np.nanmean(x):.{d}f} ± {np.nanstd(x, ddof=1):.{d}f}" if len(x) > 1 else f"{np.nanmean(x):.{d}f}"


def prediction_table():
    df = load_cv()
    info = {}
    tab = df[df.kind == "tab"]
    for m in TAB:
        d = tab[tab.model == m]
        if d.empty:
            continue
        gm = d.groupby("rel").bmhi_r2.mean()
        rel = bool(gm.idxmax())
        info[m] = dict(rel=rel, d=d[d.rel == rel])
    nn = df[df.kind == "nn"]
    rows = []

    def add(name, d, sub=None):
        if sub:
            dd = pd.DataFrame(list(d[sub].values))
            dd["train_time_s"] = d.train_time_s.values; dd["infer_ms_per_query"] = d.infer_ms_per_query.values
            d = dd
        rows.append(dict(name=name, mean_r2=d.mean_r2.values, bmhi_r2=d.bmhi_r2.values, bmhi_rmse=d.bmhi_rmse.values,
                         rho=d.bmhi_rho.values, cf_rho=d.cf_rho.values, cf_regret=d.cf_regret.values,
                         time=d.train_time_s.values if "train_time_s" in d else np.array([np.nan]),
                         inf=d.infer_ms_per_query.values if "infer_ms_per_query" in d else np.array([np.nan]),
                         r2=np.stack(d.r2.values)))
    for m in TAB:
        if m in info:
            add(m + (" (rel.)" if info[m]["rel"] else ""), info[m]["d"])
    # graph/sequence network baselines are compared on identical folds in the ablation table
    full = nn[(nn.model == "CHRONO-RAGAT") & (nn.seed == 0)]
    add("CHRONO-RAGAT network only (single)", full, "network_only")
    add("**CHRONO-RAGAT stacked (single)**", full)
    ens = ensemble_cv()
    if ens is not None:
        rows.append(dict(name="CHRONO-RAGAT network only (3-seed ensemble)", **ens["net"]))
        rows.append(dict(name="**CHRONO-RAGAT stacked (3-seed ensemble)**", **ens["stk"]))
    ceil = df[df.kind == "ceil"]
    if not ceil.empty:
        rows.append(dict(name="*Noise ceiling*", mean_r2=ceil.mean_r2.values, bmhi_r2=ceil.bmhi_r2.values,
                         bmhi_rmse=ceil.bmhi_rmse.values, rho=ceil.bmhi_rho.values, cf_rho=np.array([1.0]),
                         cf_regret=np.array([0.0]), time=np.array([np.nan]), inf=np.array([np.nan]),
                         r2=np.stack(ceil.r2.values)))
    return rows


def ensemble_cv():
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from simulator import bmhi, OUTCOMES
    from exp_predict import cf_set, cf_metrics, metrics, fold_split
    from train import fit_blend, blend, Cohort
    cache = os.path.join(RES, "cv_ensemble_cache.pkl")
    if os.path.exists(cache):
        import pickle
        return pickle.load(open(cache, "rb"))
    coh = Cohort("dev_")
    out = {k: dict(mean_r2=[], bmhi_r2=[], bmhi_rmse=[], rho=[], cf_rho=[], cf_regret=[], time=[], inf=[], r2=[])
           for k in ("net", "stk")}
    for k in range(5):
        P = sorted(glob.glob(os.path.join(RES, "cv", f"CHRONO-RAGAT__f{k}__s*_pred.npy")))
        if len(P) < 2:
            return None
        fit_idx, val_idx, te = fold_split(coh, k)
        Yp = np.mean([np.load(p) for p in P], 0).astype(float)
        Yv = np.mean([np.load(p.replace("_pred", "_val")) for p in P], 0).astype(float)
        cf = np.mean([np.load(p.replace("_pred", "_cfY")) for p in P], 0).astype(float)
        tb = dict(np.load(os.path.join(RES, "cv", f"TREE__f{k}.npz")))
        rows, Xcf, tcf = cf_set(coh, te, seed=k)
        w = fit_blend(tb["val"], Yv, coh.Y[val_idx])
        js = [json.load(open(p.replace("_pred.npy", ".json"))) for p in P]
        for key, Ypred, cfp in [("net", Yp, cf), ("stk", blend(w, tb["test"], Yp), blend(w, tb["cf"], cf))]:
            m = metrics(Ypred, coh.Y[te])
            cr, cg = cf_metrics(bmhi(cfp), tcf, len(te))
            for kk, v in [("mean_r2", m["mean_r2"]), ("bmhi_r2", m["bmhi_r2"]), ("bmhi_rmse", m["bmhi_rmse"]),
                          ("rho", m["bmhi_rho"]), ("cf_rho", cr), ("cf_regret", cg), ("r2", m["r2"])]:
                out[key][kk].append(v)
            out[key]["time"].append(sum(j["train_time_s"] for j in js))
            out[key]["inf"].append(sum(j["infer_ms_per_query"] for j in js))
    res = {k: {kk: np.array(vv) for kk, vv in v.items()} for k, v in out.items()}
    import pickle
    pickle.dump(res, open(cache, "wb"))
    return res


def table6(rows):
    out = []
    for r in rows:
        t = "–" if np.all(np.isnan(r["time"])) else f"{np.nanmean(r['time']):.1f}"
        out.append([r["name"], ms(r["bmhi_r2"]), ms(r["bmhi_rmse"]), ms(r["rho"]), ms(r["mean_r2"]), ms(r["cf_rho"]),
                    ms(r["cf_regret"]), t])
    return dict(type="table", header=["Model", "BMHI R²", "BMHI RMSE", "BMHI Spearman ρ", "Mean R² (9 outcomes)",
                                      "Counterfactual ranking ρ", "Top-1 regret", "Train time (s)"],
                rows=out, widths=[0.25, 0.11, 0.11, 0.11, 0.11, 0.12, 0.1, 0.09], fontsize=14)


def per_outcome_table():
    from simulator import OUT_LABELS
    df = load_cv()
    rows = prediction_table()
    names = [r["name"] for r in rows]
    tab = df[df.kind == "tab"]
    best_tab = max([r for r in rows if r["name"].split(" (")[0] in TAB], key=lambda r: np.mean(r["bmhi_r2"]))
    return best_tab


def ablation_table():
    df = load_cv()
    nn = df[df.kind == "nn"]
    full = nn[(nn.model == "CHRONO-RAGAT") & (nn.seed == 0) & (nn.fold < 3)].set_index("fold")
    from exp_predict import ABL
    out = [["**Full CHRONO-RAGAT (stacked)**", ms(full.bmhi_r2), ms(full.mean_r2), ms(full.cf_rho), ms(full.cf_regret), "–", "–", "–"]]
    stats = []

    def row(n, d):
        db = (d.bmhi_r2 - full.bmhi_r2).mean(); dm = (d.mean_r2 - full.mean_r2).mean(); dc = (d.cf_rho - full.cf_rho).mean()
        out.append([n, ms(d.bmhi_r2), ms(d.mean_r2), ms(d.cf_rho), ms(d.cf_regret), f"{db:+.3f}", f"{dm:+.3f}", f"{dc:+.3f}"])
        stats.append(dict(name=n, db=db, dm=dm, dc=dc, dbs=(d.bmhi_r2 - full.bmhi_r2).std(), dms=(d.mean_r2 - full.mean_r2).std(),
                          dcs=(d.cf_rho - full.cf_rho).std()))
    netonly = pd.DataFrame(list(full.network_only.values), index=full.index)
    row("w/o tree branch (network only)", netonly)
    tb = df[(df.kind == "tab") & (df.model == "Gradient boosting") & (df.rel == True) & (df.fold < 3)].set_index("fold")
    if not tb.empty:
        row("w/o network (tree branch only)", tb)
    for n in ABL:
        if n == "CHRONO-RAGAT":
            continue
        d = nn[(nn.model == n) & (nn.fold < 3)].set_index("fold")
        if d.empty:
            continue
        row(n, d)
    return dict(type="table", header=["Variant", "BMHI R²", "Mean R²", "Counterfactual ρ", "Top-1 regret", "Δ BMHI R²", "Δ mean R²", "Δ ρ"],
                rows=out, widths=[0.26, 0.11, 0.11, 0.12, 0.11, 0.1, 0.09, 0.1], fontsize=14), pd.DataFrame(stats)


def prescription_table():
    df = pd.read_csv(os.path.join(RES, "prescription_results.csv"))
    order = ["Usual habits (no programme)", "Guideline (150 min/wk, 12-h window)", "Rule-based chrono-matched",
             "One-size-fits-all AI plan", "GBT surrogate + CLO-GWO", "Network-only ensemble (no tree branch) + CLO-GWO",
             "Single CHRONO-RAGAT (no ensemble) + CLO-GWO",
             "Random search", "WOA", "GWO", "mGWO", "PSO", "DE", "GA", "CLO-GWO", "Oracle (true simulator)"]
    lab = {"CLO-GWO": "**Stacked CHRONO-RAGAT ensemble + CLO-GWO (proposed)**", "Random search": "CHRONO-RAGAT ensemble + random search",
           "WOA": "CHRONO-RAGAT ensemble + WOA", "GWO": "CHRONO-RAGAT ensemble + GWO", "mGWO": "CHRONO-RAGAT ensemble + mGWO",
           "PSO": "CHRONO-RAGAT ensemble + PSO", "DE": "CHRONO-RAGAT ensemble + DE", "GA": "CHRONO-RAGAT ensemble + GA"}
    tests = pd.read_csv(os.path.join(RES, "prescription_paired_tests.csv")).set_index("vs")
    fmap = {"Usual habits (no programme)": "Usual_habits", "Guideline (150 min/wk, 12-h window)": "Guideline",
            "Rule-based chrono-matched": "Rule-based_chrono-matched", "One-size-fits-all AI plan": "One-size-fits-all_AI_plan",
            "GBT surrogate + CLO-GWO": "GBT_surrogate", "Single CHRONO-RAGAT (no ensemble) + CLO-GWO": "Single_model",
            "Network-only ensemble (no tree branch) + CLO-GWO": "Network_only",
            "Oracle (true simulator)": "Oracle", "Random search": "Random_search"}
    out = []
    d = df.set_index("strategy")
    for o in order:
        if o not in d.index:
            continue
        r = d.loc[o]
        key = fmap.get(o, o)
        p = tests.p.get(key, np.nan) if key in tests.index else np.nan
        ptxt = "–" if o == "CLO-GWO" else ("< 0.001" if p < 0.001 else f"{p:.3f}")
        adh = "–" if pd.isna(r.adherence) else f"{r.adherence:.2f}"
        out.append([lab.get(o, o), f"{r.true_bmhi:.3f} ± {r.true_bmhi_sd:.3f}", f"{r.pct_of_oracle:.1f}", f"{r.regret:.3f}",
                    f"{r.d_homa:.3f}", f"{r.d_vo2:.2f}", f"{r.d_sjl:.3f}", f"{r.d_se:.2f}", adh, f"{100 * r.viol_rate:.1f}", ptxt])
    return dict(type="table", header=["Strategy", "True BMHI (mean ± SD)", "% of oracle", "Regret", "ΔHOMA-IR", "ΔVO_{2max}",
                                      "ΔSJL (h)", "ΔSE (%)", "Adherence", "Violations (%)", "p vs. proposed"],
                rows=out, widths=[0.25, 0.1, 0.07, 0.07, 0.07, 0.07, 0.07, 0.07, 0.08, 0.07, 0.08], fontsize=13,
                highlight=["**Stacked CHRONO-RAGAT ensemble + CLO-GWO (proposed)**"])


def trial_table():
    from simulator import OUTCOMES, OUT_LABELS
    s = pd.read_csv(os.path.join(RES, "trial_summary.csv"))
    names = ["Control (usual habits)", "Guideline", "Rule-based chrono-matched", "AI-personalised (CHRONO-RAGAT + CLO-GWO)"]
    lab = dict(zip(OUTCOMES, OUT_LABELS)); lab["bmhi"] = "**BMHI (composite)**"
    out = []
    for _, r in s.iterrows():
        row = [lab[r.outcome]]
        for nm in names:
            row.append(f"{r[nm + '|mean']:.3f} ± {r[nm + '|sd']:.3f}" if abs(r[nm + '|mean']) < 10 else f"{r[nm + '|mean']:.2f} ± {r[nm + '|sd']:.2f}")
        p = r.p_vs_guideline
        row.append(f"{r.diff_vs_guideline:+.3f} [{r.ci_lo_vs_guideline:+.3f}, {r.ci_hi_vs_guideline:+.3f}]")
        row.append("< 0.001" if p < 0.001 else f"{p:.3f}")
        row.append(f"{r.d_vs_guideline:+.2f}")
        out.append(row)
    return dict(type="table", header=["Outcome (12-week change)", "Control", "Guideline", "Rule-based", "AI-personalised",
                                      "AI − guideline [95% CI]", "p", "Cohen's d"],
                rows=out, widths=[0.19, 0.11, 0.11, 0.11, 0.11, 0.19, 0.08, 0.1], fontsize=14)
