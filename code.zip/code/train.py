"""Training / inference utilities for CHRONO-RAGAT and its ablations.

Residual Response Propagation (RRP): every forward pass first computes a graph-free "base" prediction
for each labelled reference student with the shared head; the neighbour message then carries the
reference student's RESIDUAL (observed - base prediction, stop-gradient) together with its prescription.
Residuals isolate shared, unobserved responsiveness (e.g. metabotype) from the effect of the
prescription itself, which the shared head already explains.
"""
import os, time, gc
import numpy as np, pandas as pd
from autograd import Adam, Tensor, gather_rows
from model import ChronoRAGAT
from features import (load_cohort, static_matrix, hourly_tokens, daily_tokens, presc_encode, Standardizer,
                      knn_graph, knn_graph_cross, RAW, ple_fit)
from simulator import OUTCOMES, OUT_SIGN, OUT_SCALE, OUT_W, DEC_NAMES


class Cohort:
    def __init__(self, prefix="dev_", with_outcomes=True):
        b, lat, logs, act = load_cohort(prefix)
        self.b, self.lat = b, lat
        n = len(b)
        self.n = n
        self.S = static_matrix(b)
        self.H = hourly_tokens(act)
        self.Dl = daily_tokens(logs, n)
        if with_outcomes:
            pa = pd.read_csv(os.path.join(RAW, f"{prefix}intervention_assignments.csv"))
            self.X = pa[DEC_NAMES].values
            self.Y = pd.read_csv(os.path.join(RAW, f"{prefix}outcomes_12wk.csv"))[OUTCOMES].values
            self.penc = presc_encode(self.X, b)
        # baseline-scaled outcomes: changes in HOMA-IR, TG and RMSSD are modelled relative to baseline
        self.base_scale = np.ones((n, len(OUTCOMES)))
        self.base_scale[:, 0] = b.homa_ir.values
        self.base_scale[:, 2] = b.triglycerides.values / 100.0
        self.base_scale[:, 8] = b.rmssd.values / 10.0

    def penc_for(self, idx, X):
        return presc_encode(X, self.b.iloc[idx])


def merge_cohorts(dev, ext):
    """Append an external (unlabelled) cohort to the development cohort so that external students can be
    queried against development reference students (inductive inference)."""
    m = Cohort.__new__(Cohort)
    m.b = pd.concat([dev.b, ext.b], ignore_index=True)
    m.lat = pd.concat([dev.lat, ext.lat], ignore_index=True)
    m.n = dev.n + ext.n
    m.S = np.concatenate([dev.S, ext.S]); m.H = np.concatenate([dev.H, ext.H]); m.Dl = np.concatenate([dev.Dl, ext.Dl])
    m.X = np.concatenate([dev.X, np.full((ext.n, dev.X.shape[1]), np.nan)])
    m.Y = np.concatenate([dev.Y, np.full((ext.n, dev.Y.shape[1]), np.nan)])
    m.penc = np.concatenate([dev.penc, np.zeros((ext.n, dev.penc.shape[1]))])
    m.base_scale = np.concatenate([dev.base_scale, ext.base_scale])
    return m


class Context:
    """Standardisation + reference (labelled) set used for graph messages."""

    def __init__(self, coh, ref_idx, k=10, rel=True, prior=False, prior_seed=0):
        self.coh, self.ref, self.k, self.rel = coh, np.asarray(ref_idx), k, rel
        self.scale = coh.base_scale if rel else np.ones_like(coh.base_scale)
        Yr = coh.Y / self.scale
        self.sS = Standardizer().fit(coh.S[ref_idx])
        self.sH = Standardizer().fit(coh.H[ref_idx].reshape(-1, coh.H.shape[-1]))
        self.sD = Standardizer().fit(coh.Dl[ref_idx].reshape(-1, coh.Dl.shape[-1]))
        self.sY = Standardizer().fit(Yr[ref_idx])
        self.S = self.sS(coh.S)
        self.H = self.sH(coh.H.reshape(-1, coh.H.shape[-1])).reshape(coh.H.shape)
        self.Dl = self.sD(coh.Dl.reshape(-1, coh.Dl.shape[-1])).reshape(coh.Dl.shape)
        self.Ys = np.nan_to_num(self.sY(Yr))
        # BMHI is linear in the standardised (scaled) outcomes with per-student coefficients C[i, t]
        self.bmhi_c = (OUT_W * OUT_SIGN / OUT_SCALE) * self.sY.sd.ravel()
        self.bmhi_C = self.bmhi_c[None, :] * self.scale
        # absolute-scale loss for baseline-scaled heads: y_abs_std = y_rel_std * G + O (per student)
        self.sA = Standardizer().fit(coh.Y[ref_idx])
        self.YsA = np.nan_to_num(self.sA(coh.Y))
        self.G = self.sY.sd * self.scale / self.sA.sd
        self.O = (self.sY.mu * self.scale - self.sA.mu) / self.sA.sd
        self.bmhi_CA = np.tile((OUT_W * OUT_SIGN / OUT_SCALE) * self.sA.sd.ravel(), (coh.n, 1))
        mask = np.zeros(coh.n, bool); mask[self.ref] = True
        self.nb_all, self.sim_all = knn_graph(self.S, mask, k)          # cohort indices of reference neighbours
        self.ple_s = ple_fit(self.S[self.ref])
        self.ple_p = ple_fit(coh.penc[self.ref])
        self.prior, self.tree = None, None
        if prior:
            self._fit_tree_prior(prior_seed)

    def _fit_tree_prior(self, seed=0, n_folds=5):
        """Cross-fitted gradient-boosted-tree prior (standardised scale). Reference students receive out-of-fold
        predictions so that the network never learns from in-sample (over-fitted) tree outputs."""
        from sklearn.ensemble import HistGradientBoostingRegressor
        from sklearn.multioutput import MultiOutputRegressor
        coh = self.coh
        Yr = coh.Y / self.scale
        F = np.concatenate([coh.S, coh.penc], 1)
        mk = lambda: MultiOutputRegressor(HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, random_state=seed))
        prior = np.zeros((coh.n, Yr.shape[1]))
        self.tree = mk().fit(F[self.ref], Yr[self.ref])
        prior[:] = self.sY(self.tree.predict(F))
        rng = np.random.default_rng(seed)
        parts = np.array_split(rng.permutation(self.ref), n_folds)
        for k_ in range(n_folds):
            tr = np.concatenate([parts[j] for j in range(n_folds) if j != k_])
            mdl = mk().fit(F[tr], Yr[tr])
            prior[parts[k_]] = self.sY(mdl.predict(F[parts[k_]]))
        self.prior = prior.astype(np.float32)

    def offset_obs(self, idx):
        """Prior for the OBSERVED prescriptions (out-of-fold for reference students)."""
        return None if self.prior is None else self.prior[idx]

    def offset_for(self, idx, pq):
        """Prior for arbitrary (counterfactual) prescriptions of students idx."""
        if self.tree is None:
            return None
        F = np.concatenate([self.coh.S[idx], pq], 1)
        return self.sY(self.tree.predict(F)).astype(np.float32)

    def to_orig(self, ystd, idx):
        return self.sY.inv(ystd) * self.scale[idx]


def make_model(ctx, cfg, seed=0):
    coh = ctx.coh
    return ChronoRAGAT(ds=coh.S.shape[1], dh=coh.H.shape[-1], dd=coh.Dl.shape[-1], dp=coh.penc.shape[1],
                       dy=coh.Y.shape[1], d=cfg.get("d", 24), heads=cfg.get("heads", 4),
                       dropout_p=cfg.get("dropout", 0.2), seed=seed, use_temporal=cfg.get("temporal", True),
                       graph=cfg.get("graph", "ragat"), use_cross=cfg.get("cross", True), use_pe=cfg.get("pe", True),
                       uw=cfg.get("uw", True), bmhi_c=None, lam_bmhi=cfg.get("lam_bmhi", 0.5),
                       wide=cfg.get("wide", True), ple_s=ctx.ple_s if cfg.get("ple", False) else None,
                       ple_p=ctx.ple_p if cfg.get("ple", False) else None)


def _msg_feats(model, ctx, cfg, enc_idx, cls, tok, training):
    """Neighbour response features for every encoded node: [residual or raw response, prescription]."""
    coh = ctx.coh
    full = np.zeros((coh.n, coh.Y.shape[1]), np.float32)
    y0 = None
    if model.graph == "ragat":
        if cfg.get("msg", "residual") == "residual":
            y0 = model.head(cls, tok, coh.penc[enc_idx], training, ctx.S[enc_idx], ctx.offset_obs(enc_idx))
            full[enc_idx] = ctx.Ys[enc_idx] - y0.data
        else:
            full[enc_idx] = ctx.Ys[enc_idx]
    return np.concatenate([full, coh.penc], -1), y0


def _batch_forward(model, ctx, q_idx, cls_all, tok_all, pos_of, pq, training, rfeat, offset=None):
    nb = ctx.nb_all[q_idx]
    nb_c = gather_rows(cls_all, pos_of[nb])
    cls_q = gather_rows(cls_all, pos_of[q_idx])
    tok_q = gather_rows(tok_all, pos_of[q_idx])
    return model.forward(cls_q, tok_q, pq, nb_c, rfeat[nb], ctx.coh.penc[nb], ctx.sim_all[q_idx], training,
                         ctx.S[q_idx], offset)


def fit(ctx, cfg, fit_idx, val_idx, seed=0, epochs=300, lr=3e-3, wd=1e-3, patience=60, verbose=False,
        eval_every=5, beta_base=0.5):
    model = make_model(ctx, cfg, seed)
    if ctx.prior is not None:
        # residual learning starts exactly at the boosted prior: zero-initialised output layer
        model.P["h2"].data[:] = 0.0
        model.P["h2b"].data[:] = 0.0
    opt = Adam(model.params(), lr=lr, wd=wd)
    coh = ctx.coh
    fit_idx = np.asarray(fit_idx); val_idx = np.asarray(val_idx)
    enc_idx = np.unique(np.concatenate([ctx.ref, fit_idx]))
    pos_of = -np.ones(coh.n, int); pos_of[enc_idx] = np.arange(len(enc_idx))
    best, best_state, wait, hist = np.inf, None, 0, []
    t0 = time.time()
    bs = cfg.get("batch", 128)
    rng_b = np.random.default_rng(seed + 12345)
    use_abs = cfg.get("absloss", True) and ctx.rel
    for ep in range(epochs):
        # (a) historical (stop-gradient) neighbour embeddings and residual messages, refreshed every epoch
        cls_h, tok_h = model.encode(ctx.S[enc_idx], ctx.H[enc_idx], ctx.Dl[enc_idx], training=False)
        rfeat, _ = _msg_feats(model, ctx, cfg, enc_idx, cls_h, tok_h, False)
        cls_h = cls_h.data
        del tok_h
        # (b) mini-batch updates
        perm = rng_b.permutation(fit_idx)
        Ls = []
        for s0 in range(0, len(perm), bs):
            b = perm[s0:s0 + bs]
            cls_b, tok_b = model.encode(ctx.S[b], ctx.H[b], ctx.Dl[b], training=True)
            nb = ctx.nb_all[b]
            yhat = model.forward(cls_b, tok_b, coh.penc[b], Tensor(cls_h[pos_of[nb]]), rfeat[nb], coh.penc[nb],
                                 ctx.sim_all[b], True, ctx.S[b], ctx.offset_obs(b))
            y0 = model.head(cls_b, tok_b, coh.penc[b], True, ctx.S[b], ctx.offset_obs(b)) if (model.graph == "ragat" and beta_base > 0) else None
            if use_abs:
                G, O = Tensor(ctx.G[b]), Tensor(ctx.O[b])
                L = model.loss(yhat * G + O, ctx.YsA[b], ctx.bmhi_CA[b])
                if y0 is not None:
                    L = L + model.loss(y0 * G + O, ctx.YsA[b], ctx.bmhi_CA[b]) * beta_base
            else:
                L = model.loss(yhat, ctx.Ys[b], ctx.bmhi_C[b])
                if y0 is not None:
                    L = L + model.loss(y0, ctx.Ys[b], ctx.bmhi_C[b]) * beta_base
            opt.zero_grad()
            L.backward()
            opt.step()
            Ls.append(float(L.data))
            del cls_b, tok_b, yhat, y0, L
        Lval = float(np.mean(Ls))
        del cls_h, rfeat
        gc.collect()
        if (ep + 1) % eval_every == 0 or ep == epochs - 1:
            yv = predict_std(model, ctx, cfg, val_idx, coh.penc[val_idx])
            if cfg.get("absloss", True) and ctx.rel:
                ya = yv * ctx.G[val_idx] + ctx.O[val_idx]
                dv = ((ya - ctx.YsA[val_idx]) ** 2).mean() + 0.5 * ((((ya - ctx.YsA[val_idx]) * ctx.bmhi_CA[val_idx]).sum(-1)) ** 2).mean()
            else:
                dv = ((yv - ctx.Ys[val_idx]) ** 2).mean() + 0.5 * ((((yv - ctx.Ys[val_idx]) * ctx.bmhi_C[val_idx]).sum(-1)) ** 2).mean()
            hist.append((ep + 1, Lval, float(dv)))
            if verbose:
                print(f"ep {ep+1} train {Lval:.4f} val {dv:.4f} t={time.time()-t0:.1f}s", flush=True)
            if dv < best - 1e-5:
                best, best_state, wait = dv, model.state(), 0
            else:
                wait += eval_every
                if wait >= patience:
                    break
    model.load(best_state)
    model.hist = hist
    model.best_val = best
    model.cfg = cfg
    model.train_time = time.time() - t0
    return model


def predict_std(model, ctx, cfg, q_idx, pq):
    coh = ctx.coh
    q_idx = np.asarray(q_idx)
    enc_idx = np.unique(np.concatenate([ctx.ref, q_idx]))
    pos_of = -np.ones(coh.n, int); pos_of[enc_idx] = np.arange(len(enc_idx))
    cls, tok = model.encode(ctx.S[enc_idx], ctx.H[enc_idx], ctx.Dl[enc_idx], training=False)
    rfeat, _ = _msg_feats(model, ctx, cfg, ctx.ref, gather_rows(cls, pos_of[ctx.ref]),
                          gather_rows(tok, pos_of[ctx.ref]), False)
    y = _batch_forward(model, ctx, q_idx, cls, tok, pos_of, pq, False, rfeat, ctx.offset_for(q_idx, pq))
    return y.data.astype(np.float64)


def predict(model, ctx, q_idx, pq):
    return ctx.to_orig(predict_std(model, ctx, model.cfg, q_idx, pq), np.asarray(q_idx))


class FrozenStudent:
    """Pre-computed encoder outputs and neighbour messages for fast evaluation of many candidate
    prescriptions (used inside the metaheuristic prescription optimiser)."""

    def __init__(self, models, ctx, q_idx):
        self.models, self.ctx = models, ctx
        coh = ctx.coh
        q_idx = np.asarray(q_idx)
        enc_idx = np.unique(np.concatenate([ctx.ref, q_idx]))
        pos_of = -np.ones(coh.n, int); pos_of[enc_idx] = np.arange(len(enc_idx))
        self.q_idx = q_idx
        self.cache = []
        nb = ctx.nb_all[q_idx]
        for m in models:
            cls, tok = m.encode(ctx.S[enc_idx], ctx.H[enc_idx], ctx.Dl[enc_idx], training=False)
            rfeat, _ = _msg_feats(m, ctx, m.cfg, ctx.ref, gather_rows(cls, pos_of[ctx.ref]),
                                  gather_rows(tok, pos_of[ctx.ref]), False)
            self.cache.append(dict(cls=cls.data[pos_of[q_idx]], tok=tok.data[pos_of[q_idx]],
                                   nb_c=cls.data[pos_of[nb]], nb_r=rfeat[nb]))
        self.nb_p = coh.penc[nb]; self.nb_s = ctx.sim_all[q_idx]

    def eval(self, which, X):
        """which: (m,) positions into q_idx; X: (m,12) prescriptions -> (M, m, 9) outcomes (orig units)."""
        ctx = self.ctx
        pq = ctx.coh.penc_for(self.q_idx[which], X)
        outs = []
        for m, c in zip(self.models, self.cache):
            y = m.forward(Tensor(c["cls"][which]), Tensor(c["tok"][which]), pq, Tensor(c["nb_c"][which]),
                          c["nb_r"][which], self.nb_p[which], self.nb_s[which], training=False,
                          s_wide=ctx.S[self.q_idx[which]], offset=ctx.offset_for(self.q_idx[which], pq))
            outs.append(ctx.to_orig(y.data.astype(np.float64), self.q_idx[which]))
        return np.stack(outs)


# ============================================================================ boosted-tree branch + stacking
class TreeModel:
    """Gradient-boosted tree branch trained on [static phenotype, prescription encoding] with baseline-scaled
    targets. Used as the tabular expert that CHRONO-RAGAT is stacked with."""

    def __init__(self, coh, train_idx, seed=0):
        from sklearn.ensemble import HistGradientBoostingRegressor
        from sklearn.multioutput import MultiOutputRegressor
        self.coh = coh
        self.m = MultiOutputRegressor(HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, random_state=seed))
        self.m.fit(np.concatenate([coh.S, coh.penc], 1)[train_idx], (coh.Y / coh.base_scale)[train_idx])

    def predict(self, idx, pq, coh=None):
        coh = coh or self.coh
        idx = np.asarray(idx)
        return self.m.predict(np.concatenate([coh.S[idx], pq], 1)) * coh.base_scale[idx]


def fit_blend(y_tree, y_net, y_obs, grid=np.linspace(0, 1, 21), passes=3):
    """Per-outcome convex stacking weights omega_t (weight of the tree expert), fitted on validation students by
    coordinate descent on a joint criterion: variance-normalised per-outcome MSE plus normalised composite (BMHI) MSE."""
    from simulator import bmhi
    T = y_obs.shape[1]
    var = y_obs.var(0) + 1e-12
    b_obs = bmhi(y_obs); vb = b_obs.var() + 1e-12

    def crit(w):
        yb = w * y_tree + (1 - w) * y_net
        return (((yb - y_obs) ** 2).mean(0) / var).sum() / T + ((bmhi(yb) - b_obs) ** 2).mean() / vb

    w = np.full(T, 0.5)
    for _ in range(passes):
        for t in range(T):
            best, bv = w[t], np.inf
            for a in grid:
                w[t] = a
                v = crit(w)
                if v < bv - 1e-12:
                    best, bv = a, v
            w[t] = best
    return w


def blend(w, y_tree, y_net):
    return w * y_tree + (1 - w) * y_net
