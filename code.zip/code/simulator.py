"""
CHRONO-SIM: a physiology-grounded in-silico cohort of college students.

Generates
  * baseline phenotype (anthropometry, fitness, chronotype, sleep, diet, metabolic panel)
  * 14-day hourly actigraphy (336 h) from a gated two-harmonic cosinor rest-activity model
  * 14-day daily behaviour logs (sleep, steps, MVPA, meal timing, energy intake, caffeine)
  * 12-week responses to a 12-dimensional exercise + diet prescription

The structural response model encodes published, directionally established effects:
  - exercise phase-response curve (advances with morning/afternoon, delays near DLMO)
  - time-of-day modulation of exercise effects on insulin sensitivity
  - early vs late time-restricted eating (TRE) effects on insulin resistance
  - caffeine-induced circadian delay; late vigorous exercise impairs sleep efficiency
  - adherence that decays with chronotype misalignment, burden and stress
  - latent metabotype clusters that modulate responsiveness (partly hidden)
Magnitudes are calibrated to the ranges reported in the trials cited in the paper.
All variables are SIMULATED; no human data are used.
"""
import numpy as np
import pandas as pd

# ---------------------------------------------------------------- decision space
DEC_NAMES = ["ex_time", "ex_intensity", "ex_duration", "ex_freq", "hiit_frac",
             "tre_window", "first_meal", "protein_pct", "carb_pct", "fiber_g",
             "caffeine_cutoff", "kcal_deficit"]
DEC_LB = np.array([6.0, 40.0, 20.0, 2.0, 0.0, 8.0, 6.0, 12.0, 35.0, 15.0, 10.0, 0.0])
DEC_UB = np.array([22.0, 85.0, 60.0, 6.0, 1.0, 14.0, 12.0, 30.0, 60.0, 40.0, 20.0, 20.0])
DEC_UNITS = ["h (clock)", "%HRR", "min/session", "sessions/wk", "fraction", "h/day",
             "h (clock)", "% energy", "% energy", "g/day", "h (clock)", "% energy"]

OUTCOMES = ["d_homa", "d_fg", "d_tg", "d_vo2", "d_is", "d_ra", "d_sjl", "d_se", "d_rmssd"]
OUT_LABELS = ["ΔHOMA-IR", "ΔFasting glucose (mg/dL)", "ΔTriglycerides (mg/dL)",
              "ΔVO2max (mL/kg/min)", "ΔInterdaily stability", "ΔRelative amplitude",
              "ΔSocial jetlag (h)", "ΔSleep efficiency (%)", "ΔRMSSD (ms)"]
# sign: +1 if an increase is beneficial; scale = minimal clinically important difference
OUT_SIGN = np.array([-1, -1, -1, 1, 1, 1, -1, 1, 1], dtype=float)
OUT_SCALE = np.array([0.5, 4.0, 15.0, 3.0, 0.05, 0.05, 0.5, 3.0, 5.0])
OUT_W = np.array([0.20, 0.10, 0.10, 0.15, 0.10, 0.10, 0.10, 0.10, 0.05])


def bmhi(Y):
    """Biorhythm-Metabolic Health Index improvement (weighted MCID-scaled sum)."""
    Y = np.atleast_2d(Y)
    return ((Y * OUT_SIGN / OUT_SCALE) * OUT_W).sum(-1)


def circ_diff(a, b):
    """signed circular difference a-b on a 24 h clock, in (-12, 12]."""
    return (a - b + 12.0) % 24.0 - 12.0


# ---------------------------------------------------------------- cohort
def generate_cohort(n, seed=0, n_clusters=4):
    rng = np.random.default_rng(seed)
    sex = rng.binomial(1, 0.48, n)                     # 1 = male
    age = np.round(rng.uniform(18, 24.5, n), 1)
    # latent metabotype clusters (not observed directly)
    clus = rng.choice(n_clusters, n, p=[0.35, 0.25, 0.25, 0.15])
    c_bmi = np.array([0.0, 2.2, -0.8, 4.0])[clus]
    c_si = np.array([0.3, -0.4, 0.5, -1.0])[clus]          # insulin sensitivity shift
    c_resp = np.array([1.0, 1.35, 0.8, 1.15])[clus]         # metabolic responsiveness
    c_chrono = np.array([0.0, 0.5, -0.4, 0.7])[clus]
    # metabotype biochemical / dietary signatures (partially observable)
    c_tg = np.array([0.0, 0.25, -0.15, 0.35])[clus]
    c_hdl = np.array([0.0, -5.0, 5.0, -8.0])[clus]
    c_sugar = np.array([0.0, 20.0, -10.0, 25.0])[clus]
    c_fiber = np.array([0.0, -3.0, 4.0, -4.0])[clus]

    msf = np.clip(rng.normal(5.0 + c_chrono, 1.0), 2.5, 9.0)          # mid-sleep free days (clock h)
    stress = rng.normal(0, 1, n) + 0.25 * (clus == 3)
    sleep_reg = np.clip(rng.beta(4, 2, n) - 0.08 * (msf - 5) - 0.05 * stress, 0.15, 0.98)
    amp_lat = np.exp(rng.normal(0, 0.18, n)) * (0.6 + 0.5 * sleep_reg)  # circadian robustness
    dlmo = msf - 6.3 + rng.normal(0, 0.35, n)                          # dim-light melatonin onset
    sjl = np.clip(0.9 + 0.55 * (msf - 4.5) + 0.3 * (1 - sleep_reg) * 2 + rng.normal(0, 0.35, n), 0.0, 4.5)
    msw = msf - sjl                                                      # mid-sleep work days
    sleep_dur_w = np.clip(7.3 - 0.35 * sjl - 0.2 * stress + rng.normal(0, 0.45, n), 4.5, 9.5)
    sleep_dur_f = np.clip(sleep_dur_w + 0.6 * sjl + rng.normal(0, 0.4, n), 5.0, 11.0)
    onset_w = (msw - sleep_dur_w / 2) % 24
    onset_f = (msf - sleep_dur_f / 2) % 24
    wake_w = (onset_w + sleep_dur_w) % 24
    se = np.clip(88 - 2.0 * stress - 3.0 * (1 - sleep_reg) + rng.normal(0, 3, n), 65, 97)

    bmi = np.clip(np.where(sex == 1, 22.8, 21.7) + c_bmi + rng.normal(0, 2.6, n), 16.5, 39)
    mass = bmi * (np.where(sex == 1, 1.76, 1.63) + rng.normal(0, 0.05, n)) ** 2
    waist = np.where(sex == 1, 80, 72) + 2.1 * (bmi - 22) + rng.normal(0, 3, n)
    mvpa = np.clip(rng.lognormal(np.log(120), 0.55, n) - 15 * c_bmi, 5, 600)    # min/week
    vo2 = np.clip(np.where(sex == 1, 45, 37) - 0.65 * (bmi - 22) + 0.025 * (mvpa - 120)
                  + rng.normal(0, 3.5, n), 22, 65)
    rhr = np.clip(78 - 0.45 * (vo2 - 40) + 1.5 * stress + rng.normal(0, 4, n), 48, 100)
    rmssd = np.clip(np.exp(np.log(42) + 0.012 * (vo2 - 40) - 0.08 * stress - 0.01 * (age - 20)
                           + rng.normal(0, 0.25, n)), 12, 120)

    first_meal_h = np.clip(wake_w + rng.normal(1.2, 0.8, n), 6, 13)
    eat_win = np.clip(rng.normal(12.8, 1.4, n) + 0.25 * (msf - 5), 9, 17)
    last_meal_h = first_meal_h + eat_win
    kcal = np.clip(np.where(sex == 1, 2550, 1950) + 30 * (bmi - 22) + rng.normal(0, 260, n), 1300, 4000)
    carb = np.clip(rng.normal(51, 6, n), 35, 68)
    prot = np.clip(rng.normal(16, 3, n), 9, 30)
    fat = 100 - carb - prot
    fiber = np.clip(rng.normal(18, 5, n) + c_fiber, 6, 40)
    sugar = np.clip(rng.normal(62, 20, n) + 0.5 * (carb - 51) + c_sugar, 10, 160)
    caff_last = np.clip(rng.normal(15.5, 2.5, n) + 0.3 * (msf - 5), 8, 23)
    screen_bed = np.clip(rng.normal(55, 25, n), 0, 180)

    # latent insulin sensitivity (z-scale) and metabolic panel
    si = (c_si - 0.18 * (bmi - 22) + 0.04 * (vo2 - 40) - 0.15 * sjl - 0.12 * (7 - sleep_dur_w)
          - 0.004 * (last_meal_h - 20) * 10 + 0.25 * amp_lat + rng.normal(0, 0.35, n))
    fg = np.clip(86 - 4.2 * si + rng.normal(0, 3.5, n), 68, 126)
    ins = np.clip(np.exp(np.log(7.2) - 0.33 * si + rng.normal(0, 0.18, n)), 2, 40)
    homa = fg * ins / 405.0
    tg = np.clip(np.exp(np.log(85) + c_tg - 0.18 * si + 0.006 * (carb - 51) + 0.003 * (sugar - 62)
                        + rng.normal(0, 0.22, n)), 35, 400)
    hdl = np.clip(np.where(sex == 1, 50, 60) + c_hdl + 3.5 * si + 0.1 * (vo2 - 40) + rng.normal(0, 7, n), 25, 100)
    trainability = np.clip(rng.normal(1.0, 0.22, n) * (0.85 + 0.15 * amp_lat), 0.3, 1.8)

    base = pd.DataFrame(dict(
        sid=np.arange(n), sex=sex, age=age, bmi=bmi, body_mass=mass, waist=waist,
        vo2max=vo2, rhr=rhr, rmssd=rmssd, mvpa_wk=mvpa, msf_sc=msf, social_jetlag=sjl,
        sleep_dur_week=sleep_dur_w, sleep_dur_free=sleep_dur_f, sleep_onset_week=onset_w,
        wake_week=wake_w, sleep_eff=se, stress_pss=np.clip(20 + 6 * stress, 0, 40),
        first_meal=first_meal_h, eating_window=eat_win, kcal=kcal, carb_pct=carb,
        protein_pct=prot, fat_pct=fat, fiber_g=fiber, sugar_g=sugar, caffeine_last=caff_last,
        screen_before_bed=screen_bed, fasting_glucose=fg, insulin=ins, homa_ir=homa,
        triglycerides=tg, hdl=hdl))
    latent = pd.DataFrame(dict(sid=np.arange(n), cluster=clus, resp=c_resp, dlmo=dlmo,
                               amp_lat=amp_lat, sleep_reg=sleep_reg, si=si, stress_z=stress,
                               trainability=trainability, onset_free=onset_f, msw=msw))
    return base, latent


# ---------------------------------------------------------------- actigraphy & logs
def generate_actigraphy(base, latent, seed=0, days=14):
    rng = np.random.default_rng(seed + 7)
    n = len(base)
    T = days * 24
    act = np.zeros((n, T))
    logs = []
    for i in range(n):
        b, l = base.iloc[i], latent.iloc[i]
        reg = l.sleep_reg
        for d in range(days):
            weekend = (d % 7) in (5, 6)
            on = (l.onset_free if weekend else b.sleep_onset_week) + rng.normal(0, 0.25 + 1.6 * (1 - reg))
            dur = (b.sleep_dur_free if weekend else b.sleep_dur_week) + rng.normal(0, 0.3 + 0.8 * (1 - reg))
            dur = float(np.clip(dur, 3.5, 12))
            acro = (l.dlmo + 15.5 + rng.normal(0, 0.6)) % 24   # activity acrophase ~ 13-14 h after DLMO... afternoon
            mvpa_today = max(0.0, rng.normal(b.mvpa_wk / 7, b.mvpa_wk / 14))
            ex_hour = int(np.clip(rng.normal((b.msf_sc + 11.5) % 24, 2.0), 6, 22))
            steps = 0.0
            for h in range(24):
                t = d * 24 + h
                clock = h + 0.5
                # asleep?  sleep window starting at `on` (could be after midnight of previous day)
                rel = (clock - on) % 24
                asleep = rel < dur
                cos1 = np.cos(2 * np.pi * (clock - acro) / 24)
                cos2 = np.cos(4 * np.pi * (clock - acro - 2) / 24)
                lvl = 220 * l.amp_lat * (1 + 0.75 * cos1 + 0.15 * cos2) + 60
                if asleep:
                    lvl = rng.gamma(1.2, 8) * (1.3 - reg)
                else:
                    lvl = lvl * rng.lognormal(0, 0.35)
                    if h == ex_hour and mvpa_today > 5:
                        lvl += 9 * min(mvpa_today, 90)
                act[i, t] = lvl
                if not asleep:
                    steps += lvl * 2.6
            fm = b.first_meal + (1.0 if weekend else 0) * 0.8 * b.social_jetlag / 2 + rng.normal(0, 0.5 + (1 - reg))
            win = b.eating_window + rng.normal(0, 0.8)
            logs.append(dict(sid=int(b.sid), day=d + 1, weekend=int(weekend),
                             sleep_onset=round(on % 24, 2), sleep_duration=round(dur, 2),
                             steps=int(max(500, steps * rng.lognormal(0, 0.1))),
                             mvpa_min=round(mvpa_today, 1), first_meal=round(fm, 2),
                             last_meal=round(fm + win, 2),
                             kcal=int(b.kcal * rng.lognormal(0, 0.12)),
                             caffeine_last=round(b.caffeine_last + rng.normal(0, 1.0), 2)))
    return act, pd.DataFrame(logs)


def nonparametric_circadian(act):
    """IS, IV, RA, L5, M10, M10 onset (Van Someren non-parametric rest-activity metrics)."""
    n, T = act.shape
    days = T // 24
    x = act.reshape(n, days, 24)
    hourly = x.mean(1)
    gm = act.mean(1, keepdims=True)
    IS =(T * ((hourly - gm) ** 2).sum(1)) / (24 * ((act - gm) ** 2).sum(1))
    IV = (T * (np.diff(act, axis=1) ** 2).sum(1)) / ((T - 1) * ((act - gm) ** 2).sum(1))
    ext = np.concatenate([hourly, hourly], 1)
    m10 = np.stack([ext[:, s:s + 10].mean(1) for s in range(24)], 1)
    l5 = np.stack([ext[:, s:s + 5].mean(1) for s in range(24)], 1)
    M10, L5 = m10.max(1), l5.min(1)
    RA = (M10 - L5) / (M10 + L5)
    return pd.DataFrame(dict(IS=IS, IV=IV, RA=RA, L5=L5, M10=M10,
                             M10_onset=m10.argmax(1).astype(float), L5_onset=l5.argmin(1).astype(float)))


# ---------------------------------------------------------------- prescriptions
def repair(X, bmi):
    """Project decision vectors onto the feasible/safe set (used by every optimizer)."""
    X = np.clip(X, DEC_LB, DEC_UB)
    X = X.copy()
    # fat share must stay within 20-40 % energy
    fat = 100 - X[:, 7] - X[:, 8]
    over = fat < 20
    X[over, 8] = 80 - X[over, 7]
    under = fat > 40
    X[under, 8] = 60 - X[under, 7]
    X[:, 8] = np.clip(X[:, 8], DEC_LB[8], DEC_UB[8])
    # energy deficit allowed only when BMI > 22 (no restriction for lean students)
    maxdef = np.clip((np.asarray(bmi) - 22.0) * 4.0, 0, 20)
    X[:, 11] = np.minimum(X[:, 11], maxdef)
    return X


def constraint_violation(X, base_row_onset):
    """Soft constraints: pre-sleep fast >= 2 h; vigorous exercise ends >= 2 h before sleep;
    weekly MVPA volume >= 90 min and <= 300 min."""
    onset = np.asarray(base_row_onset) % 24
    onset = np.where(onset < 12, onset + 24, onset)
    last_meal = X[:, 6] + X[:, 5]
    v1 = np.maximum(0, last_meal - (onset - 2.0))
    ex_end = X[:, 0] + X[:, 2] / 60
    v2 = np.maximum(0, ex_end - (onset - 2.0)) * (X[:, 1] > 70)
    vol = X[:, 3] * X[:, 2]
    v3 = np.maximum(0, 90 - vol) / 30 + np.maximum(0, vol - 300) / 30
    return v1 + v2 + v3


def sample_prescriptions(n, bmi, rng):
    X = DEC_LB + rng.random((n, len(DEC_LB))) * (DEC_UB - DEC_LB)
    return repair(X, bmi)


def response(base, latent, X, rng=None, noise=True):
    """12-week outcome changes for prescriptions X (n x 12), row-aligned with base/latent.
    Returns (Y (n x 9), adherence (n,))."""
    b, l = base, latent
    n = len(b)
    ex_t, inten, dur, freq, hiit, win, fm, prot, carb, fib, caf, deff = [X[:, j] for j in range(12)]
    msf, dlmo = b.msf_sc.values, l.dlmo.values
    stress = l.stress_z.values
    onset = b.sleep_onset_week.values
    onset24 = np.where(onset < 12, onset + 24, onset)

    # ---------- adherence (behavioural feasibility)
    pref_ex = msf + 11.0                     # preferred training time ~ 11 h after mid-sleep
    mis_ex = np.abs(circ_diff(ex_t, pref_ex))
    mis_fm = np.maximum(0, b.wake_week.values + 0.5 - fm) * 1.2 + np.maximum(0, fm - (b.first_meal.values + 2.5)) * 0.4
    stress_pos = np.clip(stress, 0, None)
    low_fit = np.clip((42 - b.vo2max.values) / 8, 0, 2)
    clus = l.cluster.values
    burden = (0.03 * (inten - 60) + 0.40 * (freq - 3.5) + 0.018 * (dur - 40) + 0.5 * hiit * (1 + low_fit)) \
        * (1 + 0.45 * stress_pos + 0.35 * low_fit)
    diet_burden = (0.30 * np.maximum(0, 12 - win) + 0.04 * np.maximum(0, fib - 30) + 0.05 * deff
                   + 0.04 * np.maximum(0, prot - 24)) * (1 + 0.4 * stress_pos)
    logit = 2.6 - 0.10 * mis_ex ** 2 - 0.55 * mis_fm - burden - diet_burden - 0.30 * stress \
        + 0.6 * (l.sleep_reg.values - 0.6)
    adh = 1 / (1 + np.exp(-logit))
    adh_ex = np.clip(adh + 0.1 * (1 - np.abs(circ_diff(ex_t, pref_ex)) / 6), 0.05, 1.0)
    adh_diet = np.clip(adh - 0.08 * np.maximum(0, 11 - win), 0.05, 1.0)
    if noise:
        adh_ex = np.clip(adh_ex + rng.normal(0, 0.06, n), 0.02, 1.0)
        adh_diet = np.clip(adh_diet + rng.normal(0, 0.06, n), 0.02, 1.0)

    vol = freq * dur * adh_ex                     # effective min/week
    vol_eff = 1 - np.exp(-vol / 160)
    int_f = (inten / 100) * (1 + 0.45 * hiit)
    # chronotype-aligned performance: training near individual peak boosts effective intensity
    perf = 1 + 0.15 * np.exp(-(circ_diff(ex_t, msf + 11.5) / 4.0) ** 2)

    # ---------- circadian phase shift (h, + = advance)
    tau = (ex_t - dlmo) % 24                       # hours after DLMO
    prc = 0.55 * np.cos(2 * np.pi * (tau - 12.5) / 24) + 0.10
    dphi_ex = 1.1 * prc * adh_ex * np.sqrt(freq / 4) * np.sqrt(dur / 40) * (0.6 + 0.6 * inten / 100)
    dphi_meal = 0.30 * (b.first_meal.values - fm) * adh_diet
    caf_gap = onset24 - caf                          # hours between last caffeine and sleep
    dphi_caf = -0.18 * np.maximum(0, 8 - caf_gap) * adh_diet + 0.05 * np.maximum(0, b.caffeine_last.values - caf) * adh_diet
    dphi = dphi_ex + dphi_meal + dphi_caf
    lateness = np.clip((msf - 3.5) / 2.5, 0, 1.6)
    d_sjl = -0.45 * dphi * lateness - 0.25 * adh * (freq / 6) * (1 - np.abs(circ_diff(ex_t, pref_ex)) / 12) \
        + 0.15 * np.maximum(0, -dphi)

    # ---------- rest-activity rhythm
    day_ex = np.exp(-(circ_diff(ex_t, 14) / 5.0) ** 2)
    ex_end = ex_t + dur / 60
    late_vig = (np.maximum(0, ex_end - (onset24 - 2.5)) > 0) * np.clip((inten - 65) / 20, 0, 1) * adh_ex
    d_is = 0.035 * adh_ex * (freq / 5) + 0.03 * adh_diet * np.clip((13 - win) / 5, -0.3, 1) \
        - 0.02 * np.abs(dphi_caf) + 0.02 * np.maximum(0, -d_sjl)
    d_ra = 0.05 * vol_eff * (0.5 + day_ex) * l.amp_lat.values ** 0.5 - 0.035 * late_vig \
        - 0.012 * np.maximum(0, 8 - caf_gap) * adh_diet
    d_se = 2.0 * np.sqrt(vol / 150) - 3.5 * late_vig - 0.5 * np.maximum(0, 8 - caf_gap) * adh_diet \
        + 1.2 * np.maximum(0, -d_sjl) + 0.8 * adh_diet * np.clip((onset24 - (fm + win)) - 3, -2, 2) / 2 \
        - 1.2 * hiit * stress_pos * adh_ex

    # ---------- cardiorespiratory fitness
    base_gap = np.clip((55 - b.vo2max.values) / 15, 0.2, 2.0)
    athletic = (clus == 2).astype(float)
    d_vo2 = 4.5 * l.trainability.values * vol_eff * int_f * perf * (0.6 + 0.4 * base_gap) \
        * (1 - 0.012 * np.maximum(0, 48 - carb) * athletic * adh_diet) + 0.04 * (prot - 16) * athletic * adh_diet

    # ---------- metabolic
    ir_z = np.clip(-l.si.values, -2, 3)            # higher = more insulin resistant
    t_met = 1 + 0.45 * np.clip(ir_z, 0, None) * np.exp(-(circ_diff(ex_t, 16.5) / 2.8) ** 2) \
        - 0.20 * np.clip(ir_z, 0, None) * np.exp(-(circ_diff(ex_t, 7.0) / 1.8) ** 2)
    ex_met = vol_eff * int_f * perf * t_met * (0.6 + 0.4 * hiit)
    last_meal = fm + win
    early = np.clip((20.5 - last_meal) / 4.5, -0.6, 1.0)
    tre = adh_diet * np.clip((14 - win) / 6, 0, 1) * (0.5 + 0.8 * early)
    meal_mis = adh_diet * np.maximum(0, last_meal - (onset24 - 3))     # eating close to biological night
    carbsens = np.isin(clus, [1, 3]).astype(float)
    diet_q = adh_diet * (0.012 * (fib - 18) + 0.010 * (prot - 16) - 0.010 * (1 + 1.5 * carbsens - 0.8 * athletic) * (carb - 50))
    deficit = adh_diet * deff / 10
    resp = l.resp.values
    rel = -(0.30 * ex_met + 0.18 * tre + 0.10 * deficit + 0.6 * diet_q - 0.06 * meal_mis
            + 0.05 * np.maximum(0, -d_sjl)) * resp
    d_homa = b.homa_ir.values * rel
    d_fg = 9.0 * rel * (1 + 0.3 * np.clip(ir_z, 0, None)) - 0.6 * dphi_ex.clip(0, None)
    d_tg = b.triglycerides.values * (-(0.16 * ex_met + 0.09 * tre + 0.07 * deficit) * resp
                                      - adh_diet * 0.006 * (50 - carb) - adh_diet * 0.004 * (fib - 18)
                                      + 0.03 * meal_mis)
    d_rmssd = b.rmssd.values * (0.16 * vol_eff * (0.7 + 0.3 * day_ex) - 0.08 * late_vig
                                + 0.03 * np.maximum(0, -d_sjl) - 0.03 * np.clip((inten - 75) / 10, 0, 1) * hiit
                                - 0.06 * hiit * stress_pos * adh_ex)

    Y = np.stack([d_homa, d_fg, d_tg, d_vo2, d_is, d_ra, d_sjl, d_se, d_rmssd], 1)
    if noise:
        sd = np.array([0.18, 2.2, 7.0, 1.0, 0.018, 0.018, 0.22, 1.4, 2.5])
        Y = Y + rng.normal(0, 1, Y.shape) * sd
    return Y, adh


def no_intervention(base, latent, rng):
    """Semester drift without a structured programme (control arm)."""
    n = len(base)
    st = latent.stress_z.values
    Y = np.stack([
        base.homa_ir.values * (0.03 + 0.02 * st),
        0.6 + 0.4 * st,
        2.0 + 1.5 * st,
        -0.3 + np.zeros(n),
        -0.004 - 0.004 * st,
        -0.004 + np.zeros(n),
        0.05 + 0.05 * st,
        -0.4 - 0.3 * st,
        -0.8 - 0.5 * st], 1)
    sd = np.array([0.18, 2.2, 7.0, 1.0, 0.018, 0.018, 0.22, 1.4, 2.5])
    return Y + rng.normal(0, 1, Y.shape) * sd


def guideline_prescription(base):
    """Generic guideline: 150 min/wk moderate (60 %HRR, 30 min x 5) at 17:00, 12-h eating window
    from 08:00, 18 % protein / 50 % carbohydrate / 25 g fibre, caffeine before 14:00,
    deficit only per BMI rule (half of allowed)."""
    n = len(base)
    X = np.tile([17.0, 60, 30, 5, 0, 12, 8, 18, 50, 25, 14, 0], (n, 1)).astype(float)
    X[:, 11] = np.clip((base.bmi.values - 22) * 2, 0, 10)
    return repair(X, base.bmi.values)


def rule_chrono_prescription(base):
    """Heuristic chronotype-matched plan (expert rules, no learning)."""
    n = len(base)
    msf = base.msf_sc.values
    X = np.zeros((n, 12))
    X[:, 0] = np.clip(msf + 10.5, 8, 19)                     # train in biological afternoon
    X[:, 1] = 65; X[:, 2] = 35; X[:, 3] = 4; X[:, 4] = 0.25
    X[:, 5] = 10
    X[:, 6] = np.clip(base.wake_week.values + 1.0, 6, 12)
    X[:, 7] = 20; X[:, 8] = 48; X[:, 9] = 28
    X[:, 10] = np.clip(base.sleep_onset_week.values % 24 - 8, 10, 16)
    X[:, 10] = np.where(base.sleep_onset_week.values % 24 < 12, 14, X[:, 10])
    X[:, 11] = np.clip((base.bmi.values - 22) * 2.5, 0, 12)
    return repair(X, base.bmi.values)
