"""Experiment 2: hyper-parameter optimisation of CHRONO-RAGAT with CLO-GWO vs. random search
(equal budget of 30 reduced-fidelity training runs)."""
import os, sys, json, time
import numpy as np, pandas as pd
from train import Cohort, Context, fit
from optimizers import clo_gwo, random_search

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
NAMES = ["log10_lr", "d", "dropout", "log10_wd", "k", "lam_bmhi", "beta_base", "log2_batch"]
LB = np.array([-3.5, 16, 0.05, -4.0, 5, 0.1, 0.1, 5.0])
UB = np.array([-2.5, 48, 0.35, -2.0, 20, 1.5, 1.0, 7.0])
BUDGET, POP = 30, 6


def decode(x):
    return dict(lr=10 ** x[0], d=int(8 * round(x[1] / 8)), dropout=float(x[2]), wd=10 ** x[3], k=int(round(x[4])),
                lam_bmhi=float(x[5]), beta_base=float(x[6]), batch=int(2 ** round(x[7])))


def splits(N, seed=0):
    idx = np.arange(N); rng = np.random.default_rng(seed); rng.shuffle(idx)
    return idx[:int(.7 * N)], idx[int(.7 * N):int(.8 * N)], idx[int(.8 * N):]


def main(method):
    coh = Cohort("dev_")
    fit_idx, val_idx, te = splits(coh.n)
    rng = np.random.default_rng(5)
    sub_fit = rng.choice(fit_idx, 960, replace=False)          # reduced fidelity
    sub_val = rng.choice(val_idx, 240, replace=False)
    ctx_cache = {}
    log = []

    def evaluate(x):
        h = decode(x)
        if h["k"] not in ctx_cache:
            ctx_cache[h["k"]] = Context(coh, sub_fit, k=h["k"])
        ctx = ctx_cache[h["k"]]
        t = time.time()
        m = fit(ctx, dict(d=h["d"], dropout=h["dropout"], lam_bmhi=h["lam_bmhi"], batch=h["batch"]), sub_fit, sub_val, seed=0,
                epochs=60, lr=h["lr"], wd=h["wd"], patience=12, eval_every=2, beta_base=h["beta_base"])
        log.append(dict(method=method, eval=len(log) + 1, val_loss=float(m.best_val), time_s=time.time() - t, **h))
        print(method, len(log), round(m.best_val, 4), h, flush=True)
        pd.DataFrame(log).to_csv(os.path.join(RES, f"hpo_log_{method}.csv"), index=False)
        return m.best_val

    def f(X):
        S, P, D = X.shape
        return np.array([[evaluate(X[s, p]) for p in range(P)] for s in range(S)])

    alg = clo_gwo if method == "CLO-GWO" else random_search
    method_tag = method
    bx, bf, cur = alg(f, LB, UB, 1, POP, BUDGET, np.random.default_rng(11))
    best = decode(bx[0])
    json.dump(dict(method=method, best_val=float(bf[0]), best=best), open(os.path.join(RES, f"hpo_best_{method}.json"), "w"),
              indent=2)
    print("BEST", method, bf, best)


if __name__ == "__main__":
    main(sys.argv[1])
