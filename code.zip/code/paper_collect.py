"""Collect every number used in the manuscript into one dictionary R (also saved as results/paper_numbers.json)."""
import os, json, pickle
import numpy as np, pandas as pd
from paper_tables import prediction_table, ablation_table, RES, RAW

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def collect():
    R = {}
    R["n_dev"] = len(pd.read_csv(os.path.join(RAW, "dev_baseline_phenotype.csv")))
    R["n_trial"] = len(pd.read_csv(os.path.join(RAW, "trial_baseline_phenotype.csv")))
    # benchmark
    rk = pd.read_csv(os.path.join(RES, "benchmark_friedman_ranks.csv"), index_col=0).iloc[:, 0]
    R["bench_rank"] = rk.to_dict()
    R["bench_friedman"] = json.load(open(os.path.join(RES, "benchmark_friedman.json")))
    w = pd.read_csv(os.path.join(RES, "benchmark_wilcoxon.csv"))
    R["bench_wtl"] = {a: dict(w[w.vs == a].result.value_counts()) for a in w.vs.unique()}
    ab = pd.read_csv(os.path.join(RES, "benchmark_ablation_summary.csv"), index_col=0)
    base = ab["CLO-GWO"]
    R["bench_abl_worse"] = {c: int((ab[c] > base * 1.0000001).sum()) for c in ab.columns if c != "CLO-GWO"}
    R["bench_abl_ratio"] = {c: float(np.exp(np.mean(np.log((ab[c] + 1e-12) / (base + 1e-12))))) for c in ab.columns if c != "CLO-GWO"}
    s = pd.read_csv(os.path.join(RES, "benchmark_summary.csv"))
    R["bench_best_count"] = s.loc[s.groupby("func")["mean"].idxmin()].alg.value_counts().to_dict()
    # HPO
    for m in ["CLO-GWO", "Random"]:
        p = os.path.join(RES, f"hpo_best_{m}.json")
        if os.path.exists(p):
            R[f"hpo_{m}"] = json.load(open(p))
            lg = pd.read_csv(os.path.join(RES, f"hpo_log_{m}.csv"))
            R[f"hpo_{m}_n"] = len(lg)
            R[f"hpo_{m}_evals_to_best"] = int(lg.val_loss.idxmin() + 1)
            R[f"hpo_{m}_median"] = float(lg.val_loss.median())
            R[f"hpo_{m}_time"] = float(lg.time_s.sum())
    # CV prediction
    rows = prediction_table()
    R["cv"] = {r["name"]: {k: (float(np.nanmean(v)), float(np.nanstd(v, ddof=1)) if len(v) > 1 else 0.0)
                          for k, v in r.items() if k != "name"} for r in rows}
    tab_abl, abl = ablation_table()
    R["abl"] = abl.set_index("name").to_dict("index") if len(abl) else {}
    p = os.path.join(RES, "final_ensemble_holdout_metrics.json")
    if os.path.exists(p):
        R["holdout"] = json.load(open(p))
    # prescription
    p = os.path.join(RES, "prescription_results.csv")
    if os.path.exists(p):
        df = pd.read_csv(p).set_index("strategy")
        R["presc"] = df.to_dict("index")
        R["presc_tests"] = pd.read_csv(os.path.join(RES, "prescription_paired_tests.csv")).set_index("vs").to_dict("index")
        R["kappa"] = pd.read_csv(os.path.join(RES, "kappa_sensitivity.csv")).to_dict("records")
        R["perm"] = pd.read_csv(os.path.join(RES, "prescription_permutation_importance.csv")).to_dict("records")
        sol = pickle.load(open(os.path.join(RES, "prescription_solutions.pkl"), "rb"))
        b = pd.read_csv(os.path.join(RAW, "dev_baseline_phenotype.csv")).iloc[sol["q"]]
        lat = pd.read_csv(os.path.join(RAW, "dev_latent_ground_truth.csv")).iloc[sol["q"]]
        ai, orc = sol["sols"]["CLO-GWO"], sol["sols"]["Oracle"]
        cor = lambda a, b_: float(np.corrcoef(a, b_)[0, 1])
        R["pers"] = dict(r_time_msf_ai=cor(b.msf_sc, ai[:, 0]), r_time_msf_or=cor(b.msf_sc, orc[:, 0]),
                         r_int_stress_ai=cor(lat.stress_z, ai[:, 1]), r_int_stress_or=cor(lat.stress_z, orc[:, 1]),
                         r_hiit_stress_ai=cor(lat.stress_z, ai[:, 4]), r_fm_wake_ai=cor(b.wake_week, ai[:, 6]),
                         r_def_bmi_ai=cor(b.bmi, ai[:, 11]), slope_time_msf_ai=float(np.polyfit(b.msf_sc, ai[:, 0], 1)[0]),
                         slope_time_msf_or=float(np.polyfit(b.msf_sc, orc[:, 0], 1)[0]),
                         mean_ai=dict(zip(["ex_time", "ex_intensity", "ex_duration", "ex_freq", "hiit", "window", "first_meal",
                                           "protein", "carb", "fiber", "caffeine", "deficit"], ai.mean(0).tolist())),
                         sd_ai=ai.std(0).tolist(), deficit_lean=float(ai[b.bmi.values <= 22, 11].max()) if (b.bmi.values <= 22).any() else 0.0,
                         mae_time_vs_oracle=float(np.mean(np.abs(((ai[:, 0] - orc[:, 0] + 12) % 24) - 12))))
        land = pd.read_csv(os.path.join(RES, "timing_landscape.csv"))
        lr = {}
        for sid, g in land.groupby("student", sort=False):
            lr[int(sid)] = dict(msf=float(g.msf.iloc[0]), argmax_pred=float(g.ex_time.values[g.pred_mu.values.argmax()]),
                                argmax_true=float(g.ex_time.values[g.true_bmhi.values.argmax()]),
                                r=float(np.corrcoef(g.pred_mu, g.true_bmhi)[0, 1]))
        R["landscape"] = lr
    p = os.path.join(RES, "trial_overview.json")
    if os.path.exists(p):
        R["trial"] = json.load(open(p))
        R["trial_summary"] = pd.read_csv(os.path.join(RES, "trial_summary.csv")).set_index("outcome").to_dict("index")
    json.dump(R, open(os.path.join(RES, "paper_numbers.json"), "w"), indent=1, default=float)
    return R


if __name__ == "__main__":
    R = collect()
    print(json.dumps({k: R[k] for k in R if k in ("bench_rank", "bench_wtl", "cv")}, indent=1, default=float)[:3000])
