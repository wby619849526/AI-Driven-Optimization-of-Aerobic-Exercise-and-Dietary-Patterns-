"""
CHRONO-RAGAT: Chrono-metabolic Response-Aware Graph Attention Network.

Blocks
 (1) Static phenotype encoder                         -> CLS token
 (2) Circadian temporal Transformer over 24 hourly rest-activity tokens and 14 daily behaviour tokens,
     with circadian (24 h) and infradian (7 d) harmonic positional encodings
 (3) Response-Aware, Prescription-Conditioned Graph Attention (RAGAT, GATv2-style) over a phenotype-
     similarity graph: neighbours send their latent state AND their observed (prescription, response)
     pair; attention depends on the prescription contrast between query and neighbour
 (4) Chrono-Nutritional Cross-Attention: exercise / nutrition / caffeine tokens query the student's
     temporal context, followed by FiLM modulation of the graph-refined state
 (5) Multi-task head (9 outcomes) trained with homoscedastic-uncertainty weighting + composite BMHI loss
"""
import numpy as np
from autograd import (Tensor, Param, glorot, Adam, concat, gather_rows, gelu, leaky_relu, softmax,
                      layer_norm, dropout, tanh)
from features import TOK_EX, TOK_DIET, TOK_CAF, ple_transform


def circ_pe(n_tok, period, n_harm=2):
    t = np.arange(n_tok)
    feats = []
    for k in range(1, n_harm + 1):
        feats += [np.sin(2 * np.pi * k * t / period), np.cos(2 * np.pi * k * t / period)]
    return np.stack(feats, -1)


class ChronoRAGAT:
    def __init__(self, ds, dh, dd, dp, dy, d=32, heads=4, dropout_p=0.1, seed=0,
                 use_temporal=True, graph="ragat", use_cross=True, use_pe=True, uw=True, bmhi_c=None,
                 lam_bmhi=0.5, wide=True, ple_s=None, ple_p=None):
        self.rng = np.random.default_rng(seed)
        r = self.rng
        self.d, self.h, self.p = d, heads, dropout_p
        self.use_temporal, self.graph, self.use_cross, self.use_pe, self.uw = use_temporal, graph, use_cross, use_pe, uw
        self.bmhi_c = bmhi_c
        self.lam_bmhi = lam_bmhi
        self.wide = wide
        self.ple_s, self.ple_p = ple_s, ple_p
        Ts = 0 if ple_s is None else ple_s.shape[0] - 1
        Tp = 0 if ple_p is None else ple_p.shape[0] - 1
        self.Tp = Tp
        ds = ds * (1 + Ts)
        self.tok_idx = {}
        for nm, g in [("ex", TOK_EX), ("di", TOK_DIET), ("ca", TOK_CAF)]:
            ext = [dp + j * Tp + t for j in g for t in range(Tp)]
            self.tok_idx[nm] = list(g) + ext
        dw = ds if wide else 0
        P = {}
        P["s1"] = glorot(r, ds, 2 * d); P["s1b"] = Param(np.zeros(2 * d))
        P["s2"] = glorot(r, 2 * d, d); P["s2b"] = Param(np.zeros(d))
        if use_temporal:
            P["th"] = glorot(r, dh, d); P["td"] = glorot(r, dd, d)
            P["pe_h"] = glorot(r, 4, d); P["pe_d"] = glorot(r, 4, d)
            P["type_h"] = Param(r.normal(0, 0.02, d)); P["type_d"] = Param(r.normal(0, 0.02, d))
            for nm in ["q", "k", "v", "o"]:
                P["sa_" + nm] = glorot(r, d, d)
            P["ln1g"] = Param(np.ones(d)); P["ln1b"] = Param(np.zeros(d))
            P["ln2g"] = Param(np.ones(d)); P["ln2b"] = Param(np.zeros(d))
            P["f1"] = glorot(r, d, 2 * d); P["f1b"] = Param(np.zeros(2 * d))
            P["f2"] = glorot(r, 2 * d, d); P["f2b"] = Param(np.zeros(d))
        if graph in ("ragat", "gat"):
            P["ga"] = glorot(r, d, d); P["gb"] = glorot(r, d, d)
            P["gatt"] = Param(r.normal(0, 0.1, (heads, d // heads)))
            P["gs"] = Param(np.zeros(d))
            P["gv"] = glorot(r, d, d); P["go"] = glorot(r, d, d)
            if graph == "ragat":
                P["gc"] = glorot(r, dy + dp, d); P["gp"] = glorot(r, dp, d)
                P["gr1"] = glorot(r, dy + dp, d); P["gr1b"] = Param(np.zeros(d)); P["gr2"] = glorot(r, d, d)
        elif graph == "gcn":
            P["gv"] = glorot(r, d, d); P["go"] = glorot(r, d, d)
        if graph is not None:
            P["lng"] = Param(np.ones(d)); P["lnb"] = Param(np.zeros(d))
        if use_cross:
            P["iex"] = glorot(r, len(self.tok_idx["ex"]), d); P["idi"] = glorot(r, len(self.tok_idx["di"]), d)
            P["ica"] = glorot(r, len(self.tok_idx["ca"]), d)
            P["ib"] = Param(r.normal(0, 0.02, (3, d)))
            for nm in ["q", "k", "v", "o"]:
                P["ca_" + nm] = glorot(r, d, d)
            P["ln3g"] = Param(np.ones(d)); P["ln3b"] = Param(np.zeros(d))
            P["fg"] = glorot(r, d, d); P["fb"] = glorot(r, d, d)
            P["h1"] = glorot(r, 2 * d + dw, 2 * d)
        else:
            P["h1"] = glorot(r, d + dp * (1 + Tp) + dw, 2 * d)
        P["h1b"] = Param(np.zeros(2 * d))
        P["h2"] = glorot(r, 2 * d, dy); P["h2b"] = Param(np.zeros(dy))
        P["logvar"] = Param(np.zeros(dy))
        self.P = P
        self.pe_h = circ_pe(24, 24)
        self.pe_d = circ_pe(14, 7)
        self.attn = {}

    # -------------------------------------------------------------- attention
    def _mha(self, pre, xq, xkv, training, store=None):
        P, h = self.P, self.h
        n, Lq, d = xq.shape
        Lk = xkv.shape[1]
        dh = d // h
        Q = (xq @ P[pre + "q"]).reshape(n, Lq, h, dh).transpose(0, 2, 1, 3)
        K = (xkv @ P[pre + "k"]).reshape(n, Lk, h, dh).transpose(0, 2, 3, 1)
        V = (xkv @ P[pre + "v"]).reshape(n, Lk, h, dh).transpose(0, 2, 1, 3)
        A = softmax((Q @ K) * (1.0 / np.sqrt(dh)), axis=-1)
        if store:
            self.attn[store] = A.data
        A = dropout(A, self.p, self.rng, training)
        O = (A @ V).transpose(0, 2, 1, 3).reshape(n, Lq, d)
        return O @ P[pre + "o"]

    def sx(self, S):
        S = np.asarray(S.data if isinstance(S, Tensor) else S)
        return S if self.ple_s is None else np.concatenate([S, ple_transform(S, self.ple_s)], -1)

    def px(self, pq):
        pq = np.asarray(pq)
        return pq if self.ple_p is None else np.concatenate([pq, ple_transform(pq, self.ple_p)], -1)

    # -------------------------------------------------------------- encoder
    def encode(self, S, H, Dl, training=False):
        P = self.P
        S, H, Dl = Tensor(self.sx(S)), Tensor(H), Tensor(Dl)
        cls = gelu(S @ P["s1"] + P["s1b"]) @ P["s2"] + P["s2b"]        # (n,d)
        n = S.shape[0]
        if not self.use_temporal:
            return cls, cls.reshape(n, 1, self.d)
        th = H @ P["th"] + P["type_h"]
        td = Dl @ P["td"] + P["type_d"]
        if self.use_pe:
            th = th + Tensor(self.pe_h) @ P["pe_h"]
            td = td + Tensor(self.pe_d) @ P["pe_d"]
        X = concat([cls.reshape(n, 1, self.d), th, td], axis=1)       # (n, 39, d)
        X = dropout(X, self.p, self.rng, training)
        Xn = layer_norm(X, P["ln1g"], P["ln1b"])
        X = X + self._mha("sa_", Xn, Xn, training, store="temporal")
        Xn = layer_norm(X, P["ln2g"], P["ln2b"])
        X = X + dropout(gelu(Xn @ P["f1"] + P["f1b"]) @ P["f2"] + P["f2b"], self.p, self.rng, training)
        return X[:, 0, :], X

    # -------------------------------------------------------------- graph
    def graph_layer(self, cq, pq, nb_c, nb_r, nb_p, nb_s, training):
        """cq (n,d); pq (n,dp) query prescription enc; nb_c (n,k,d); nb_r (n,k,dy+dp); nb_p (n,k,dp); nb_s (n,k)"""
        P, h = self.P, self.h
        if self.graph is None:
            return cq
        n, k, d = nb_c.shape
        dh = d // h
        if self.graph == "gcn":
            w = np.clip(np.asarray(nb_s), 0, None) + 1e-6
            w = Tensor((w / w.sum(1, keepdims=True))[:, :, None])
            m = (nb_c @ P["gv"]) * w
            out = m.sum(1) @ P["go"]
        else:
            e = (cq @ P["ga"]).reshape(n, 1, d) + nb_c @ P["gb"] + Tensor(nb_s[:, :, None]) * P["gs"]
            if self.graph == "ragat":
                dp_ = Tensor(pq[:, None, :] - nb_p)
                e = e + Tensor(nb_r) @ P["gc"] + dp_ @ P["gp"]
            e = leaky_relu(e).reshape(n, k, h, dh)
            sc = (e * P["gatt"]).sum(-1)                                  # (n,k,h)
            a = softmax(sc, axis=1)
            self.attn["graph"] = a.data
            a = dropout(a, self.p, self.rng, training)
            m = nb_c @ P["gv"]
            if self.graph == "ragat":
                m = m + gelu(Tensor(nb_r) @ P["gr1"] + P["gr1b"]) @ P["gr2"]
            m = m.reshape(n, k, h, dh)
            out = (m * a.reshape(n, k, h, 1)).sum(1).reshape(n, d) @ P["go"]
        return layer_norm(cq + dropout(out, self.p, self.rng, training), P["lng"], P["lnb"])

    # -------------------------------------------------------------- head
    def head(self, z, tok, pq, training, s_wide=None, offset=None):
        P = self.P
        pqx = self.px(pq.data if isinstance(pq, Tensor) else pq)
        pqT = Tensor(pqx)
        n = z.shape[0]
        if self.use_cross:
            t = concat([(Tensor(pqx[:, self.tok_idx["ex"]]) @ P["iex"]).reshape(n, 1, self.d),
                        (Tensor(pqx[:, self.tok_idx["di"]]) @ P["idi"]).reshape(n, 1, self.d),
                        (Tensor(pqx[:, self.tok_idx["ca"]]) @ P["ica"]).reshape(n, 1, self.d)], axis=1) + P["ib"]
            kv = concat([tok, z.reshape(n, 1, self.d)], axis=1)
            u = layer_norm(t + self._mha("ca_", t, kv, training, store="cross"), P["ln3g"], P["ln3b"])
            pooled = u.mean(axis=1)
            hz = z * (tanh(pooled @ P["fg"]) + 1.0) + pooled @ P["fb"]
            x = concat([hz, pooled], -1)
        else:
            x = concat([z, pqT], -1)
        if self.wide:                       # wide skip path: raw standardised phenotype -> head
            x = concat([x, Tensor(self.sx(s_wide))], -1)
        x = dropout(gelu(x @ P["h1"] + P["h1b"]), self.p, self.rng, training)
        out = x @ P["h2"] + P["h2b"]
        if offset is not None:              # boosted-tree prior: the network learns the residual correction
            out = out + Tensor(offset)
        return out

    def forward(self, cls, tok, pq, nb_c, nb_r, nb_p, nb_s, training=False, s_wide=None, offset=None):
        z = self.graph_layer(cls, pq, nb_c, nb_r, nb_p, nb_s, training)
        return self.head(z, tok, pq, training, s_wide, offset)

    # -------------------------------------------------------------- loss
    def loss(self, yhat, y, C=None):
        P = self.P
        err = (yhat - Tensor(y)) ** 2
        mse_t = err.mean(axis=0)
        if self.uw:
            # homoscedastic uncertainty weighting (Kendall-style), differentiable in logvar
            ew = _exp(P["logvar"] * -1.0)
            L = (mse_t * ew * 0.5 + P["logvar"] * 0.5).sum()
        else:
            L = mse_t.mean()
        if C is not None and self.lam_bmhi > 0:
            db = ((yhat - Tensor(y)) * Tensor(C)).sum(axis=-1)          # composite (BMHI) error
            L = L + (db ** 2).mean() * self.lam_bmhi
        return L

    def params(self):
        return list(self.P.values())

    def state(self):
        return {k: v.data.copy() for k, v in self.P.items()}

    def load(self, st):
        for k, v in st.items():
            self.P[k].data = v.copy()


def _exp(x):
    e = np.exp(x.data)
    out = Tensor(e, x.requires_grad, (x,))
    out._backward = lambda g: x._acc(g * e)
    return out
