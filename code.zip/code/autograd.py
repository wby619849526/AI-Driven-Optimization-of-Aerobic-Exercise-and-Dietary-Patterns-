"""
Minimal reverse-mode automatic differentiation engine on NumPy.
Used to implement CHRONO-RAGAT without external deep-learning frameworks,
so that every result in the paper is reproducible with NumPy/SciPy only.
"""
import numpy as np

_DT = np.float32


def _unbroadcast(grad, shape):
    """Sum gradient over broadcast dimensions so it matches `shape`."""
    while grad.ndim > len(shape):
        grad = grad.sum(axis=0)
    for i, s in enumerate(shape):
        if s == 1 and grad.shape[i] != 1:
            grad = grad.sum(axis=i, keepdims=True)
    return grad


class Tensor:
    __array_priority__ = 1000

    def __init__(self, data, requires_grad=False, _parents=(), _backward=None):
        self.data = np.asarray(data, dtype=_DT)
        self.requires_grad = requires_grad
        self.grad = None
        self._parents = _parents
        self._backward = _backward

    @property
    def shape(self):
        return self.data.shape

    @property
    def ndim(self):
        return self.data.ndim

    def __repr__(self):
        return f"Tensor(shape={self.shape}, rg={self.requires_grad})"

    # ------------------------------------------------------------------ graph
    def backward(self, grad=None):
        topo, seen = [], set()

        def build(t):
            if id(t) in seen:
                return
            seen.add(id(t))
            for p in t._parents:
                build(p)
            topo.append(t)

        build(self)
        self.grad = np.ones_like(self.data) if grad is None else grad
        for t in reversed(topo):
            if t._backward is not None and t.grad is not None:
                t._backward(t.grad)
        # free the graph: intermediate nodes drop closures, parents and gradients (leaves keep grads)
        for t in topo:
            if t._parents:
                t._backward = None
                t._parents = ()
                t.grad = None

    def _acc(self, g):
        if not self.requires_grad:
            return
        if self.grad is None:
            self.grad = g
        else:
            self.grad = self.grad + g

    # ---------------------------------------------------------- arithmetic
    def __add__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data + other.data, self.requires_grad or other.requires_grad, (self, other))

        def bw(g):
            self._acc(_unbroadcast(g, self.shape))
            other._acc(_unbroadcast(g, other.shape))
        out._backward = bw
        return out

    __radd__ = __add__

    def __neg__(self):
        out = Tensor(-self.data, self.requires_grad, (self,))
        out._backward = lambda g: self._acc(-g)
        return out

    def __sub__(self, other):
        return self + (-(other if isinstance(other, Tensor) else Tensor(other)))

    def __rsub__(self, other):
        return Tensor(other) + (-self)

    def __mul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data * other.data, self.requires_grad or other.requires_grad, (self, other))

        def bw(g):
            self._acc(_unbroadcast(g * other.data, self.shape))
            other._acc(_unbroadcast(g * self.data, other.shape))
        out._backward = bw
        return out

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data / other.data, self.requires_grad or other.requires_grad, (self, other))

        def bw(g):
            self._acc(_unbroadcast(g / other.data, self.shape))
            other._acc(_unbroadcast(-g * self.data / other.data ** 2, other.shape))
        out._backward = bw
        return out

    def __pow__(self, p):
        out = Tensor(self.data ** p, self.requires_grad, (self,))
        out._backward = lambda g: self._acc(g * p * self.data ** (p - 1))
        return out

    def __matmul__(self, other):
        other = other if isinstance(other, Tensor) else Tensor(other)
        out = Tensor(self.data @ other.data, self.requires_grad or other.requires_grad, (self, other))

        def bw(g):
            a, b = self.data, other.data
            if self.requires_grad:
                ga = g @ np.swapaxes(b, -1, -2)
                self._acc(_unbroadcast(ga, a.shape))
            if other.requires_grad:
                gb = np.swapaxes(a, -1, -2) @ g
                other._acc(_unbroadcast(gb, b.shape))
        out._backward = bw
        return out

    # ---------------------------------------------------------- reductions
    def sum(self, axis=None, keepdims=False):
        out = Tensor(self.data.sum(axis=axis, keepdims=keepdims), self.requires_grad, (self,))

        def bw(g):
            if axis is not None and not keepdims:
                g = np.expand_dims(g, axis)
            self._acc(np.broadcast_to(g, self.shape).copy())
        out._backward = bw
        return out

    def mean(self, axis=None, keepdims=False):
        n = self.data.size if axis is None else np.prod([self.shape[a] for a in np.atleast_1d(axis)])
        return self.sum(axis=axis, keepdims=keepdims) * (1.0 / n)

    # ---------------------------------------------------------- shape ops
    def reshape(self, *shape):
        out = Tensor(self.data.reshape(*shape), self.requires_grad, (self,))
        out._backward = lambda g: self._acc(g.reshape(self.shape))
        return out

    def transpose(self, *axes):
        out = Tensor(self.data.transpose(*axes), self.requires_grad, (self,))
        inv = np.argsort(axes)
        out._backward = lambda g: self._acc(g.transpose(*inv))
        return out

    def __getitem__(self, idx):
        out = Tensor(self.data[idx], self.requires_grad, (self,))

        def bw(g):
            full = np.zeros_like(self.data)
            np.add.at(full, idx, g)
            self._acc(full)
        out._backward = bw
        return out


# -------------------------------------------------------------- functions
def concat(ts, axis=-1):
    data = np.concatenate([t.data for t in ts], axis=axis)
    out = Tensor(data, any(t.requires_grad for t in ts), tuple(ts))
    sizes = [t.shape[axis] for t in ts]
    splits = np.cumsum(sizes)[:-1]

    def bw(g):
        for t, gg in zip(ts, np.split(g, splits, axis=axis)):
            t._acc(gg)
    out._backward = bw
    return out


def stack(ts, axis=0):
    return concat([t.reshape(*t.shape[:axis], 1, *t.shape[axis:]) if axis >= 0 else
                   t.reshape(*t.shape, 1) for t in ts], axis=axis)


def gather_rows(x, idx):
    """x: (N, ...) ; idx: int array of any shape -> (idx.shape + x.shape[1:])"""
    out = Tensor(x.data[idx], x.requires_grad, (x,))

    def bw(g):
        full = np.zeros_like(x.data)
        np.add.at(full, idx.reshape(-1), g.reshape(-1, *x.shape[1:]))
        x._acc(full)
    out._backward = bw
    return out


def relu(x):
    out = Tensor(np.maximum(x.data, 0), x.requires_grad, (x,))
    out._backward = lambda g: x._acc(g * (x.data > 0))
    return out


def leaky_relu(x, s=0.2):
    out = Tensor(np.where(x.data > 0, x.data, s * x.data), x.requires_grad, (x,))
    out._backward = lambda g: x._acc(g * np.where(x.data > 0, 1.0, s))
    return out


def gelu(x):
    # sigmoid approximation of GELU: x * sigmoid(1.702 x)
    s = 1.0 / (1.0 + np.exp(-1.702 * np.clip(x.data, -30, 30)))
    out = Tensor(x.data * s, x.requires_grad, (x,))

    def bw(g):
        x._acc(g * (s + 1.702 * x.data * s * (1 - s)))
    out._backward = bw
    return out


def tanh(x):
    t = np.tanh(x.data)
    out = Tensor(t, x.requires_grad, (x,))
    out._backward = lambda g: x._acc(g * (1 - t ** 2))
    return out


def sigmoid(x):
    s = 1 / (1 + np.exp(-np.clip(x.data, -50, 50)))
    out = Tensor(s, x.requires_grad, (x,))
    out._backward = lambda g: x._acc(g * s * (1 - s))
    return out


def softmax(x, axis=-1, mask=None):
    z = x.data
    if mask is not None:
        z = np.where(mask, z, -1e9)
    z = z - z.max(axis=axis, keepdims=True)
    e = np.exp(z)
    s = e / e.sum(axis=axis, keepdims=True)
    out = Tensor(s, x.requires_grad, (x,))

    def bw(g):
        x._acc(s * (g - (g * s).sum(axis=axis, keepdims=True)))
    out._backward = bw
    return out


def layer_norm(x, gamma, beta, eps=1e-5):
    mu = x.data.mean(-1, keepdims=True)
    var = x.data.var(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + eps)
    xh = (x.data - mu) * inv
    out = Tensor(xh * gamma.data + beta.data, True, (x, gamma, beta))
    D = x.shape[-1]

    def bw(g):
        gamma._acc(_unbroadcast(g * xh, gamma.shape))
        beta._acc(_unbroadcast(g, beta.shape))
        if x.requires_grad:
            gx = g * gamma.data
            dx = (inv / D) * (D * gx - gx.sum(-1, keepdims=True) - xh * (gx * xh).sum(-1, keepdims=True))
            x._acc(dx)
    out._backward = bw
    return out


def dropout(x, p, rng, training):
    if not training or p <= 0:
        return x
    m = (rng.random(x.shape, dtype=np.float32) > p).astype(np.float32) * np.float32(1.0 / (1 - p))
    return x * Tensor(m)


# -------------------------------------------------------------- params
class Param(Tensor):
    def __init__(self, data):
        super().__init__(data, requires_grad=True)


def glorot(rng, fan_in, fan_out):
    lim = np.sqrt(6.0 / (fan_in + fan_out))
    return Param(rng.uniform(-lim, lim, (fan_in, fan_out)))


class Adam:
    def __init__(self, params, lr=1e-3, wd=0.0, b1=0.9, b2=0.999, eps=1e-8, clip=5.0):
        self.params = params
        self.lr, self.wd, self.b1, self.b2, self.eps, self.clip = lr, wd, b1, b2, eps, clip
        self.m = [np.zeros_like(p.data) for p in params]
        self.v = [np.zeros_like(p.data) for p in params]
        self.t = 0

    def zero_grad(self):
        for p in self.params:
            p.grad = None

    def step(self):
        self.t += 1
        # global gradient-norm clipping
        gn = np.sqrt(sum(float((p.grad ** 2).sum()) for p in self.params if p.grad is not None))
        sc = min(1.0, self.clip / (gn + 1e-12))
        for i, p in enumerate(self.params):
            if p.grad is None:
                continue
            g = p.grad * sc
            if self.wd > 0 and p.data.ndim > 1:          # decoupled weight decay (AdamW)
                p.data -= (self.lr * self.wd * p.data).astype(p.data.dtype)
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
            mh = self.m[i] / (1 - self.b1 ** self.t)
            vh = self.v[i] / (1 - self.b2 ** self.t)
            p.data -= (self.lr * mh / (np.sqrt(vh) + self.eps)).astype(p.data.dtype)
        return gn
