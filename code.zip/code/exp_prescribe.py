"""Experiments 4-6:
 (4) personalised prescription optimisation on held-out students: CLO-GWO vs. 7 optimisers (equal budget),
     scored on the TRUE (noise-free) simulator response; regret vs. oracle; uncertainty-penalty sensitivity
 (5) personalisation / interpretability analyses (chronotype maps, timing landscapes, attention)
 (6) in-silico randomised controlled trial on an independent external cohort (4 arms)"""
import os, sys, json, time, pickle
import numpy as np, pandas as pd
from scipy import stats
from train import Cohort, Context, fit, predict, FrozenStudent, merge_cohorts, make_model, TreeModel, fit_blend, blend
from features import presc_encode
from simulator import (bmhi, response, repair, constraint_violation, guideline_prescription, rule_chrono_prescription,
                       no_intervention, DEC_LB, DEC_UB, DEC_NAMES, OUTCOMES, OUT_LABELS)
from optimizers import clo_gwo, gwo, mgwo, pso, de, ga, woa, random_search
from exp_hpo import splits
from exp_predict import load_hp

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
M_ENS, KAPPA, LAM = 5, 0.5, 2.0
POP, BUDGET = 20, 1200


class Surrogate:
    """Batched objective for S students x P candidates using the frozen ensemble."""

    def __init__(self, models, ctx, q_idx, kappa=KAPPA, tree=None, w=None):
        self.fs = FrozenStudent(models, ctx, q_idx)
        self.tree, self.w = tree, w
        b = ctx.coh.b
        self.q = np.asarray(q_idx)
        self.bmi = b.bmi.values[self.q]
        self.onset = b.sleep_onset_week.values[self.q]
        self.kappa = kappa
        self.bq = {k: b[k].values[self.q] for k in ["msf_sc", "wake_week", "sleep_onset_week"]}

    def predict(self, which, X):
        pq = presc_encode(X, {k: v[which] for k, v in self.bq.items()})
        outs = []
        ctx = self.fs.ctx
        off = ctx.offset_for(self.q[which], pq)
        from autograd import Tensor
        for m, c in zip(self.fs.models, self.fs.cache):
            y = m.forward(Tensor(c["cls"][which]), Tensor(c["tok"][which]), pq, Tensor(c["nb_c"][which]),
                          c["nb_r"][which], self.fs.nb_p[which], self.fs.nb_s[which], training=False,
                          s_wide=ctx.S[self.q[which]], offset=off)
            outs.append(ctx.to_orig(y.data.astype(np.float64), self.q[which]))
        if self.tree is not None:                                # stacked with the boosted-tree branch
            yt = self.tree.predict(self.q[which], pq, ctx.coh)
            outs = [blend(self.w, yt, o) for o in outs]
        return np.stack(outs)                                   # (M, n, 9)

    def objective(self, X3, sub=None):
        S, P, D = X3.shape
        sub = np.arange(S) if sub is None else sub
        which = np.repeat(sub, P)
        X = repair(X3.reshape(-1, D), self.bmi[which])
        Y = []
        for s in range(0, len(which), 4000):
            Y.append(self.predict(which[s:s + 4000], X[s:s + 4000]))
        Y = np.concatenate(Y, 1)
        B = bmhi(Y.reshape(-1, 9)).reshape(Y.shape[0], -1)
        mu, sd = B.mean(0), B.std(0)
        pen = constraint_violation(X, self.onset[which])
        return -(mu - self.kappa * sd - LAM * pen).reshape(S, P)


def true_objective(coh, q):
    b = coh.b.iloc[q].reset_index(drop=True); l = coh.lat.iloc[q].reset_index(drop=True)

    def f(X3):
        S, P, D = X3.shape
        rows = np.repeat(np.arange(S), P)
        X = repair(X3.reshape(-1, D), b.bmi.values[rows])
        Y, _ = response(b.iloc[rows].reset_index(drop=True), l.iloc[rows].reset_index(drop=True), X, None, noise=False)
        pen = constraint_violation(X, b.sleep_onset_week.values[rows])
        return -(bmhi(Y) - LAM * pen).reshape(S, P)
    return f


def evaluate_true(coh, q, X):
    b = coh.b.iloc[q].reset_index(drop=True); l = coh.lat.iloc[q].reset_index(drop=True)
    X = repair(X, b.bmi.values)
    Y, adh = response(b, l, X, None, noise=False)
    viol = constraint_violation(X, b.sleep_onset_week.values)
    return Y, bmhi(Y), adh, viol, X


def train_ensemble(coh, fit_idx, val_idx, hp):
    p = os.path.join(RES, "final_ensemble.pkl")
    ctx = Context(coh, fit_idx, k=hp["k"])
    cfg = dict(d=hp["d"], dropout=hp["dropout"], lam_bmhi=hp["lam_bmhi"], batch=hp.get("batch", 64))
    if os.path.exists(p):
        st = pickle.load(open(p, "rb"))
        models = []
        for s, state in enumerate(st["states"]):
            m = make_model(ctx, cfg, seed=s); m.load(state); m.cfg = cfg; models.append(m)
        return models, ctx, st["hist"], st["tree"], st["w"]
    models, hist = [], []
    for s in range(M_ENS):
        m = fit(ctx, cfg, fit_idx, val_idx, seed=100 + s, epochs=120, lr=hp["lr"], wd=hp["wd"], patience=16,
                eval_every=2, beta_base=hp["beta_base"])
        models.append(m); hist.append(m.hist)
        print("ensemble member", s, "val", round(m.best_val, 4), flush=True)
    tree = TreeModel(coh, fit_idx)
    Yv = np.mean([predict(m, ctx, val_idx, coh.penc[val_idx]) for m in models], 0)
    w = fit_blend(tree.predict(val_idx, coh.penc[val_idx]), Yv, coh.Y[val_idx])
    tree = TreeModel(coh, np.concatenate([fit_idx, val_idx]))        # refit on all training students
    pickle.dump(dict(states=[m.state() for m in models], cfg=cfg, hp=hp, hist=hist, tree=tree, w=w), open(p, "wb"))
    return models, ctx, hist, tree, w


def main():
    coh = Cohort("dev_")
    hp = load_hp()
    fit_idx, val_idx, te = splits(coh.n)
    models, ctx, hist, tree, wbl = train_ensemble(coh, fit_idx, val_idx, hp)
    # hold-out accuracy of the stacked ensemble, the network-only ensemble and the tree branch
    from exp_predict import metrics
    Ynet = np.mean([predict(m, ctx, te, coh.penc[te]) for m in models], 0)
    Ytr = tree.predict(te, coh.penc[te])
    json.dump(dict(stacked=metrics(blend(wbl, Ytr, Ynet), coh.Y[te]), network=metrics(Ynet, coh.Y[te]),
                   tree=metrics(Ytr, coh.Y[te]), omega=wbl.tolist()),
              open(os.path.join(RES, "final_ensemble_holdout_metrics.json"), "w"), indent=1)

    q = te[:240]                                        # held-out students used for optimisation
    sur = Surrogate(models, ctx, q, tree=tree, w=wbl)
    rows = []
    curves = {}
    sols = {}
    algs = {"CLO-GWO": clo_gwo, "GWO": gwo, "mGWO": mgwo, "PSO": pso, "DE": de, "GA": ga, "WOA": woa,
            "Random search": random_search}
    for an, alg in algs.items():
        t0 = time.time()
        bx, bf, cur = alg(lambda X: sur.objective(X), DEC_LB, DEC_UB, len(q), POP, BUDGET, np.random.default_rng(3))
        el = time.time() - t0
        Y, B, adh, viol, Xr = evaluate_true(coh, q, bx)
        sols[an] = Xr
        curves[an] = [(float(fe), float(-np.mean(b))) for fe, b in cur]
        rows.append(dict(strategy=an, pred_obj=float(-bf.mean()), true_bmhi=float(B.mean()), true_bmhi_sd=float(B.std()),
                         adherence=float(adh.mean()), viol_rate=float((viol > 1e-6).mean()), time_s=el,
                         **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
        np.save(os.path.join(RES, f"presc_true_bmhi_{an.replace(' ', '_')}.npy"), B)
        print(an, rows[-1]["true_bmhi"], round(el), flush=True)
    # alternative surrogate: gradient-boosted trees (best tabular learner) optimised by the same CLO-GWO
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.multioutput import MultiOutputRegressor
    hgb = TreeModel(coh, np.concatenate([fit_idx, val_idx]))

    def f_tree(X3):
        S, P, D = X3.shape
        which = np.repeat(np.arange(S), P)
        X = repair(X3.reshape(-1, D), sur.bmi[which])
        pq = presc_encode(X, {k: v[which] for k, v in sur.bq.items()})
        Yh = hgb.predict(q[which], pq)
        return -(bmhi(Yh) - LAM * constraint_violation(X, sur.onset[which])).reshape(S, P)
    t0 = time.time()
    bx, bf, cur = clo_gwo(f_tree, DEC_LB, DEC_UB, len(q), POP, BUDGET, np.random.default_rng(3))
    Y, B, adh, viol, Xr = evaluate_true(coh, q, bx)
    sols["GBT surrogate + CLO-GWO"] = Xr
    rows.append(dict(strategy="GBT surrogate + CLO-GWO", pred_obj=float(-bf.mean()), true_bmhi=float(B.mean()),
                     true_bmhi_sd=float(B.std()), adherence=float(adh.mean()), viol_rate=float((viol > 1e-6).mean()),
                     time_s=time.time() - t0, **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
    np.save(os.path.join(RES, "presc_true_bmhi_GBT_surrogate.npy"), B)
    print("GBT surrogate", rows[-1]["true_bmhi"], flush=True)
    # single-model (no ensemble, kappa = 0) CHRONO-RAGAT surrogate: effect of the deep ensemble
    sur1 = Surrogate(models[:1], ctx, q, kappa=0.0, tree=tree, w=wbl)
    bx, bf, _ = clo_gwo(lambda X: sur1.objective(X), DEC_LB, DEC_UB, len(q), POP, BUDGET, np.random.default_rng(3))
    Y, B, adh, viol, Xr = evaluate_true(coh, q, bx)
    rows.append(dict(strategy="Single CHRONO-RAGAT (no ensemble) + CLO-GWO", pred_obj=float(-bf.mean()),
                     true_bmhi=float(B.mean()), true_bmhi_sd=float(B.std()), adherence=float(adh.mean()),
                     viol_rate=float((viol > 1e-6).mean()), time_s=0.0,
                     **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
    np.save(os.path.join(RES, "presc_true_bmhi_Single_model.npy"), B)
    # network-only ensemble (no boosted-tree branch)
    surN = Surrogate(models, ctx, q)
    bx, bf, _ = clo_gwo(lambda X: surN.objective(X), DEC_LB, DEC_UB, len(q), POP, BUDGET, np.random.default_rng(3))
    Y, B, adh, viol, Xr = evaluate_true(coh, q, bx)
    rows.append(dict(strategy="Network-only ensemble (no tree branch) + CLO-GWO", pred_obj=float(-bf.mean()),
                     true_bmhi=float(B.mean()), true_bmhi_sd=float(B.std()), adherence=float(adh.mean()),
                     viol_rate=float((viol > 1e-6).mean()), time_s=0.0,
                     **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
    np.save(os.path.join(RES, "presc_true_bmhi_Network_only.npy"), B)
    print("network-only", rows[-1]["true_bmhi"], flush=True)
    # reference strategies
    b = coh.b.iloc[q].reset_index(drop=True); l = coh.lat.iloc[q].reset_index(drop=True)
    rng = np.random.default_rng(9)
    Yc = no_intervention(b, l, rng)
    ref = {"Usual habits (no programme)": None, "Guideline (150 min/wk, 12-h window)": guideline_prescription(b),
           "Rule-based chrono-matched": rule_chrono_prescription(b)}
    # one-size-fits-all AI plan: maximise the mean surrogate objective over training students
    trs = fit_idx[:150]
    sur_tr = Surrogate(models, ctx, trs, tree=tree, w=wbl)

    def f_osfa(X3):
        S, P, D = X3.shape
        vals = np.zeros((S, P))
        for p in range(P):
            Xp = np.tile(X3[0, p], (len(trs), 1, 1))          # same plan for every training student
            vals[0, p] = sur_tr.objective(Xp).mean()
        return vals
    bx, bf, _ = clo_gwo(f_osfa, DEC_LB, DEC_UB, 1, 10, 240, np.random.default_rng(4))
    ref["One-size-fits-all AI plan"] = np.tile(bx[0], (len(q), 1))
    for nm, X in ref.items():
        if X is None:
            Y = Yc; B = bmhi(Y); adh = np.full(len(q), np.nan); viol = np.zeros(len(q)); Xr = None
        else:
            Y, B, adh, viol, Xr = evaluate_true(coh, q, X)
        sols[nm] = Xr
        rows.append(dict(strategy=nm, pred_obj=np.nan, true_bmhi=float(B.mean()), true_bmhi_sd=float(B.std()),
                         adherence=float(np.nanmean(adh)) if X is not None else np.nan,
                         viol_rate=float((viol > 1e-6).mean()), time_s=0.0,
                         **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
        np.save(os.path.join(RES, f"presc_true_bmhi_{nm.split(' (')[0].replace(' ', '_')}.npy"), B)
    # oracle (CLO-GWO on the true simulator, larger budget)
    bx, bf, _ = clo_gwo(true_objective(coh, q), DEC_LB, DEC_UB, len(q), 30, 6000, np.random.default_rng(5))
    Y, B, adh, viol, Xr = evaluate_true(coh, q, bx)
    sols["Oracle"] = Xr
    rows.append(dict(strategy="Oracle (true simulator)", pred_obj=np.nan, true_bmhi=float(B.mean()),
                     true_bmhi_sd=float(B.std()), adherence=float(adh.mean()), viol_rate=float((viol > 1e-6).mean()),
                     time_s=0.0, **{o: float(Y[:, j].mean()) for j, o in enumerate(OUTCOMES)}))
    np.save(os.path.join(RES, "presc_true_bmhi_Oracle.npy"), B)
    oracle_B = B
    df = pd.DataFrame(rows)
    df["regret"] = oracle_B.mean() - df.true_bmhi
    df["pct_of_oracle"] = 100 * df.true_bmhi / oracle_B.mean()
    df.to_csv(os.path.join(RES, "prescription_results.csv"), index=False)
    json.dump(curves, open(os.path.join(RES, "prescription_curves.json"), "w"))
    pickle.dump(dict(q=q, sols=sols), open(os.path.join(RES, "prescription_solutions.pkl"), "wb"))
    # paired tests CLO-GWO vs others
    base = np.load(os.path.join(RES, "presc_true_bmhi_CLO-GWO.npy"))
    tests = []
    for f in os.listdir(RES):
        if f.startswith("presc_true_bmhi_") and "CLO-GWO" not in f:
            o = np.load(os.path.join(RES, f))
            w = stats.wilcoxon(base, o)
            tests.append(dict(vs=f[16:-4], mean_diff=float((base - o).mean()), p=float(w.pvalue),
                              win_rate=float((base > o).mean())))
    pd.DataFrame(tests).to_csv(os.path.join(RES, "prescription_paired_tests.csv"), index=False)

    # ---- kappa sensitivity (uncertainty penalty)
    ks = []
    qk = q[:120]
    surk = Surrogate(models, ctx, qk, tree=tree, w=wbl)
    for kap in [0.0, 0.5, 1.0, 2.0]:
        surk.kappa = kap
        bx, bf, _ = clo_gwo(lambda X: surk.objective(X), DEC_LB, DEC_UB, len(qk), POP, BUDGET, np.random.default_rng(3))
        Y, B, adh, viol, Xr = evaluate_true(coh, qk, bx)
        Ym = surk.predict(np.arange(len(qk)), Xr)
        sdB = bmhi(Ym.reshape(-1, 9)).reshape(Ym.shape[0], -1).std(0)
        ks.append(dict(kappa=kap, true_bmhi=float(B.mean()), p10_true_bmhi=float(np.percentile(B, 10)),
                       harm_rate=float((B < 0).mean()), pred_sd=float(sdB.mean()), adherence=float(adh.mean())))
        print("kappa", ks[-1], flush=True)
    pd.DataFrame(ks).to_csv(os.path.join(RES, "kappa_sensitivity.csv"), index=False)

    # ---- timing landscapes for 3 representative students (early / intermediate / late chronotype)
    msf = coh.b.msf_sc.values[q]
    picks = [int(np.argmin(np.abs(msf - v))) for v in [3.6, 5.0, 6.6]]
    land = []
    Xai = sols["CLO-GWO"]
    grid = np.linspace(6, 22, 49)
    for pi in picks:
        Xg = np.tile(Xai[pi], (len(grid), 1)); Xg[:, 0] = grid
        Xg = repair(Xg, np.full(len(grid), coh.b.bmi.values[q[pi]]))
        Ym = sur.predict(np.full(len(grid), pi), Xg)
        Bm = bmhi(Ym.reshape(-1, 9)).reshape(M_ENS, -1)
        Yt, Bt, _, _, _ = evaluate_true(coh, np.full(len(grid), q[pi]), Xg)
        for g, mu, sd, bt in zip(grid, Bm.mean(0), Bm.std(0), Bt):
            land.append(dict(student=int(q[pi]), msf=float(msf[pi]), ex_time=float(g), pred_mu=float(mu), pred_sd=float(sd),
                             true_bmhi=float(bt)))
    pd.DataFrame(land).to_csv(os.path.join(RES, "timing_landscape.csv"), index=False)

    # ---- attention maps (temporal self-attention from CLS to hourly tokens; graph attention entropy)
    m0 = models[0]
    m0.encode(ctx.S[q], ctx.H[q], ctx.Dl[q], training=False)
    A = m0.attn["temporal"]                                  # (n, h, 39, 39)
    cls_to_hour = A[:, :, 0, 1:25].mean(1)                    # (n, 24)
    cls_to_day = A[:, :, 0, 25:39].mean(1)
    np.save(os.path.join(RES, "attn_cls_hour.npy"), cls_to_hour)
    np.save(os.path.join(RES, "attn_cls_day.npy"), cls_to_day)
    np.save(os.path.join(RES, "attn_msf.npy"), msf)
    # cross-attention of intervention tokens and graph attention on the AI prescriptions
    sur.predict(np.arange(len(q)), Xai)
    np.save(os.path.join(RES, "attn_cross.npy"), models[-1].attn["cross"].mean(1))    # (n, 3, 40)
    np.save(os.path.join(RES, "attn_graph.npy"), models[-1].attn["graph"])            # (n, k, h)

    # ---- permutation importance of input groups on predicted BMHI of the AI plan
    base_pred = bmhi(sur.predict(np.arange(len(q)), Xai).mean(0))
    imp = []
    rngp = np.random.default_rng(1)
    groups = {"Exercise timing": [0], "Exercise dose (intensity, duration, frequency, HIIT)": [1, 2, 3, 4],
              "Eating window & first-meal time": [5, 6], "Macronutrients & fibre": [7, 8, 9],
              "Caffeine cut-off": [10], "Energy deficit": [11]}
    for g, cols in groups.items():
        Xp = Xai.copy()
        Xp[:, cols] = Xp[rngp.permutation(len(q))][:, cols]
        Xp = repair(Xp, coh.b.bmi.values[q])
        pb = bmhi(sur.predict(np.arange(len(q)), Xp).mean(0))
        Yt0, Bt0, _, _, _ = evaluate_true(coh, q, Xai); Yt1, Bt1, _, _, _ = evaluate_true(coh, q, Xp)
        imp.append(dict(group=g, pred_drop=float((base_pred - pb).mean()), true_drop=float((Bt0 - Bt1).mean())))
    pd.DataFrame(imp).to_csv(os.path.join(RES, "prescription_permutation_importance.csv"), index=False)

    # ---- in-silico RCT on the independent external cohort
    trial(coh, models, ctx, hp, fit_idx, tree, wbl)


def trial(coh, models, ctx_dev, hp, fit_idx, tree, wbl):
    ext = Cohort("trial_", with_outcomes=False)
    mc = merge_cohorts(coh, ext)
    ctx = Context(mc, fit_idx, k=hp["k"])
    tq = np.arange(coh.n, mc.n)
    rng = np.random.default_rng(2027)
    arm = rng.permutation(np.repeat(np.arange(4), len(tq) // 4))
    names = ["Control (usual habits)", "Guideline", "Rule-based chrono-matched", "AI-personalised (CHRONO-RAGAT + CLO-GWO)"]
    b = mc.b.iloc[tq].reset_index(drop=True); l = mc.lat.iloc[tq].reset_index(drop=True)
    X = np.full((len(tq), 12), np.nan)
    X[arm == 1] = guideline_prescription(b[arm == 1])
    X[arm == 2] = rule_chrono_prescription(b[arm == 2])
    ai = np.where(arm == 3)[0]
    sur = Surrogate(models, ctx, tq[ai], tree=tree, w=wbl)
    bx, bf, _ = clo_gwo(lambda Z: sur.objective(Z), DEC_LB, DEC_UB, len(ai), POP, BUDGET, np.random.default_rng(8))
    X[ai] = repair(bx, b.bmi.values[ai])
    Y = np.zeros((len(tq), 9)); adh = np.full(len(tq), np.nan)
    c = arm == 0
    Y[c] = no_intervention(b[c].reset_index(drop=True), l[c].reset_index(drop=True), rng)
    for a in [1, 2, 3]:
        ii = arm == a
        Y[ii], adh[ii] = response(b[ii].reset_index(drop=True), l[ii].reset_index(drop=True), X[ii], rng, noise=True)
    B = bmhi(Y)
    out = pd.DataFrame(Y, columns=OUTCOMES); out["bmhi"] = B; out["arm"] = [names[a] for a in arm]; out["adherence"] = adh
    out = pd.concat([out, pd.DataFrame(X, columns=DEC_NAMES)], axis=1)
    out.insert(0, "sid", b.sid.values)
    out.to_csv(os.path.join(RES, "trial_participant_level.csv"), index=False)
    summ = []
    for j, o in enumerate(OUTCOMES + ["bmhi"]):
        v = out[o].values
        row = dict(outcome=o)
        for a, nm in enumerate(names):
            x = v[arm == a]; row[f"{nm}|mean"] = x.mean(); row[f"{nm}|sd"] = x.std(ddof=1)
        ai_v = v[arm == 3]
        for a, tag in [(0, "vs_control"), (1, "vs_guideline"), (2, "vs_rule")]:
            o_v = v[arm == a]
            diff = ai_v.mean() - o_v.mean()
            se = np.sqrt(ai_v.var(ddof=1) / len(ai_v) + o_v.var(ddof=1) / len(o_v))
            t = stats.ttest_ind(ai_v, o_v, equal_var=False)
            sp = np.sqrt((ai_v.var(ddof=1) + o_v.var(ddof=1)) / 2)
            row[f"diff_{tag}"] = diff; row[f"ci_lo_{tag}"] = diff - 1.96 * se; row[f"ci_hi_{tag}"] = diff + 1.96 * se
            row[f"p_{tag}"] = t.pvalue; row[f"d_{tag}"] = diff / sp
        summ.append(row)
    pd.DataFrame(summ).to_csv(os.path.join(RES, "trial_summary.csv"), index=False)
    resp = {nm: float((B[arm == a] >= 1.0).mean()) for a, nm in enumerate(names)}
    harm = {nm: float((B[arm == a] < 0).mean()) for a, nm in enumerate(names)}
    adh_m = {nm: float(np.nanmean(adh[arm == a])) if a > 0 else None for a, nm in enumerate(names)}
    ch = stats.chi2_contingency(np.array([[(B[arm == a] >= 1).sum(), (B[arm == a] < 1).sum()] for a in range(4)]))
    json.dump(dict(responder_rate=resp, harm_rate=harm, adherence=adh_m, chi2=float(ch.statistic), chi2_p=float(ch.pvalue),
                   n_per_arm=int((arm == 0).sum()),
                   anova_p=float(stats.f_oneway(*[B[arm == a] for a in range(4)]).pvalue)),
              open(os.path.join(RES, "trial_overview.json"), "w"), indent=1)
    print("trial done", resp, flush=True)


if __name__ == "__main__":
    main()
