"""All data figures of the paper (matplotlib, 300 dpi PNG + PDF)."""
import os, sys, json, glob, pickle
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures"); RAW = os.path.join(ROOT, "data", "raw")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# reference categorical palette (validated order), text and surface tokens
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, MUTED, GRID = "#0b0b0b", "#52514e", "#8a8984", "#e6e5e1"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.titlesize": 10, "axes.titleweight": "bold",
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.6, "legend.frameon": False, "lines.linewidth": 2.0, "figure.dpi": 100,
                     "savefig.dpi": 300, "savefig.bbox": "tight"})


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"))
    fig.savefig(os.path.join(FIG, name + ".pdf"))
    plt.close(fig)


def panel(ax, letter):
    ax.text(-0.14, 1.06, letter, transform=ax.transAxes, fontsize=12, fontweight="bold", color=INK, va="bottom")


# ------------------------------------------------------------------ Fig 4 cohort
def fig_cohort():
    b = pd.read_csv(os.path.join(RAW, "dev_baseline_phenotype.csv"))
    act = np.load(os.path.join(RAW, "dev_actigraphy.npy"))
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.6), gridspec_kw=dict(width_ratios=[1.25, 1, 1]))
    # (a) actogram of a late chronotype student
    i = int(np.argmin(np.abs(b.msf_sc.values - 6.8)))
    ax = axs[0]
    im = ax.imshow(np.log1p(act[i].reshape(14, 24)), aspect="auto", cmap="Blues", origin="upper",
                   extent=[0, 24, 14.5, 0.5])
    ax.set_xlabel("Clock time (h)"); ax.set_ylabel("Day"); ax.grid(False)
    ax.set_title(f"Actogram, late chronotype (MSF$_{{sc}}$ = {b.msf_sc[i]:.1f} h)")
    ax.set_xticks(range(0, 25, 4))
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.set_label("log(1 + counts)", color=INK2); cb.outline.set_visible(False)
    panel(ax, "a")
    # (b) 24-h profiles by chronotype tertile
    ax = axs[1]
    t = pd.qcut(b.msf_sc, 3, labels=["Early", "Intermediate", "Late"])
    prof = act.reshape(len(b), 14, 24).mean(1)
    for k, (lab, c) in enumerate(zip(["Early", "Intermediate", "Late"], [PAL[0], PAL[2], PAL[1]])):
        m = prof[t.values == lab].mean(0); s = prof[t.values == lab].std(0) / np.sqrt((t.values == lab).sum())
        ax.plot(np.arange(24) + 0.5, m, color=c, label=f"{lab} (n={int((t.values == lab).sum())})")
        ax.fill_between(np.arange(24) + 0.5, m - 1.96 * s, m + 1.96 * s, color=c, alpha=0.18, lw=0)
    ax.set_xlabel("Clock time (h)"); ax.set_ylabel("Mean activity (counts/h)"); ax.set_xticks(range(0, 25, 4))
    ax.set_title("24-h rest-activity profile by chronotype"); ax.legend(loc="upper left", fontsize=8); panel(ax, "b")
    # (c) chronotype vs social jetlag coloured by HOMA-IR tertile
    ax = axs[2]
    ht = pd.qcut(b.homa_ir, 3, labels=["low", "mid", "high"])
    for lab, c in zip(["low", "mid", "high"], [PAL[0], PAL[2], PAL[1]]):
        mm = ht.values == lab
        ax.scatter(b.msf_sc[mm], b.social_jetlag[mm], s=9, color=c, alpha=0.55, lw=0, label=f"HOMA-IR {lab}")
    z = np.polyfit(b.msf_sc, b.social_jetlag, 1); xx = np.linspace(2.5, 9, 10)
    ax.plot(xx, np.polyval(z, xx), color=INK2, lw=1.4, ls="--")
    r = np.corrcoef(b.msf_sc, b.social_jetlag)[0, 1]
    ax.text(0.03, 0.95, f"r = {r:.2f}", transform=ax.transAxes, color=INK2, va="top")
    ax.set_xlabel("Chronotype MSF$_{sc}$ (h)"); ax.set_ylabel("Social jetlag (h)")
    ax.set_title("Chronotype, social jetlag and insulin resistance"); ax.legend(fontsize=8, loc="lower right", markerscale=2)
    panel(ax, "c")
    fig.tight_layout()
    save(fig, "Fig4_cohort_characteristics")


# ------------------------------------------------------------------ Fig 5 benchmark
def fig_benchmark():
    cur = json.load(open(os.path.join(RES, "benchmark_curves.json")))
    desc = pd.read_csv(os.path.join(RES, "benchmark_summary.csv")).drop_duplicates("func").set_index("func").desc
    funcs = ["F1", "F5", "F7", "F9", "F10", "F11"]
    algs = ["CLO-GWO", "GWO", "mGWO", "PSO", "DE", "GA", "WOA"]
    fig, axs = plt.subplots(2, 3, figsize=(12, 6.4))
    for ax, fn, L in zip(axs.ravel(), funcs, "abcdef"):
        for k, a in enumerate(algs):
            c = np.array(cur[f"{fn}|{a}"])
            ax.plot(c[:, 0] / 1000, np.maximum(c[:, 1], 1e-16), color=PAL[k], lw=2.4 if a == "CLO-GWO" else 1.4,
                    label=a, zorder=5 if a == "CLO-GWO" else 2)
        ax.set_yscale("log"); ax.set_title(f"{fn}: {desc[fn]}"); ax.set_xlabel("Function evaluations (x10$^3$)")
        ax.set_ylabel("Median best error"); panel(ax, L)
    axs[0, 0].legend(ncol=2, fontsize=7.5, loc="lower left")
    fig.tight_layout()
    save(fig, "Fig5_benchmark_convergence")


# ------------------------------------------------------------------ CV results loader
def load_cv():
    rows = []
    for f in glob.glob(os.path.join(RES, "cv", "*.json")):
        r = json.load(open(f))
        if os.path.basename(f).startswith("TAB_"):
            r["model"] = r["model"] + (" (rel)" if r.get("rel") else "")
        rows.append(r)
    return pd.DataFrame(rows)


def fig_prediction():
    from paper_tables import prediction_table
    from simulator import OUT_LABELS, bmhi
    from exp_predict import fold_split
    from train import Cohort, fit_blend, blend
    rows = [r for r in prediction_table() if "ceiling" not in r["name"]]
    names = [r["name"].replace("**", "") for r in rows]
    fig = plt.figure(figsize=(15, 5.4))
    gs = fig.add_gridspec(1, 4, width_ratios=[1.0, 1.25, 0.04, 0.85], wspace=0.14)
    ax = fig.add_subplot(gs[0])
    y = np.arange(len(rows))
    b = np.array([np.mean(r["bmhi_r2"]) for r in rows]); bs = np.array([np.std(r["bmhi_r2"], ddof=1) for r in rows])
    cr = np.array([np.mean(r["cf_rho"]) for r in rows]); cs = np.array([np.std(r["cf_rho"], ddof=1) for r in rows])
    mr = np.array([np.mean(r["mean_r2"]) for r in rows]); mrs = np.array([np.std(r["mean_r2"], ddof=1) for r in rows])
    ax.barh(y - 0.27, b, 0.26, xerr=bs, color=PAL[0], label="BMHI R$^2$", error_kw=dict(lw=0.7, ecolor=INK2))
    ax.barh(y, cr, 0.26, xerr=cs, color=PAL[2], label="Counterfactual $\\rho$", error_kw=dict(lw=0.7, ecolor=INK2))
    ax.barh(y + 0.27, mr, 0.26, xerr=mrs, color=PAL[3], label="Mean R$^2$ (9 outcomes)", error_kw=dict(lw=0.7, ecolor=INK2))
    ax.set_yticks(y); ax.set_yticklabels(names, fontsize=7.5); ax.invert_yaxis(); ax.set_xlim(0, 1)
    ax.legend(fontsize=7.5, loc="upper center", bbox_to_anchor=(0.45, -0.07), ncol=3, columnspacing=0.8, handlelength=1.2)
    ax.set_title("Accuracy (5-fold CV)"); ax.grid(axis="y", visible=False)
    panel(ax, "a")
    ax = fig.add_subplot(gs[1])
    R = np.array([np.mean(r["r2"], 0) for r in rows])
    im = ax.imshow(R, cmap="Blues", vmin=0, vmax=max(0.6, R.max()), aspect="auto")
    ax.set_yticks(range(len(rows))); ax.set_yticklabels([])          # same row order as panel a
    ax.set_xticks(range(9)); ax.set_xticklabels([o.split(" (")[0] for o in OUT_LABELS], rotation=40, ha="right", fontsize=8)
    for i_ in range(R.shape[0]):
        for j_ in range(R.shape[1]):
            ax.text(j_, i_, f"{R[i_, j_]:.2f}", ha="center", va="center", fontsize=6.3, color="white" if R[i_, j_] > 0.38 else INK)
    ax.grid(False); ax.set_title("Per-outcome R$^2$ (5-fold CV)")
    cb = fig.colorbar(im, cax=fig.add_subplot(gs[2])); cb.outline.set_visible(False)
    panel(ax, "b")
    ax = fig.add_subplot(gs[3])
    pos = ax.get_position(); ax.set_position([pos.x0 + 0.05, pos.y0, pos.width - 0.05, pos.height])
    coh = Cohort("dev_")
    obs, pre = [], []
    for k in range(5):
        P = sorted(glob.glob(os.path.join(RES, "cv", f"CHRONO-RAGAT__f{k}__s*_pred.npy")))
        if not P:
            continue
        fit_idx, val_idx, te = fold_split(coh, k)
        Yp = np.mean([np.load(p) for p in P], 0); Yv = np.mean([np.load(p.replace("_pred", "_val")) for p in P], 0)
        tb = dict(np.load(os.path.join(RES, "cv", f"TREE__f{k}.npz")))
        w = fit_blend(tb["val"], Yv, coh.Y[val_idx])
        pre.append(bmhi(blend(w, tb["test"], Yp))); obs.append(bmhi(coh.Y[te]))
    obs, pre = np.concatenate(obs), np.concatenate(pre)
    ax.scatter(obs, pre, s=5, color=PAL[0], alpha=0.35, lw=0)
    lim = [min(obs.min(), pre.min()), max(obs.max(), pre.max())]
    ax.plot(lim, lim, color=INK2, lw=1, ls="--")
    r2 = 1 - ((pre - obs) ** 2).sum() / ((obs - obs.mean()) ** 2).sum()
    ax.text(0.04, 0.95, f"pooled R$^2$ = {r2:.3f}\nn = {len(obs)}", transform=ax.transAxes, va="top", color=INK2)
    ax.set_xlabel("Observed BMHI change"); ax.set_ylabel("Predicted BMHI change")
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal", adjustable="box")
    ax.set_title("Stacked CHRONO-RAGAT (3-seed)", pad=14)
    ax.text(-0.32, 1.06, "c", transform=ax.transAxes, fontsize=12, fontweight="bold", color=INK, va="bottom")
    save(fig, "Fig7_prediction_performance")
    return r2


def fig_ablation():
    from paper_tables import ablation_table
    _, a = ablation_table()
    fig, axs = plt.subplots(1, 3, figsize=(14, 4.0), sharey=True)
    y = np.arange(len(a))
    for ax, col, sc, title, L, c in [(axs[0], "db", "dbs", "$\\Delta$ BMHI R$^2$", "a", PAL[0]),
                                     (axs[1], "dm", "dms", "$\\Delta$ mean R$^2$ (9 outcomes)", "b", PAL[3]),
                                     (axs[2], "dc", "dcs", "$\\Delta$ counterfactual $\\rho$", "c", PAL[2])]:
        ax.barh(y, a[col], 0.6, xerr=a[sc], color=c, error_kw=dict(lw=0.8, ecolor=INK2))
        ax.axvline(0, color=INK2, lw=1); ax.set_title(title + " vs. full model"); ax.grid(axis="y", visible=False); panel(ax, L)
    axs[0].set_yticks(y); axs[0].set_yticklabels(a.name, fontsize=8); axs[0].invert_yaxis()
    fig.tight_layout()
    save(fig, "Fig8_ablation")
    return a


def fig_hpo():
    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    for k, (m, c) in enumerate([("CLO-GWO", PAL[0]), ("RS", PAL[1])]):
        p = os.path.join(RES, f"hpo_log_{'CLO-GWO' if m == 'CLO-GWO' else 'Random'}.csv")
        if not os.path.exists(p):
            continue
        d = pd.read_csv(p)
        ax.plot(d["eval"], d.val_loss, "o", color=c, ms=3.5, alpha=0.45)
        ax.plot(d["eval"], d.val_loss.cummin(), color=c, lw=2, label=("CLO-GWO" if m == "CLO-GWO" else "Random search"))
    ax.set_xlabel("Training runs (reduced fidelity)"); ax.set_ylabel("Validation loss"); ax.legend()
    ax.set_title("Hyper-parameter search for CHRONO-RAGAT")
    fig.tight_layout(); save(fig, "Fig6_hpo_convergence")


def fig_prescription():
    cur = json.load(open(os.path.join(RES, "prescription_curves.json")))
    df = pd.read_csv(os.path.join(RES, "prescription_results.csv"))
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.2), gridspec_kw=dict(width_ratios=[1, 1.35]))
    ax = axs[0]
    for k, (a, c) in enumerate(cur.items()):
        c = np.array(c)
        ax.plot(c[:, 0], c[:, 1], color=PAL[k % 8], lw=2.4 if a == "CLO-GWO" else 1.3, label=a, zorder=5 if a == "CLO-GWO" else 2,
                ls="-" if k < 8 else "--")
    ax.set_xlabel("Surrogate evaluations per student"); ax.set_ylabel("Mean surrogate objective  $\\mu-\\kappa\\sigma$")
    ax.set_title("Prescription search convergence (n = 240)"); ax.legend(fontsize=7.5, ncol=2, loc="lower right"); panel(ax, "a")
    ax.set_xlim(0, 1200)
    lo = np.percentile(np.concatenate([c[:, 1] for c in map(np.array, cur.values())]), 5)
    ax.set_ylim(bottom=lo)
    ax = axs[1]
    order = ["Usual habits (no programme)", "Guideline (150 min/wk, 12-h window)", "Rule-based chrono-matched",
             "One-size-fits-all AI plan", "Tree expert only", "Network only", "Random search", "GWO", "PSO", "DE", "GA",
             "CLO-GWO", "Oracle (true simulator)"]
    files = {"Usual habits (no programme)": "Usual_habits", "Guideline (150 min/wk, 12-h window)": "Guideline",
             "Rule-based chrono-matched": "Rule-based_chrono-matched", "One-size-fits-all AI plan": "One-size-fits-all_AI_plan",
             "Oracle (true simulator)": "Oracle", "Tree expert only": "GBT_surrogate", "Network only": "Network_only"}
    data, labs = [], []
    for o in order:
        fn = os.path.join(RES, f"presc_true_bmhi_{files.get(o, o.replace(' ', '_'))}.npy")
        if os.path.exists(fn):
            data.append(np.load(fn)); labs.append(o.replace(" (150 min/wk, 12-h window)", "").replace(" (true simulator)", "")
                                                  .replace("CLO-GWO", "Proposed (stacked + CLO-GWO)"))
    cols = [MUTED] * 4 + [PAL[6]] * 2 + [PAL[3]] * (len(data) - 8) + [PAL[0], PAL[5]]
    bp = ax.boxplot(data, patch_artist=True, widths=0.6, showfliers=False, medianprops=dict(color=INK, lw=1.3))
    for p_, c in zip(bp["boxes"], cols):
        p_.set_facecolor(c); p_.set_alpha(0.85); p_.set_edgecolor("white")
    ax.plot(np.arange(1, len(data) + 1), [d.mean() for d in data], "D", color=INK, ms=4, label="mean")
    ax.set_xticks(np.arange(1, len(data) + 1)); ax.set_xticklabels(labs, rotation=35, ha="right", fontsize=8)
    ax.set_ylabel("True 12-week BMHI improvement"); ax.axhline(0, color=INK2, lw=0.8)
    ax.set_title("Counterfactual decision quality on held-out students"); ax.legend(loc="upper left"); panel(ax, "b")
    fig.tight_layout(); save(fig, "Fig9_prescription_optimisation")


def fig_personalisation():
    from train import Cohort
    sol = pickle.load(open(os.path.join(RES, "prescription_solutions.pkl"), "rb"))
    b = pd.read_csv(os.path.join(RAW, "dev_baseline_phenotype.csv")).iloc[sol["q"]]
    lat = pd.read_csv(os.path.join(RAW, "dev_latent_ground_truth.csv")).iloc[sol["q"]]
    ai, orc = sol["sols"]["CLO-GWO"], sol["sols"]["Oracle"]
    land = pd.read_csv(os.path.join(RES, "timing_landscape.csv"))
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.8))
    ax = axs[0]
    ax.scatter(b.msf_sc, orc[:, 0], s=12, color=PAL[5], alpha=0.6, lw=0, label="Oracle")
    ax.scatter(b.msf_sc, ai[:, 0], s=12, color=PAL[0], alpha=0.6, lw=0, label="CHRONO-RAGAT + CLO-GWO")
    for X, c in [(orc, PAL[5]), (ai, PAL[0])]:
        z = np.polyfit(b.msf_sc, X[:, 0], 1); xx = np.linspace(b.msf_sc.min(), b.msf_sc.max(), 5)
        ax.plot(xx, np.polyval(z, xx), color=c, lw=1.6)
    r = np.corrcoef(b.msf_sc, ai[:, 0])[0, 1]
    ax.set_xlabel("Chronotype MSF$_{sc}$ (h)"); ax.set_ylabel("Prescribed exercise start (clock h)")
    ax.set_title(f"Exercise timing tracks chronotype (r = {r:.2f})"); ax.legend(fontsize=7.5, loc="upper left"); panel(ax, "a")
    ax = axs[1]
    st = lat.stress_z.values
    ax.scatter(st, orc[:, 1], s=12, color=PAL[5], alpha=0.6, lw=0, label="Oracle")
    ax.scatter(st, ai[:, 1], s=12, color=PAL[0], alpha=0.6, lw=0, label="CHRONO-RAGAT + CLO-GWO")
    for X, c in [(orc, PAL[5]), (ai, PAL[0])]:
        z = np.polyfit(st, X[:, 1], 1); xx = np.linspace(st.min(), st.max(), 5); ax.plot(xx, np.polyval(z, xx), color=c, lw=1.6)
    r = np.corrcoef(st, ai[:, 1])[0, 1]
    ax.set_xlabel("Academic stress (z)"); ax.set_ylabel("Prescribed intensity (%HRR)")
    ax.set_title(f"Intensity de-escalates with stress (r = {r:.2f})"); panel(ax, "b")
    ax = axs[2]
    for k, (sid, g) in enumerate(land.groupby("student", sort=False)):
        c = [PAL[0], PAL[2], PAL[1]][k]
        lab = ["Early", "Intermediate", "Late"][k] + f" (MSF {g.msf.iloc[0]:.1f} h)"
        ax.plot(g.ex_time, g.pred_mu, color=c, lw=2, label=lab)
        ax.fill_between(g.ex_time, g.pred_mu - g.pred_sd, g.pred_mu + g.pred_sd, color=c, alpha=0.18, lw=0)
        ax.plot(g.ex_time, g.true_bmhi, color=c, lw=1.2, ls="--")
    ax.add_artist(ax.legend(fontsize=7.5, loc="upper left"))
    ax.legend([Line2D([], [], color=INK2, lw=2), Line2D([], [], color=INK2, lw=1.2, ls="--")],
              ["predicted $\\mu\\pm\\sigma$", "true response"], fontsize=7.5, loc="upper right")
    ax.set_xlabel("Exercise start time (clock h)"); ax.set_ylabel("BMHI improvement")
    ax.set_title("Timing landscape (other variables at optimum)"); panel(ax, "c")
    fig.tight_layout(); save(fig, "Fig10_personalisation")


def fig_trial():
    s = pd.read_csv(os.path.join(RES, "trial_summary.csv"))
    ov = json.load(open(os.path.join(RES, "trial_overview.json")))
    from simulator import OUTCOMES, OUT_LABELS
    lab = dict(zip(OUTCOMES, OUT_LABELS)); lab["bmhi"] = "BMHI (composite)"
    fig, axs = plt.subplots(1, 2, figsize=(12, 4.2), gridspec_kw=dict(width_ratios=[1.5, 1]))
    ax = axs[0]
    y = np.arange(len(s))
    for k, (tag, c, nm) in enumerate([("vs_control", PAL[1], "vs. control"), ("vs_guideline", PAL[0], "vs. guideline"),
                                      ("vs_rule", PAL[2], "vs. rule-based")]):
        d = s[f"d_{tag}"].values
        # CI on Cohen's d via SE of difference scaled by pooled SD
        scale = s[f"diff_{tag}"].values / np.where(d == 0, 1, d)
        lo = s[f"ci_lo_{tag}"].values / scale; hi = s[f"ci_hi_{tag}"].values / scale
        ax.errorbar(d, y + (k - 1) * 0.22, xerr=[d - lo, hi - d], fmt="o", color=c, ms=4.5, lw=1.2, capsize=0, label=nm)
    ax.axvline(0, color=INK2, lw=1)
    ax.set_yticks(y); ax.set_yticklabels([lab[o] for o in s.outcome], fontsize=8.5); ax.invert_yaxis()
    ax.set_xlabel("Standardised effect of AI-personalised arm (Cohen's d, 95% CI)\n(sign: positive = larger raw value)")
    ax.set_title("In-silico RCT: AI-personalised arm vs. comparators"); ax.legend(fontsize=8, loc="lower right"); panel(ax, "a")
    ax.grid(axis="y", visible=False)
    ax = axs[1]
    names = list(ov["responder_rate"].keys())
    short = ["Control", "Guideline", "Rule-based", "AI-personalised"]
    rr = [100 * ov["responder_rate"][n] for n in names]; hr = [100 * ov["harm_rate"][n] for n in names]
    x = np.arange(4)
    ax.bar(x - 0.2, rr, 0.38, color=PAL[0], label="Responders (BMHI $\\geq$ 1)")
    ax.bar(x + 0.2, hr, 0.38, color=PAL[1], label="Worsened (BMHI < 0)")
    for i in range(4):
        ax.text(x[i] - 0.2, rr[i] + 1, f"{rr[i]:.0f}%", ha="center", fontsize=8, color=INK2)
        ax.text(x[i] + 0.2, hr[i] + 1, f"{hr[i]:.0f}%", ha="center", fontsize=8, color=INK2)
    ax.set_xticks(x); ax.set_xticklabels(short, fontsize=8.5); ax.set_ylabel("% of participants")
    ax.set_title(f"Responder and worsening rates (n = {ov['n_per_arm']}/arm)"); ax.legend(fontsize=8, loc="upper right")
    ax.set_ylim(0, max(max(rr), max(hr)) * 1.18)
    ax.grid(axis="x", visible=False); panel(ax, "b")
    fig.tight_layout(); save(fig, "Fig12_insilico_RCT")


def fig_interpret():
    A = np.load(os.path.join(RES, "attn_cls_hour.npy")); msf = np.load(os.path.join(RES, "attn_msf.npy"))
    imp = pd.read_csv(os.path.join(RES, "prescription_permutation_importance.csv"))
    ks = pd.read_csv(os.path.join(RES, "kappa_sensitivity.csv"))
    fig, axs = plt.subplots(1, 3, figsize=(13, 3.8), gridspec_kw=dict(width_ratios=[1, 1.15, 1]))
    ax = axs[0]
    t = pd.qcut(msf, 3, labels=["Early", "Intermediate", "Late"])
    for lab, c in zip(["Early", "Intermediate", "Late"], [PAL[0], PAL[2], PAL[1]]):
        m = A[np.asarray(t) == lab].mean(0)
        ax.plot(np.arange(24) + 0.5, m / m.sum(), color=c, label=lab)
    ax.set_xticks(range(0, 25, 4)); ax.set_xlabel("Clock hour token"); ax.set_ylabel("Normalised [CLS] attention")
    ax.set_title("Temporal attention over the 24-h cycle"); ax.legend(fontsize=8); panel(ax, "a")
    ax = axs[1]
    imp = imp.sort_values("true_drop")
    y = np.arange(len(imp))
    ax.barh(y + 0.2, imp.pred_drop, 0.38, color=PAL[0], label="model-predicted drop")
    ax.barh(y - 0.2, imp.true_drop, 0.38, color=PAL[5], label="true (simulator) drop")
    ax.set_yticks(y); ax.set_yticklabels([g.replace(" (intensity, duration, frequency, HIIT)", "\n(intensity, duration, freq., HIIT)")
                                          for g in imp.group], fontsize=8)
    ax.set_xlabel("BMHI loss when component is permuted"); ax.set_title("Which prescription components matter"); ax.legend(fontsize=7.5)
    ax.grid(axis="y", visible=False); panel(ax, "b")
    ax = axs[2]
    ax.plot(ks.kappa, ks.true_bmhi, "o-", color=PAL[0], label="mean true BMHI")
    ax.plot(ks.kappa, ks.p10_true_bmhi, "s-", color=PAL[2], label="10th percentile")
    ax.set_xlabel("Uncertainty penalty $\\kappa$"); ax.set_ylabel("True BMHI improvement")
    ax.set_title("Robustness: optimism vs. caution"); ax.legend(fontsize=8, loc="center right"); panel(ax, "c")
    fig.tight_layout(); save(fig, "Fig11_interpretability")


if __name__ == "__main__":
    which = sys.argv[1:] or ["cohort", "benchmark"]
    for w in which:
        globals()["fig_" + w]()
        print("fig", w)
