"""
Batched population-based optimisers. Every optimiser solves S independent minimisation problems in
parallel (S = independent runs for benchmarking, or S = students for prescription optimisation).

    f : callable (S, P, D) -> (S, P)       objective to MINIMISE
    lb, ub : (D,) bounds
Returns best_x (S, D), best_f (S,), curve (list of (fe, best_f (S,)))

Proposed: CLO-GWO  (Circadian-oscillation, Levy-flight, Opposition-based Grey Wolf Optimizer)
  1. tent-chaotic initialisation + opposition-based learning (OBL) population selection
  2. circadian-oscillatory convergence factor a(t) = 2 cos^2(pi t / 2T) [1 + A sin(2 pi omega t / T)]
     -> alternating exploration / exploitation pulses instead of a linear decay
  3. fitness-weighted leader fusion (alpha, beta, delta weights from relative fitness)
  4. greedy survivor selection (a wolf only moves if its new position is better)
  5. Levy-flight refinement of the alpha wolf (heavy-tailed jumps, annealed step)
  6. (optional, off by default) elite opposition-based learning (EOBL) for the worst 20 % of the pack -
     evaluated in the ablation and excluded because it did not improve results
  7. stagnation-triggered partial restart around the alpha
  8. shift-invariant encircling |C o (L - X)| instead of |C o L - X| (removes the origin bias of GWO)
  9. dimension-learning hunting (neighbourhood-based, per-dimension learning; best of GWO / DLH move)
Baselines: GWO, mGWO (nonlinear a), PSO, DE/rand/1/bin, real-coded GA, WOA, random search.
"""
import numpy as np
from math import gamma, pi, sin


def _levy(rng, shape, beta=1.5):
    sig = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = rng.normal(0, sig, shape)
    v = rng.normal(0, 1, shape)
    return u / np.abs(v) ** (1 / beta)


class _Tracker:
    def __init__(self, S, budget, n_ckpt=100):
        self.fe = 0
        self.budget = budget
        self.best = np.full(S, np.inf)
        self.bx = None
        self.curve = []
        self.next = budget / n_ckpt
        self.step = budget / n_ckpt

    def update(self, X, F, nfe, rows=None):
        """nfe = evaluations charged PER PROBLEM; rows = subset of problems updated (None = all)."""
        self.fe += nfe
        if rows is not None:
            j = F.argmin(1)
            fb = F[np.arange(F.shape[0]), j]
            xb = X[np.arange(F.shape[0]), j]
            better = fb < self.best[rows]
            r = np.asarray(rows)[better]
            self.bx[r] = xb[better]
            self.best[r] = fb[better]
            self._ckpt()
            return
        j = F.argmin(1)
        fb = F[np.arange(F.shape[0]), j]
        better = fb < self.best
        if self.bx is None:
            self.bx = X[np.arange(F.shape[0]), j].copy()
        self.bx[better] = X[np.arange(F.shape[0]), j][better]
        self.best = np.minimum(self.best, fb)
        self._ckpt()

    def _ckpt(self):
        while self.fe >= self.next - 1e-9:
            self.curve.append((self.next, self.best.copy()))
            self.next += self.step

    def done(self):
        return self.fe >= self.budget


def _init(rng, S, P, lb, ub):
    return lb + rng.random((S, P, len(lb))) * (ub - lb)


# ============================================================================ CLO-GWO
def clo_gwo(f, lb, ub, S, P=30, budget=30000, rng=None, omega=3.0, amp=0.25, levy_beta=1.5,
            eobl_frac=0.2, stall=20, use_circ=True, use_levy=True, use_eobl=False, use_greedy=True,
            use_wfuse=True, use_chaos_obl=True, use_sie=True, use_dlh=False):
    rng = rng or np.random.default_rng(0)
    D = len(lb)
    tr = _Tracker(S, budget)
    if use_chaos_obl:
        z = rng.random((S, P, D))
        for _ in range(8):
            z = np.where(z < 0.7, z / 0.7, (1 - z) / 0.3)
            z = np.clip(z, 1e-6, 1 - 1e-6)
        X = lb + z * (ub - lb)
        Xo = lb + ub - X
        F, Fo = f(X), f(Xo)
        tr.update(X, F, P); tr.update(Xo, Fo, P)
        XX = np.concatenate([X, Xo], 1); FF = np.concatenate([F, Fo], 1)
        o = np.argsort(FF, 1)[:, :P]
        X = np.take_along_axis(XX, o[:, :, None], 1); F = np.take_along_axis(FF, o, 1)
    else:
        X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    per_it = P * (2 if use_dlh else 1) + (1 if use_levy else 0) + (int(np.ceil(eobl_frac * P)) if use_eobl else 0)
    T = max(1, int((budget - tr.fe) / per_it))
    t = 0
    last_best = tr.best.copy(); since = np.zeros(S, int)
    ar = np.arange(S)
    while not tr.done():
        frac = min(1.0, t / T)
        if use_circ:
            a = 2 * np.cos(pi * frac / 2) ** 2 * (1 + amp * np.sin(2 * pi * omega * frac))
        else:
            a = 2 - 2 * frac
        o = np.argsort(F, 1)
        L = np.take_along_axis(X, o[:, :3, None], 1)                 # (S,3,D) alpha beta delta
        FL = np.take_along_axis(F, o[:, :3], 1)
        if use_wfuse:
            worst = F.max(1, keepdims=True)
            w = (worst - FL) + 1e-12
            w = w / w.sum(1, keepdims=True)
            w = 0.5 * w + 0.5 / 3                                        # shrink toward equal weights
        else:
            w = np.full((S, 3), 1 / 3)
        Xn = np.zeros_like(X)
        for k in range(3):
            A = 2 * a * rng.random((S, P, D)) - a
            C = 2 * rng.random((S, P, D))
            if use_sie:      # shift-invariant encircling: |C o (L - X)| removes GWO's origin bias
                Dk = np.abs(C * (L[:, k:k + 1] - X))
            else:
                Dk = np.abs(C * L[:, k:k + 1] - X)
            Xn += w[:, k, None, None] * (L[:, k:k + 1] - A * Dk)
        Xn = np.clip(Xn, lb, ub)
        Fn = f(Xn); tr.update(Xn, Fn, P)
        if use_dlh and not tr.done():
            # dimension-learning hunting: learn each dimension from a neighbour inside radius R_i
            R = np.linalg.norm(X - Xn, axis=-1)                                  # (S,P)
            dist = np.linalg.norm(X[:, :, None, :] - X[:, None, :, :], axis=-1)  # (S,P,P)
            inn = dist <= R[:, :, None]
            sc = rng.random((S, P, P)) * inn
            nbr = sc.argmax(-1)                                                  # random neighbour within R
            rr = rng.integers(0, P, (S, P, D))
            Xnb = X[np.arange(S)[:, None, None], nbr[:, :, None], np.arange(D)[None, None, :]]
            Xr = X[np.arange(S)[:, None, None], rr, np.arange(D)[None, None, :]]
            Xd = np.clip(X + rng.random((S, P, D)) * (Xnb - Xr), lb, ub)
            Fd = f(Xd); tr.update(Xd, Fd, P)
            md = Fd < Fn
            Xn = np.where(md[:, :, None], Xd, Xn); Fn = np.where(md, Fd, Fn)
        if use_greedy:
            m = Fn < F
            X = np.where(m[:, :, None], Xn, X); F = np.where(m, Fn, F)
        else:
            X, F = Xn, Fn
        # Levy flight on the alpha
        if use_levy and not tr.done():
            ia = F.argmin(1)
            xa = X[ar, ia]
            r = X[ar, rng.integers(0, P, S)]
            step = 0.05 * (1 - frac) + 0.002
            xl = np.clip(xa + step * _levy(rng, (S, D), levy_beta) * (ub - lb) * np.sign(rng.normal(size=(S, D)))
                         * (0.5 + np.abs(xa - r) / (ub - lb)), lb, ub)
            fl = f(xl[:, None, :])[:, 0]; tr.update(xl[:, None, :], fl[:, None], 1)
            iw = F.argmax(1)
            m = fl < F[ar, iw]
            X[ar[m], iw[m]] = xl[m]; F[ar[m], iw[m]] = fl[m]
        # elite opposition-based learning on the worst wolves
        if use_eobl and not tr.done():
            ne = int(np.ceil(eobl_frac * P))
            o = np.argsort(F, 1)
            elite = np.take_along_axis(X, o[:, :max(3, P // 5), None], 1)
            da, db = elite.min(1, keepdims=True), elite.max(1, keepdims=True)
            wi = o[:, -ne:]
            Xw = np.take_along_axis(X, wi[:, :, None], 1)
            kk = rng.random((S, ne, 1))
            Xe = kk * (da + db) - Xw
            bad = (Xe < lb) | (Xe > ub)
            Xe = np.where(bad, da + rng.random(Xe.shape) * (db - da), Xe)
            Xe = np.clip(Xe, lb, ub)
            Fe = f(Xe); tr.update(Xe, Fe, ne)
            Fw = np.take_along_axis(F, wi, 1)
            m = Fe < Fw
            for s in range(S):
                X[s, wi[s, m[s]]] = Xe[s, m[s]]; F[s, wi[s, m[s]]] = Fe[s, m[s]]
        # stagnation restart
        imp = tr.best < last_best - 1e-12
        since = np.where(imp, 0, since + 1); last_best = tr.best.copy()
        rs = since >= stall
        if rs.any() and not tr.done():
            for s in np.where(rs)[0]:
                o = np.argsort(F[s])
                half = o[P // 2:]
                X[s, half] = np.clip(tr.bx[s] + rng.normal(0, 0.1 * (1 - frac) + 0.01, (len(half), D)) * (ub - lb), lb, ub)
            Xr = X[rs]
            Fr = f(Xr)
            tr.update(Xr, Fr, P - P // 2, rows=np.where(rs)[0])   # charged to every problem (conservative)
            F[rs] = Fr
            since[rs] = 0
        t += 1
    return tr.bx, tr.best, tr.curve


# ============================================================================ GWO / mGWO
def gwo(f, lb, ub, S, P=30, budget=30000, rng=None, nonlinear=False):
    rng = rng or np.random.default_rng(0)
    D = len(lb); tr = _Tracker(S, budget)
    X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    T = max(1, (budget - P) // P)
    t = 0
    while not tr.done():
        frac = min(1.0, t / T)
        a = 2 * (1 - frac ** 2) if nonlinear else 2 - 2 * frac
        o = np.argsort(F, 1)
        L = np.take_along_axis(X, o[:, :3, None], 1)
        Xn = np.zeros_like(X)
        for k in range(3):
            A = 2 * a * rng.random((S, P, D)) - a
            C = 2 * rng.random((S, P, D))
            Xn += (L[:, k:k + 1] - A * np.abs(C * L[:, k:k + 1] - X)) / 3
        X = np.clip(Xn, lb, ub); F = f(X); tr.update(X, F, P)
        t += 1
    return tr.bx, tr.best, tr.curve


def mgwo(f, lb, ub, S, P=30, budget=30000, rng=None):
    return gwo(f, lb, ub, S, P, budget, rng, nonlinear=True)


# ============================================================================ PSO
def pso(f, lb, ub, S, P=30, budget=30000, rng=None, w0=0.9, w1=0.4, c1=2.0, c2=2.0):
    rng = rng or np.random.default_rng(0)
    D = len(lb); tr = _Tracker(S, budget)
    X = _init(rng, S, P, lb, ub); V = np.zeros_like(X)
    F = f(X); tr.update(X, F, P)
    pb, pf = X.copy(), F.copy()
    T = max(1, (budget - P) // P); t = 0
    vmax = 0.2 * (ub - lb)
    while not tr.done():
        w = w0 - (w0 - w1) * min(1, t / T)
        g = pb[np.arange(S), pf.argmin(1)][:, None, :]
        V = w * V + c1 * rng.random(X.shape) * (pb - X) + c2 * rng.random(X.shape) * (g - X)
        V = np.clip(V, -vmax, vmax)
        X = np.clip(X + V, lb, ub)
        F = f(X); tr.update(X, F, P)
        m = F < pf
        pb = np.where(m[:, :, None], X, pb); pf = np.where(m, F, pf)
        t += 1
    return tr.bx, tr.best, tr.curve


# ============================================================================ DE
def de(f, lb, ub, S, P=30, budget=30000, rng=None, Fw=0.5, CR=0.9):
    rng = rng or np.random.default_rng(0)
    D = len(lb); tr = _Tracker(S, budget)
    X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    while not tr.done():
        idx = np.stack([rng.permutation(P) for _ in range(3)], -1)        # (P,3)
        r1, r2, r3 = X[:, idx[:, 0]], X[:, idx[:, 1]], X[:, idx[:, 2]]
        Vm = np.clip(r1 + Fw * (r2 - r3), lb, ub)
        cr = rng.random((S, P, D)) < CR
        jr = rng.integers(0, D, (S, P))
        cr[np.arange(S)[:, None], np.arange(P)[None], jr] = True
        U = np.where(cr, Vm, X)
        Fu = f(U); tr.update(U, Fu, P)
        m = Fu <= F
        X = np.where(m[:, :, None], U, X); F = np.where(m, Fu, F)
    return tr.bx, tr.best, tr.curve


# ============================================================================ GA
def ga(f, lb, ub, S, P=30, budget=30000, rng=None, pc=0.9, eta_c=15, eta_m=20):
    rng = rng or np.random.default_rng(0)
    D = len(lb); tr = _Tracker(S, budget)
    X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    pm = 1.0 / D
    ar = np.arange(S)[:, None]
    while not tr.done():
        a, b = rng.integers(0, P, (S, P)), rng.integers(0, P, (S, P))
        par = np.where(F[ar, a] < F[ar, b], a, b)
        M = X[ar, par]
        # SBX crossover on consecutive pairs
        u = rng.random((S, P // 2, D))
        beta = np.where(u <= 0.5, (2 * u) ** (1 / (eta_c + 1)), (1 / (2 * (1 - u))) ** (1 / (eta_c + 1)))
        p1, p2 = M[:, 0::2][:, :P // 2], M[:, 1::2][:, :P // 2]
        do = rng.random((S, P // 2, 1)) < pc
        c1 = np.where(do, 0.5 * ((1 + beta) * p1 + (1 - beta) * p2), p1)
        c2 = np.where(do, 0.5 * ((1 - beta) * p1 + (1 + beta) * p2), p2)
        C = np.concatenate([c1, c2], 1)
        if C.shape[1] < P:
            C = np.concatenate([C, M[:, -1:]], 1)
        # polynomial mutation
        u = rng.random(C.shape)
        dl = np.where(u < 0.5, (2 * u) ** (1 / (eta_m + 1)) - 1, 1 - (2 * (1 - u)) ** (1 / (eta_m + 1)))
        mm = rng.random(C.shape) < pm
        C = np.clip(C + mm * dl * (ub - lb), lb, ub)
        Fc = f(C); tr.update(C, Fc, P)
        # elitism: keep the best parent
        ib = F.argmin(1); iw = Fc.argmax(1)
        C[np.arange(S), iw] = X[np.arange(S), ib]; Fc[np.arange(S), iw] = F[np.arange(S), ib]
        X, F = C, Fc
    return tr.bx, tr.best, tr.curve


# ============================================================================ WOA
def woa(f, lb, ub, S, P=30, budget=30000, rng=None, b=1.0):
    rng = rng or np.random.default_rng(0)
    D = len(lb); tr = _Tracker(S, budget)
    X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    T = max(1, (budget - P) // P); t = 0
    while not tr.done():
        a = 2 - 2 * min(1, t / T)
        best = X[np.arange(S), F.argmin(1)][:, None, :]
        A = 2 * a * rng.random((S, P, 1)) - a
        C = 2 * rng.random((S, P, 1))
        p = rng.random((S, P, 1))
        l = rng.uniform(-1, 1, (S, P, 1))
        rnd = X[np.arange(S)[:, None], rng.integers(0, P, (S, P))]
        enc = np.where(np.abs(A) < 1, best - A * np.abs(C * best - X), rnd - A * np.abs(C * rnd - X))
        spi = np.abs(best - X) * np.exp(b * l) * np.cos(2 * np.pi * l) + best
        X = np.clip(np.where(p < 0.5, enc, spi), lb, ub)
        F = f(X); tr.update(X, F, P)
        t += 1
    return tr.bx, tr.best, tr.curve


# ============================================================================ Random search
def random_search(f, lb, ub, S, P=30, budget=30000, rng=None):
    rng = rng or np.random.default_rng(0)
    tr = _Tracker(S, budget)
    while not tr.done():
        X = _init(rng, S, P, lb, ub); F = f(X); tr.update(X, F, P)
    return tr.bx, tr.best, tr.curve


OPTIMIZERS = {"CLO-GWO": clo_gwo, "GWO": gwo, "mGWO": mgwo, "PSO": pso, "DE": de, "GA": ga, "WOA": woa}
