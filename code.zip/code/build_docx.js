// Render paper.json (produced by write_paper.py) into a journal-style .docx manuscript.
// Inline markup in text: **bold**, *italic*, ^{sup}, _{sub}
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType,
  ShadingType, BorderStyle, ImageRun, PageBreak, Footer, PageNumber, LevelFormat, TableLayoutType, VerticalAlign,
} = require("docx");

const [, , inJson, outDocx] = process.argv;
const P = JSON.parse(fs.readFileSync(inJson, "utf8"));
const FONT = "Times New Roman";
const PAGE_W = 11906, MARGIN = 1134;            // A4, 2 cm margins
const TEXT_W = PAGE_W - 2 * MARGIN;

function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^\{[^}]*\}|_\{[^}]*\})/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("*")) out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    else if (t.startsWith("^{")) out.push(new TextRun({ text: t.slice(2, -1), superScript: true, font: FONT, ...base }));
    else out.push(new TextRun({ text: t.slice(2, -1), subScript: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}

const border = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };

function table(blk) {
  const ncol = blk.header.length;
  const widths = blk.widths ? blk.widths.map(w => Math.round(w * TEXT_W)) : Array(ncol).fill(Math.floor(TEXT_W / ncol));
  const diff = TEXT_W - widths.reduce((a, b) => a + b, 0); widths[0] += diff;
  const fs_ = blk.fontsize || 16;
  const mkRow = (cells, header, last) => new TableRow({
    tableHeader: header,
    children: cells.map((c, j) => new TableCell({
      width: { size: widths[j], type: WidthType.DXA },
      verticalAlign: VerticalAlign.CENTER,
      shading: header ? { fill: "E8EEF6", type: ShadingType.CLEAR, color: "auto" } : (blk.highlight && blk.highlight.includes(cells[0]) ? { fill: "FFF4E0", type: ShadingType.CLEAR, color: "auto" } : undefined),
      margins: { top: 40, bottom: 40, left: 70, right: 70 },
      borders: { top: header ? border : none, bottom: (header || last) ? border : none, left: none, right: none },
      children: [new Paragraph({ alignment: j === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
        children: runs(String(c), { size: fs_, bold: header }) })],
    })),
  });
  const rows = [mkRow(blk.header, true, false)];
  blk.rows.forEach((r, i) => rows.push(mkRow(r, false, i === blk.rows.length - 1)));
  return new Table({ width: { size: TEXT_W, type: WidthType.DXA }, columnWidths: widths, rows, layout: TableLayoutType.FIXED });
}

const children = [];
for (const blk of P.blocks) {
  if (blk.type === "title") {
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: runs(blk.text, { size: 32, bold: true }) }));
  } else if (blk.type === "center") {
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80 }, children: runs(blk.text, { size: blk.size || 22 }) }));
  } else if (blk.type === "h1") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: runs(blk.text) }));
  } else if (blk.type === "h2") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: runs(blk.text) }));
  } else if (blk.type === "h3") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: runs(blk.text) }));
  } else if (blk.type === "p") {
    children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120, line: 300 }, children: runs(blk.text, { size: 22 }) }));
  } else if (blk.type === "eq") {
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 100 },
      children: [...runs(blk.text, { size: 22, italics: false }), new TextRun({ text: `\t(${blk.num})`, font: FONT, size: 22 })],
      tabStops: [{ type: "right", position: TEXT_W }] }));
  } else if (blk.type === "bullet") {
    children.push(new Paragraph({ numbering: { reference: "bul", level: 0 }, alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 290 }, children: runs(blk.text, { size: 22 }) }));
  } else if (blk.type === "caption") {
    children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { before: 80, after: 200 }, keepLines: true, children: runs(blk.text, { size: 19 }) }));
  } else if (blk.type === "tcaption") {
    children.push(new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 160, after: 80 }, keepNext: true, children: runs(blk.text, { size: 19 }) }));
  } else if (blk.type === "table") {
    children.push(table(blk));
    if (blk.note) children.push(new Paragraph({ spacing: { before: 40, after: 200 }, children: runs(blk.note, { size: 16 }) }));
    else children.push(new Paragraph({ spacing: { after: 160 }, children: [] }));
  } else if (blk.type === "figure") {
    const data = fs.readFileSync(blk.path);
    const w = Math.round((blk.width || 1.0) * (TEXT_W / 1440) * 96);   // px at 96 dpi
    const h = Math.round(w * blk.ar);
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120 },
      children: [new ImageRun({ type: "png", data, transformation: { width: w, height: h } })] }));
  } else if (blk.type === "ref") {
    children.push(new Paragraph({ spacing: { after: 60 }, indent: { left: 400, hanging: 400 }, alignment: AlignmentType.JUSTIFIED, children: runs(blk.text, { size: 19 }) }));
  } else if (blk.type === "pagebreak") {
    children.push(new Paragraph({ children: [new PageBreak()] }));
  }
}

const doc = new Document({
  creator: "Author", title: P.title,
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 26, bold: true, color: "1F3864" }, paragraph: { spacing: { before: 280, after: 120 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 23, bold: true, color: "1F3864" }, paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 22, bold: true, italics: true }, paragraph: { spacing: { before: 160, after: 80 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18 })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(buf => { fs.writeFileSync(outDocx, buf); console.log("wrote", outDocx); });
