"""Experiment 3: 5-fold cross-validated outcome prediction.
Neural jobs (CHRONO-RAGAT, graph/transformer baselines, ablations) are run by `worker`;
tabular baselines by `tabular`; `aggregate` builds the tables.

Besides accuracy on observed (noisy) outcomes, every model is scored on a decision-relevant
counterfactual task: for each test student, 30 random feasible prescriptions are ranked by the model
and compared with the noise-free simulator response (within-student Spearman rho, top-1 regret)."""
import os, sys, json, time, pickle
import numpy as np, pandas as pd
from scipy.stats import spearmanr
from train import Cohort, Context, fit, predict, FrozenStudent, TreeModel, fit_blend, blend
from simulator import bmhi, response, sample_prescriptions, OUTCOMES

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
CV = os.path.join(RES, "cv")
os.makedirs(CV, exist_ok=True)
K_FOLD, N_CF = 5, 30

ABL = {
    "CHRONO-RAGAT": dict(),
    "w/o temporal encoder": dict(temporal=False),
    "w/o circadian PE": dict(pe=False),
    "w/o graph (Transformer-only)": dict(graph=None),
    "GCN instead of RAGAT": dict(graph="gcn"),
    "GATv2 instead of RAGAT": dict(graph="gat"),
    "raw (non-residual) messages": dict(msg="raw"),
    "w/o cross-attention (concat)": dict(cross=False),
    "w/o uncertainty weighting": dict(uw=False),
    "w/o wide skip": dict(wide=False),
    "w/o baseline-scaled heads": dict(rel=False),
}


def folds(N, seed=2026):
    idx = np.arange(N); rng = np.random.default_rng(seed); rng.shuffle(idx)
    return np.array_split(idx, K_FOLD)


def cf_set(coh, te, seed=0):
    """Counterfactual prescriptions and their noise-free BMHI for test students."""
    rng = np.random.default_rng(seed)
    rows = np.repeat(te, N_CF)
    X = sample_prescriptions(len(rows), coh.b.bmi.values[rows], rng)
    b = coh.b.iloc[rows].reset_index(drop=True); l = coh.lat.iloc[rows].reset_index(drop=True)
    Yt, _ = response(b, l, X, None, noise=False)
    return rows, X, bmhi(Yt)


def cf_metrics(pred_b, true_b, n):
    P = pred_b.reshape(n, N_CF); T = true_b.reshape(n, N_CF)
    rho = np.array([spearmanr(P[i], T[i])[0] for i in range(n)])
    j = P.argmax(1)
    regret = T.max(1) - T[np.arange(n), j]
    return float(np.nanmean(rho)), float(regret.mean())


def metrics(Yp, Y):
    r2 = 1 - ((Yp - Y) ** 2).sum(0) / ((Y - Y.mean(0)) ** 2).sum(0)
    rmse = np.sqrt(((Yp - Y) ** 2).mean(0))
    mae = np.abs(Yp - Y).mean(0)
    bp, bt = bmhi(Yp), bmhi(Y)
    return dict(r2=r2.tolist(), rmse=rmse.tolist(), mae=mae.tolist(), mean_r2=float(r2.mean()),
                bmhi_r2=float(1 - ((bp - bt) ** 2).sum() / ((bt - bt.mean()) ** 2).sum()),
                bmhi_rmse=float(np.sqrt(((bp - bt) ** 2).mean())), bmhi_rho=float(spearmanr(bp, bt)[0]))


def load_hp():
    p = os.path.join(RES, "hpo_best_CLO-GWO.json")
    if os.path.exists(p):
        hp = json.load(open(p))["best"]
        # reduced-fidelity HPO (<= 60 epochs, 960 students) favours large learning rates that stop full-fidelity
        # training prematurely; full-fidelity training therefore uses lr = 1e-3 with all other selected values
        hp["lr_hpo"] = hp["lr"]
        hp["lr"] = 1e-3
        return hp
    return dict(lr=1e-3, d=24, dropout=0.2, wd=1e-3, k=10, lam_bmhi=0.5, beta_base=0.5, batch=64)


_TREES = {}


def fold_split(coh, fold):
    F = folds(coh.n)
    te = F[fold]
    tr = np.concatenate([F[j] for j in range(K_FOLD) if j != fold])
    tr = np.random.default_rng(fold).permutation(tr)
    nv = int(0.125 * len(tr))
    return tr[nv:], tr[:nv], te                         # fit, val, test


def tree_branch(coh, fold):
    """Boosted-tree branch of the fold (trained on the fit students only); predictions cached on disk."""
    p = os.path.join(CV, f"TREE__f{fold}.npz")
    if os.path.exists(p):
        return dict(np.load(p))
    fit_idx, val_idx, te = fold_split(coh, fold)
    T = TreeModel(coh, fit_idx)                       # (i) fit-only tree -> validation predictions for the weights
    rows, Xcf, tcf = cf_set(coh, te, seed=fold)
    val = T.predict(val_idx, coh.penc[val_idx])
    T = TreeModel(coh, np.concatenate([fit_idx, val_idx]))   # (ii) refit on all training students
    d = dict(val=val, test=T.predict(te, coh.penc[te]), cf=T.predict(rows, coh.penc_for(rows, Xcf)))
    np.savez(p, **d)
    return d


def stacked_metrics(Yv_net, Yp_net, cf_net, tb, coh, fold):
    fit_idx, val_idx, te = fold_split(coh, fold)
    w = fit_blend(tb["val"], Yv_net, coh.Y[val_idx])
    Yp = blend(w, tb["test"], Yp_net)
    res = metrics(Yp, coh.Y[te])
    rows, Xcf, tcf = cf_set(coh, te, seed=fold)
    res["cf_rho"], res["cf_regret"] = cf_metrics(bmhi(blend(w, tb["cf"], cf_net)), tcf, len(te))
    res["omega"] = w.tolist()
    return res, Yp


def run_job(coh, name, fold, seed, hp):
    out = os.path.join(CV, f"{name.replace('/', '_').replace(' ', '_')}__f{fold}__s{seed}.json")
    if os.path.exists(out):
        return
    fit_idx, val_idx, te = fold_split(coh, fold)
    cfg = dict(ABL[name]); cfg.update(d=hp["d"], dropout=hp["dropout"], lam_bmhi=hp["lam_bmhi"], batch=hp.get("batch", 64))
    rel = cfg.pop("rel", True)
    ctx = Context(coh, fit_idx, k=hp["k"], rel=rel)
    t0 = time.time()
    m = fit(ctx, cfg, fit_idx, val_idx, seed=seed, epochs=120, lr=hp["lr"], wd=hp["wd"], patience=16,
            eval_every=2, beta_base=hp["beta_base"])
    ttrain = time.time() - t0
    Yp = predict(m, ctx, te, coh.penc[te])
    Yv = predict(m, ctx, val_idx, coh.penc[val_idx])
    rows, Xcf, tcf = cf_set(coh, te, seed=fold)
    fs = FrozenStudent([m], ctx, te)
    which = np.repeat(np.arange(len(te)), N_CF)
    t1 = time.time()
    cfY = np.concatenate([fs.eval(which[s:s + 3000], Xcf[s:s + 3000])[0] for s in range(0, len(which), 3000)])
    tinf = (time.time() - t1) / len(which)
    # network-only metrics
    res_n = metrics(Yp, coh.Y[te])
    res_n["cf_rho"], res_n["cf_regret"] = cf_metrics(bmhi(cfY), tcf, len(te))
    # stacked with the boosted-tree branch (the deployed CHRONO-RAGAT)
    tb = tree_branch(coh, fold)
    res, _ = stacked_metrics(Yv, Yp, cfY, tb, coh, fold)
    meta = dict(model=name, fold=fold, seed=seed, train_time_s=ttrain, epochs=m.hist[-1][0],
                infer_ms_per_query=1000 * tinf, n_params=int(sum(p.data.size for p in m.params())))
    res.update(meta); res["network_only"] = res_n
    np.save(out.replace(".json", "_pred.npy"), Yp.astype(np.float32))
    np.save(out.replace(".json", "_val.npy"), Yv.astype(np.float32))
    np.save(out.replace(".json", "_cfY.npy"), cfY.astype(np.float32))
    json.dump(res, open(out, "w"))
    print(name, fold, seed, "stacked", round(res["bmhi_r2"], 3), round(res["cf_rho"], 3), "| net",
          round(res_n["bmhi_r2"], 3), round(res_n["cf_rho"], 3), round(ttrain), flush=True)


def worker(wid, nw):
    coh = Cohort("dev_")
    hp = load_hp()
    jobs = [("CHRONO-RAGAT", f, s) for s in range(3) for f in range(K_FOLD)]
    jobs += [(n, f, 0) for f in range(3) for n in ABL if n != "CHRONO-RAGAT"]     # ablations: first 3 folds
    for i, (n, f, s) in enumerate(jobs):
        if i % nw == wid:
            run_job(coh, n, f, s, hp)


def tabular():
    from sklearn.linear_model import RidgeCV
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.svm import SVR
    from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
    from sklearn.neural_network import MLPRegressor
    from sklearn.multioutput import MultiOutputRegressor
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    coh = Cohort("dev_")
    F = folds(coh.n)
    feats = np.concatenate([coh.S, coh.penc], 1)
    models = {
        "Ridge": lambda: make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 3, 15))),
        "k-NN": lambda: make_pipeline(StandardScaler(), KNeighborsRegressor(15, weights="distance")),
        "SVR (RBF)": lambda: make_pipeline(StandardScaler(), MultiOutputRegressor(SVR(C=3.0, epsilon=0.1))),
        "Random forest": lambda: RandomForestRegressor(300, min_samples_leaf=3, max_features=0.5, n_jobs=1, random_state=0),
        "Gradient boosting": lambda: MultiOutputRegressor(HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05,
                                                                                         random_state=0)),
        "MLP": lambda: make_pipeline(StandardScaler(), MLPRegressor(hidden_layer_sizes=(128, 64), alpha=1e-3, early_stopping=True,
                                                                    max_iter=500, random_state=0)),
    }
    for fold in range(K_FOLD):
        te = F[fold]; tr = np.concatenate([F[j] for j in range(K_FOLD) if j != fold])
        rows, Xcf, tcf = cf_set(coh, te, seed=fold)
        fcf = np.concatenate([coh.S[rows], coh.penc_for(rows, Xcf)], 1)
        for rel in [False, True]:
            sc = coh.base_scale if rel else np.ones_like(coh.base_scale)
            ysc = StandardScaler().fit((coh.Y / sc)[tr])
            for name, mk in models.items():
                out = os.path.join(CV, f"TAB_{name.replace(' ', '_').replace('(', '').replace(')', '')}_rel{int(rel)}__f{fold}.json")
                if os.path.exists(out):
                    continue
                t0 = time.time()
                mdl = mk().fit(feats[tr], ysc.transform((coh.Y / sc)[tr]))
                tt = time.time() - t0
                Yp = ysc.inverse_transform(mdl.predict(feats[te])) * sc[te]
                res = metrics(Yp, coh.Y[te])
                t1 = time.time()
                pcf = bmhi(ysc.inverse_transform(mdl.predict(fcf)) * sc[rows])
                res["cf_rho"], res["cf_regret"] = cf_metrics(pcf, tcf, len(te))
                res.update(model=name, rel=rel, fold=fold, train_time_s=tt,
                           infer_ms_per_query=1000 * (time.time() - t1) / len(rows))
                json.dump(res, open(out, "w"))
                print(name, rel, fold, round(res["bmhi_r2"], 3), round(res["cf_rho"], 3), flush=True)
    # noise ceiling (oracle that knows the noise-free response)
    for fold in range(K_FOLD):
        te = F[fold]
        Yt, _ = response(coh.b.iloc[te].reset_index(drop=True), coh.lat.iloc[te].reset_index(drop=True), coh.X[te], None,
                         noise=False)
        res = metrics(Yt, coh.Y[te]); res.update(model="Noise ceiling (true expected response)", fold=fold, cf_rho=1.0,
                                                 cf_regret=0.0)
        json.dump(res, open(os.path.join(CV, f"CEIL__f{fold}.json"), "w"))


if __name__ == "__main__":
    if sys.argv[1] == "worker":
        worker(int(sys.argv[2]), int(sys.argv[3]))
    elif sys.argv[1] == "tabular":
        tabular()
