"""Experiment 1: CLO-GWO vs. metaheuristic baselines on 12 shifted benchmark functions (D = 30),
30 independent runs, equal budget of 30,000 function evaluations; plus component ablation of CLO-GWO."""
import os, json, time
import numpy as np, pandas as pd
from scipy.stats import wilcoxon, friedmanchisquare, rankdata
from optimizers import clo_gwo, gwo, mgwo, pso, de, ga, woa

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
D, RUNS, POP, BUDGET = 30, 30, 30, 30000


def make_funcs(seed=11):
    rng = np.random.default_rng(seed)
    F = {}

    def reg(name, lo, hi, fn, shift=True, fopt=0.0, desc=""):
        o = rng.uniform(0.6 * lo, 0.6 * hi, D) if shift else np.zeros(D)
        F[name] = dict(lb=np.full(D, lo), ub=np.full(D, hi), f=(lambda X, fn=fn, o=o: fn(X - o)), fopt=fopt, desc=desc,
                       kind="")

    def penal(x, a, k, m):
        return np.where(x > a, k * (x - a) ** m, 0) + np.where(x < -a, k * (-x - a) ** m, 0)

    reg("F1", -100, 100, lambda Z: (Z ** 2).sum(-1), desc="Sphere (U)")
    reg("F2", -10, 10, lambda Z: np.abs(Z).sum(-1) + np.prod(np.abs(Z), -1), desc="Schwefel 2.22 (U)")
    reg("F3", -100, 100, lambda Z: (np.cumsum(Z, -1) ** 2).sum(-1), desc="Schwefel 1.2 (U)")
    reg("F4", -100, 100, lambda Z: np.abs(Z).max(-1), desc="Schwefel 2.21 (U)")
    reg("F5", -30, 30, lambda Z: (100 * (Z[..., 1:] - Z[..., :-1] ** 2) ** 2 + (Z[..., :-1] - 1) ** 2).sum(-1),
        desc="Rosenbrock (U)")
    reg("F6", -100, 100, lambda Z: (np.floor(Z + 0.5) ** 2).sum(-1), desc="Step (U)")
    reg("F7", -1.28, 1.28, lambda Z: ((np.arange(1, D + 1) * Z ** 4).sum(-1)), desc="Quartic (U)")
    F["F8"] = dict(lb=np.full(D, -500.0), ub=np.full(D, 500.0),
                   f=lambda X: (-X * np.sin(np.sqrt(np.abs(X)))).sum(-1) + 418.9829 * D, fopt=0.0,
                   desc="Schwefel 2.26 (M)", kind="")
    reg("F9", -5.12, 5.12, lambda Z: (Z ** 2 - 10 * np.cos(2 * np.pi * Z) + 10).sum(-1), desc="Rastrigin (M)")
    reg("F10", -32, 32, lambda Z: -20 * np.exp(-0.2 * np.sqrt((Z ** 2).mean(-1))) - np.exp(np.cos(2 * np.pi * Z).mean(-1))
        + 20 + np.e, desc="Ackley (M)")
    reg("F11", -600, 600, lambda Z: (Z ** 2).sum(-1) / 4000 - np.prod(np.cos(Z / np.sqrt(np.arange(1, D + 1))), -1) + 1,
        desc="Griewank (M)")

    def pen1(Z):
        y = 1 + (Z + 1) / 4
        s = 10 * np.sin(np.pi * y[..., 0]) ** 2 + ((y[..., :-1] - 1) ** 2 * (1 + 10 * np.sin(np.pi * y[..., 1:]) ** 2)).sum(-1) \
            + (y[..., -1] - 1) ** 2
        return np.pi / D * s + penal(Z, 10, 100, 4).sum(-1)
    reg("F12", -50, 50, pen1, desc="Penalized 1 (M)")
    return F


ALGS = {"CLO-GWO": clo_gwo, "GWO": gwo, "mGWO": mgwo, "PSO": pso, "DE": de, "GA": ga, "WOA": woa}
ABL = {"CLO-GWO": {}, "w/o circadian a(t)": dict(use_circ=False), "w/o Levy": dict(use_levy=False),
       "+ EOBL (excluded)": dict(use_eobl=True), "w/o greedy": dict(use_greedy=False),
       "w/o chaos-OBL init": dict(use_chaos_obl=False), "w/o weighted fusion": dict(use_wfuse=False),
       "w/o shift-invariant encircling": dict(use_sie=False)}


def run():
    funcs = make_funcs()
    rows, curves, abl_rows = [], {}, []
    t0 = time.time()
    for fname, F in funcs.items():
        f = lambda X, F=F: F["f"](X)
        for an, alg in ALGS.items():
            ts = time.time()
            bx, bf, cur = alg(f, F["lb"], F["ub"], RUNS, POP, BUDGET, np.random.default_rng(1000 + hash(an) % 997))
            for r in range(RUNS):
                rows.append(dict(func=fname, desc=F["desc"], alg=an, run=r, best=float(bf[r]),
                                 time_s=(time.time() - ts) / RUNS))
            curves[f"{fname}|{an}"] = [(float(fe), float(np.median(b))) for fe, b in cur]
        for an, kw in ABL.items():
            bx, bf, _ = clo_gwo(f, F["lb"], F["ub"], RUNS, POP, BUDGET, np.random.default_rng(77), **kw)
            for r in range(RUNS):
                abl_rows.append(dict(func=fname, variant=an, run=r, best=float(bf[r])))
        print(fname, "done", round(time.time() - t0, 1), flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(RES, "benchmark_raw_runs.csv"), index=False)
    pd.DataFrame(abl_rows).to_csv(os.path.join(RES, "benchmark_ablation_raw.csv"), index=False)
    json.dump(curves, open(os.path.join(RES, "benchmark_curves.json"), "w"))
    # summary table
    summ = df.groupby(["func", "desc", "alg"]).best.agg(["mean", "std", "median"]).reset_index()
    # Wilcoxon CLO-GWO vs each
    wl = []
    for fname in funcs:
        a = df[(df.func == fname) & (df.alg == "CLO-GWO")].best.values
        for an in ALGS:
            if an == "CLO-GWO":
                continue
            b = df[(df.func == fname) & (df.alg == an)].best.values
            if np.allclose(a, b):
                p, sign = 1.0, "="
            else:
                p = wilcoxon(a, b).pvalue
                sign = "+" if (p < 0.05 and np.median(a) < np.median(b)) else ("-" if (p < 0.05 and np.median(a) > np.median(b)) else "=")
            wl.append(dict(func=fname, vs=an, p=p, result=sign))
    pd.DataFrame(wl).to_csv(os.path.join(RES, "benchmark_wilcoxon.csv"), index=False)
    # Friedman ranks on mean
    piv = summ.pivot(index="func", columns="alg", values="mean")
    ranks = piv.rank(axis=1, method="average")
    fr = friedmanchisquare(*[piv[c].values for c in piv.columns])
    rk = ranks.mean().sort_values()
    rk.to_csv(os.path.join(RES, "benchmark_friedman_ranks.csv"))
    summ.to_csv(os.path.join(RES, "benchmark_summary.csv"), index=False)
    json.dump(dict(friedman_stat=float(fr.statistic), friedman_p=float(fr.pvalue)), open(os.path.join(RES, "benchmark_friedman.json"), "w"))
    ab = pd.DataFrame(abl_rows).groupby(["func", "variant"]).best.mean().unstack()
    ab.to_csv(os.path.join(RES, "benchmark_ablation_summary.csv"))
    print(rk); print(fr)


if __name__ == "__main__":
    run()
