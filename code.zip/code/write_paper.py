"""Assemble the manuscript (JSON blocks -> build_docx.js -> .docx) from the result files."""
import os, sys, json, glob, subprocess
import numpy as np, pandas as pd
from PIL import Image
from paper_static import TITLE, REFS, INTRO, RELATED, TABLE1, c
from paper_methods import methods
from paper_results import results_sections, discussion_sections, abstract_text, conclusion_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures"); RAW = os.path.join(ROOT, "data", "raw")
PAPER = os.path.join(ROOT, "paper")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from simulator import DEC_NAMES, DEC_LB, DEC_UB, DEC_UNITS, OUTCOMES, OUT_LABELS


def f(v, d=2):
    return f"{v:.{d}f}"


def table2():
    guide = [17, 60, 30, 5, 0, 12, 8, 18, 50, 25, 14, "0–10 (BMI rule)"]
    desc = ["Exercise start time", "Exercise intensity", "Session duration", "Sessions per week", "HIIT fraction of sessions",
            "Eating-window length", "First-meal time", "Protein share", "Carbohydrate share", "Dietary fibre",
            "Caffeine cut-off time", "Energy deficit"]
    rule = ["vigorous (>70% HRR) session must end ≥ 2 h before sleep", "—", "weekly volume 90–300 min (penalty)",
            "weekly volume 90–300 min (penalty)", "—", "last meal ≥ 2 h before sleep (penalty)", "—",
            "fat share kept in 20–40% (repair)", "fat share kept in 20–40% (repair)", "—", "—",
            "allowed only if BMI > 22; ≤ 4%/BMI unit, ≤ 20% (repair)"]
    rows = [[d, u, f"{lo:g}–{hi:g}", str(g), r] for d, u, lo, hi, g, r in zip(desc, DEC_UNITS, DEC_LB, DEC_UB, guide, rule)]
    return dict(type="table", header=["Variable", "Unit", "Range", "Guideline plan", "Safety rule"], rows=rows,
                widths=[0.22, 0.13, 0.11, 0.13, 0.41])


def table3():
    names = ["Learning rate", "Embedding width d", "Dropout", "Weight decay", "Graph neighbours k", "BMHI loss weight λ_{B}",
             "Base-path weight β", "Mini-batch size"]
    rng_ = ["10^{−3.5}–10^{−2.5}", "16–48 (step 8)", "0.05–0.35", "10^{−4}–10^{−2}", "5–20", "0.1–1.5", "0.1–1.0", "32–128 (powers of 2)"]
    keys = ["lr", "d", "dropout", "wd", "k", "lam_bmhi", "beta_base", "batch"]
    out = {}
    for m, fn in [("CLO-GWO", "hpo_best_CLO-GWO.json"), ("Random search", "hpo_best_Random.json")]:
        p = os.path.join(RES, fn)
        out[m] = json.load(open(p)) if os.path.exists(p) else None

    def fmt(k, v):
        if k in ("lr", "wd"):
            return f"{v:.2e}"
        if k in ("d", "k", "batch"):
            return str(int(v))
        return f"{v:.2f}"
    rows = []
    for n, r, k in zip(names, rng_, keys):
        rows.append([n, r] + [fmt(k, out[m]["best"][k]) if out[m] else "–" for m in out])
    rows.append(["**Best validation loss**", "", ] + [f"**{out[m]['best_val']:.4f}**" if out[m] else "–" for m in out])
    return dict(type="table", header=["Hyper-parameter", "Search range", "CLO-GWO", "Random search"], rows=rows,
                widths=[0.3, 0.26, 0.22, 0.22])


def table4():
    d = pd.read_csv(os.path.join(RAW, "dev_baseline_phenotype.csv"))
    t = pd.read_csv(os.path.join(RAW, "trial_baseline_phenotype.csv"))
    items = [("Male sex, %", "sex", "pct"), ("Age, years", "age", 1), ("BMI, kg/m²", "bmi", 1), ("Waist, cm", "waist", 1),
             ("VO_{2max}, mL/kg/min", "vo2max", 1), ("MVPA, min/week", "mvpa_wk", 0), ("Resting HR, bpm", "rhr", 1),
             ("RMSSD, ms", "rmssd", 1), ("Chronotype MSF_{sc}, clock h", "msf_sc", 2), ("Social jetlag, h", "social_jetlag", 2),
             ("Weekday sleep duration, h", "sleep_dur_week", 2), ("Sleep efficiency, %", "sleep_eff", 1),
             ("Perceived stress (0–40)", "stress_pss", 1), ("Eating window, h", "eating_window", 1),
             ("Energy intake, kcal/day", "kcal", 0), ("Last caffeine, clock h", "caffeine_last", 1),
             ("Fasting glucose, mg/dL", "fasting_glucose", 1), ("HOMA-IR", "homa_ir", 2), ("Triglycerides, mg/dL", "triglycerides", 0),
             ("HDL-C, mg/dL", "hdl", 1), ("Interdaily stability (IS)", "IS", 3), ("Intradaily variability (IV)", "IV", 3),
             ("Relative amplitude (RA)", "RA", 3)]
    rows = []
    for lab, col, dd in items:
        if dd == "pct":
            rows.append([lab, f"{100 * d[col].mean():.1f}", f"{100 * t[col].mean():.1f}"])
        else:
            rows.append([lab, f"{d[col].mean():.{dd}f} ± {d[col].std():.{dd}f}", f"{t[col].mean():.{dd}f} ± {t[col].std():.{dd}f}"])
    return dict(type="table", header=["Characteristic", f"Development cohort (n = {len(d):,})", f"External trial cohort (n = {len(t):,})"],
                rows=rows, widths=[0.4, 0.3, 0.3])


def table5():
    s = pd.read_csv(os.path.join(RES, "benchmark_summary.csv"))
    w = pd.read_csv(os.path.join(RES, "benchmark_wilcoxon.csv"))
    rk = pd.read_csv(os.path.join(RES, "benchmark_friedman_ranks.csv"), index_col=0).iloc[:, 0]
    algs = ["CLO-GWO", "GWO", "mGWO", "PSO", "DE", "GA", "WOA"]
    rows = []
    order = [f"F{i}" for i in range(1, 13)]
    for fn in order:
        d = s[s.func == fn].set_index("alg")
        best = d["mean"].idxmin()
        r = [f"{fn} {d.desc.iloc[0].split(' (')[0]}"]
        for a in algs:
            cell = f"{d.loc[a, 'mean']:.2e} ({d.loc[a, 'std']:.1e})"
            r.append(f"**{cell}**" if a == best else cell)
        rows.append(r)
    rows.append(["Friedman mean rank"] + [f"{rk[a]:.2f}" for a in algs])
    wtl = ["W/T/L of CLO-GWO", "–"]
    for a in algs[1:]:
        x = w[w.vs == a].result.value_counts()
        wtl.append(f"{x.get('+', 0)}/{x.get('=', 0)}/{x.get('-', 0)}")
    rows.append(wtl)
    return dict(type="table", header=["Function"] + algs, rows=rows, widths=[0.16] + [0.12] * 7, fontsize=14)


def write(R):
    blocks = [dict(type="title", text=TITLE),
              dict(type="center", text="[Author 1]^{1,*}, [Author 2]^{1}, [Author 3]^{2}"),
              dict(type="center", text="^{1} [Department, University, City, Country]; ^{2} [Department, University, City, Country]", size=19),
              dict(type="center", text="^{*} Corresponding author: [e-mail]", size=19),
              dict(type="h1", text="Abstract")]
    for p in abstract_text(R):
        blocks.append(dict(type="p", text=p))
    blocks.append(dict(type="p", text="**Highlights**"))
    for h in [
        "A physiology-grounded digital-twin cohort of college students links chronotype, rest–activity rhythm and metabolism to 12-week responses to exercise and diet timing.",
        "CHRONO-RAGAT combines a circadian Transformer, response-aware graph attention with residual response propagation and chrono-nutritional cross-attention, stacked with a boosted-tree expert.",
        "CLO-GWO removes the origin bias of grey wolf optimisation and adds a circadian-oscillatory search schedule and Lévy refinement.",
        "Uncertainty-penalised, safety-constrained plan search personalises exercise timing to chronotype and de-escalates intensity under stress.",
        "AI-personalised plans outperform guideline, rule-based and one-size-fits-all plans in counterfactual and in-silico randomised evaluations."]:
        blocks.append(dict(type="bullet", text=h))
    blocks.append(dict(type="p", text="**Keywords:** chrono-exercise; chrono-nutrition; circadian rhythm; graph attention network; grey wolf optimizer; "
                       "personalised prescription; digital twin; in-silico trial; college students; insulin resistance"))
    blocks.append(dict(type="h1", text="1. Introduction"))
    for t, x in INTRO:
        blocks.append(dict(type=t, text=x))
    blocks.append(dict(type="h1", text="2. Related work"))
    for t, x in RELATED:
        blocks.append(dict(type=t, text=x))
    blocks.append(dict(type="tcaption", text=TABLE1["caption"]))
    blocks.append(dict(type="table", header=TABLE1["header"], rows=TABLE1["rows"], widths=TABLE1["widths"], fontsize=15))
    blocks.append(dict(type="h1", text="3. Materials and methods"))
    for b in methods(R):
        blocks.extend(expand(b, R))
    blocks.append(dict(type="h1", text="4. Results"))
    for b in results_sections(R):
        blocks.extend(expand(b, R))
    blocks.append(dict(type="h1", text="5. Discussion"))
    for b in discussion_sections(R):
        blocks.extend(expand(b, R))
    blocks.append(dict(type="h1", text="6. Conclusions"))
    for p in conclusion_text(R):
        blocks.append(dict(type="p", text=p))
    blocks.append(dict(type="h1", text="Declarations"))
    for p in [
        "**Data availability.** All data analysed in this study are synthetic and were generated by the CHRONO-SIM generator described in Section 3.2. The raw development and external cohorts (baseline phenotypes, hourly actigraphy, daily logs, prescriptions, 12-week outcomes and the latent ground truth), all intermediate results and the participant-level in-silico trial data are provided in the supplementary data package.",
        "**Code availability.** The complete source code (cohort generator, automatic-differentiation engine, CHRONO-RAGAT, CLO-GWO and all baselines, experiment and figure scripts) is provided in the supplementary code package and reproduces every number in this paper from fixed random seeds.",
        "**Ethics statement.** The study used only simulated data; no human participants or animals were involved and no ethical approval was required.",
        "**Funding.** [To be completed by the authors.]",
        "**Author contributions (CRediT).** [To be completed by the authors.]",
        "**Conflicts of interest.** The authors declare no conflict of interest.",
    ]:
        blocks.append(dict(type="p", text=p))
    blocks.append(dict(type="h1", text="References"))
    for i, r in enumerate(REFS):
        blocks.append(dict(type="ref", text=f"[{i + 1}] {r}"))
    js = os.path.join(PAPER, "paper.json")
    json.dump(dict(title=TITLE, blocks=blocks), open(js, "w"), ensure_ascii=False)
    out = os.path.join(PAPER, "DJ0326-1_Manuscript_CHRONO-OPT.docx")
    subprocess.run(["node", os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_docx.js"), js, out], check=True)
    return out


def expand(b, R):
    t = b[0]
    if t == "figure":
        path = os.path.join(FIG, b[1] + ".png")
        w, h = Image.open(path).size
        return [dict(type="figure", path=path, width=b[2], ar=h / w)]
    if t == "table2":
        return [table2()]
    if t == "table3":
        return [table3()]
    if t == "table4":
        return [table4()]
    if t == "table5":
        return [table5()]
    if t == "tablex":
        return [b[1]]
    return [dict(type=t, text=b[1])]


if __name__ == "__main__":
    from paper_collect import collect
    R = collect()
    print(write(R))
