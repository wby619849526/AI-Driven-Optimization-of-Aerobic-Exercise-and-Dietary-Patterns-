"""Feature construction: static vector, circadian hourly tokens, daily tokens, prescription encoding,
and the phenotype-similarity graph."""
import os
import numpy as np, pandas as pd
from simulator import DEC_LB, DEC_UB, OUTCOMES, circ_diff

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data", "raw")

STATIC_COLS = ["sex", "age", "bmi", "waist", "vo2max", "rhr", "rmssd", "mvpa_wk", "msf_sc", "social_jetlag",
               "sleep_dur_week", "sleep_dur_free", "onset24", "wake_week", "sleep_eff", "stress_pss",
               "first_meal", "eating_window", "kcal", "carb_pct", "protein_pct", "fiber_g", "sugar_g",
               "caffeine_last", "screen_before_bed", "fasting_glucose", "insulin", "homa_ir", "triglycerides",
               "hdl", "IS", "IV", "RA", "L5", "M10", "m10_sin", "m10_cos"]


def load_cohort(prefix):
    b = pd.read_csv(os.path.join(RAW, f"{prefix}baseline_phenotype.csv"))
    lat = pd.read_csv(os.path.join(RAW, f"{prefix}latent_ground_truth.csv"))
    logs = pd.read_csv(os.path.join(RAW, f"{prefix}daily_logs.csv"))
    act = np.load(os.path.join(RAW, f"{prefix}actigraphy.npy")).astype(np.float64)
    return b, lat, logs, act


def static_matrix(b):
    b = b.copy()
    on = b.sleep_onset_week.values % 24
    b["onset24"] = np.where(on < 12, on + 24, on)
    b["m10_sin"] = np.sin(2 * np.pi * b.M10_onset / 24)
    b["m10_cos"] = np.cos(2 * np.pi * b.M10_onset / 24)
    for c in ["mvpa_wk", "insulin", "homa_ir", "triglycerides", "L5", "M10"]:
        b[c] = np.log(b[c])
    return b[STATIC_COLS].values.astype(float)


def hourly_tokens(act):
    """(N, 24, 4): weekday mean log-activity, weekend mean, between-day SD, rest fraction."""
    n, T = act.shape
    x = np.log1p(act.reshape(n, 14, 24))
    wk = np.array([(d % 7) in (5, 6) for d in range(14)])
    rest = (act.reshape(n, 14, 24) < 40).mean(1)
    return np.stack([x[:, ~wk].mean(1), x[:, wk].mean(1), x.std(1), rest], -1)


def daily_tokens(logs, n):
    L = logs.sort_values(["sid", "day"])
    on = L.sleep_onset.values % 24
    on = np.where(on < 12, on + 24, on)
    F = np.stack([on, L.sleep_duration.values, np.log(L.steps.values), L.mvpa_min.values,
                  L.first_meal.values, L.last_meal.values, L.kcal.values / 1000, L.caffeine_last.values,
                  L.weekend.values], -1)
    return F.reshape(n, 14, -1)


def presc_encode(X, b):
    """Prescription encoding incl. chronotype-relative timing (shared by all models)."""
    X = np.atleast_2d(X)
    msf = np.asarray(b["msf_sc"]) if not np.isscalar(b["msf_sc"]) else b["msf_sc"]
    wake = np.asarray(b["wake_week"])
    on = np.asarray(b["sleep_onset_week"]) % 24
    on = np.where(on < 12, on + 24, on)
    s = (X - DEC_LB) / (DEC_UB - DEC_LB)
    ex, fm, caf, win = X[:, 0], X[:, 6], X[:, 10], X[:, 5]
    rel = np.stack([circ_diff(ex, msf + 11.0) / 6, (fm - wake) / 3, (on - caf) / 8,
                    (on - (fm + win)) / 4, (X[:, 0] + X[:, 2] / 60 - on + 3) / 4], -1)
    trig = np.stack([np.sin(2 * np.pi * ex / 24), np.cos(2 * np.pi * ex / 24),
                     np.sin(2 * np.pi * fm / 24), np.cos(2 * np.pi * fm / 24)], -1)
    return np.concatenate([s, rel, trig], -1)


# indices into presc_encode output for the three intervention tokens
TOK_EX = [0, 1, 2, 3, 4, 12, 16, 17, 18]
TOK_DIET = [5, 6, 7, 8, 9, 11, 13, 15, 19, 20]
TOK_CAF = [10, 14, 15]


class Standardizer:
    def fit(self, A, axis=0):
        self.mu = A.mean(axis=axis, keepdims=True)
        self.sd = A.std(axis=axis, keepdims=True) + 1e-6
        return self

    def __call__(self, A):
        return (A - self.mu) / self.sd

    def inv(self, A):
        return A * self.sd + self.mu


def knn_graph(Z, ref_mask, k, exclude_self=True):
    """For every node, k most cosine-similar nodes among the reference (labelled) set."""
    Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9)
    S = Zn @ Zn.T
    S[:, ~ref_mask] = -np.inf
    if exclude_self:
        np.fill_diagonal(S, -np.inf)
    nb = np.argsort(-S, axis=1)[:, :k]
    sim = np.take_along_axis(S, nb, 1)
    return nb, sim


def knn_graph_cross(Zq, Zr, k):
    a = Zq / (np.linalg.norm(Zq, axis=1, keepdims=True) + 1e-9)
    r = Zr / (np.linalg.norm(Zr, axis=1, keepdims=True) + 1e-9)
    S = a @ r.T
    nb = np.argsort(-S, axis=1)[:, :k]
    return nb, np.take_along_axis(S, nb, 1)


# ---------------------------------------------------------------- piecewise-linear encoding (PLE)
def ple_fit(A, T=8):
    """Quantile bin edges per feature (T bins) for piecewise-linear numerical encoding."""
    q = np.quantile(A, np.linspace(0, 1, T + 1), axis=0)            # (T+1, F)
    for t in range(1, T + 1):
        q[t] = np.maximum(q[t], q[t - 1] + 1e-6)
    return q


def ple_transform(A, bins):
    lo, hi = bins[:-1], bins[1:]                                       # (T, F)
    e = (A[:, None, :] - lo[None]) / (hi - lo)[None]
    e = np.clip(e, 0.0, 1.0)
    return e.transpose(0, 2, 1).reshape(A.shape[0], -1)                # (n, F*T), feature-major
